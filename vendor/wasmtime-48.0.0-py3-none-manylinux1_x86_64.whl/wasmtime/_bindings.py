# flake8: noqa
#
# This is a procedurally generated file, DO NOT EDIT
# instead edit `./ci/cbindgen.py` at the root of the repo

import ctypes
from typing import Any
from enum import Enum, auto
from ._ffi import dll, wasm_val_t, wasm_ref_t

wasm_byte_t = ctypes.c_ubyte

class wasm_byte_vec_t(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_size_t),
        ("data", ctypes.POINTER(wasm_byte_t)),
    ]
    size: int
    data: ctypes._Pointer

_wasm_byte_vec_new_empty = dll.wasm_byte_vec_new_empty
_wasm_byte_vec_new_empty.restype = None
_wasm_byte_vec_new_empty.argtypes = [ctypes.POINTER(wasm_byte_vec_t)]
def wasm_byte_vec_new_empty(out: Any) -> None:
    return _wasm_byte_vec_new_empty(out)  # type: ignore

_wasm_byte_vec_new_uninitialized = dll.wasm_byte_vec_new_uninitialized
_wasm_byte_vec_new_uninitialized.restype = None
_wasm_byte_vec_new_uninitialized.argtypes = [ctypes.POINTER(wasm_byte_vec_t), ctypes.c_size_t]
def wasm_byte_vec_new_uninitialized(out: Any, arg1: Any) -> None:
    return _wasm_byte_vec_new_uninitialized(out, arg1)  # type: ignore

_wasm_byte_vec_new = dll.wasm_byte_vec_new
_wasm_byte_vec_new.restype = None
_wasm_byte_vec_new.argtypes = [ctypes.POINTER(wasm_byte_vec_t), ctypes.c_size_t, ctypes.POINTER(wasm_byte_t)]
def wasm_byte_vec_new(out: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_byte_vec_new(out, arg1, arg2)  # type: ignore

_wasm_byte_vec_copy = dll.wasm_byte_vec_copy
_wasm_byte_vec_copy.restype = None
_wasm_byte_vec_copy.argtypes = [ctypes.POINTER(wasm_byte_vec_t), ctypes.POINTER(wasm_byte_vec_t)]
def wasm_byte_vec_copy(out: Any, arg1: Any) -> None:
    return _wasm_byte_vec_copy(out, arg1)  # type: ignore

_wasm_byte_vec_delete = dll.wasm_byte_vec_delete
_wasm_byte_vec_delete.restype = None
_wasm_byte_vec_delete.argtypes = [ctypes.POINTER(wasm_byte_vec_t)]
def wasm_byte_vec_delete(arg0: Any) -> None:
    return _wasm_byte_vec_delete(arg0)  # type: ignore

wasm_name_t = wasm_byte_vec_t

class wasm_config_t(ctypes.Structure):
    pass

_wasm_config_delete = dll.wasm_config_delete
_wasm_config_delete.restype = None
_wasm_config_delete.argtypes = [ctypes.POINTER(wasm_config_t)]
def wasm_config_delete(arg0: Any) -> None:
    return _wasm_config_delete(arg0)  # type: ignore

_wasm_config_new = dll.wasm_config_new
_wasm_config_new.restype = ctypes.POINTER(wasm_config_t)
_wasm_config_new.argtypes = []
def wasm_config_new() -> ctypes._Pointer:
    return _wasm_config_new()  # type: ignore

class wasm_engine_t(ctypes.Structure):
    pass

_wasm_engine_delete = dll.wasm_engine_delete
_wasm_engine_delete.restype = None
_wasm_engine_delete.argtypes = [ctypes.POINTER(wasm_engine_t)]
def wasm_engine_delete(arg0: Any) -> None:
    return _wasm_engine_delete(arg0)  # type: ignore

_wasm_engine_new = dll.wasm_engine_new
_wasm_engine_new.restype = ctypes.POINTER(wasm_engine_t)
_wasm_engine_new.argtypes = []
def wasm_engine_new() -> ctypes._Pointer:
    return _wasm_engine_new()  # type: ignore

_wasm_engine_new_with_config = dll.wasm_engine_new_with_config
_wasm_engine_new_with_config.restype = ctypes.POINTER(wasm_engine_t)
_wasm_engine_new_with_config.argtypes = [ctypes.POINTER(wasm_config_t)]
def wasm_engine_new_with_config(arg0: Any) -> ctypes._Pointer:
    return _wasm_engine_new_with_config(arg0)  # type: ignore

class wasm_store_t(ctypes.Structure):
    pass

_wasm_store_delete = dll.wasm_store_delete
_wasm_store_delete.restype = None
_wasm_store_delete.argtypes = [ctypes.POINTER(wasm_store_t)]
def wasm_store_delete(arg0: Any) -> None:
    return _wasm_store_delete(arg0)  # type: ignore

_wasm_store_new = dll.wasm_store_new
_wasm_store_new.restype = ctypes.POINTER(wasm_store_t)
_wasm_store_new.argtypes = [ctypes.POINTER(wasm_engine_t)]
def wasm_store_new(arg0: Any) -> ctypes._Pointer:
    return _wasm_store_new(arg0)  # type: ignore

wasm_mutability_t = ctypes.c_uint8

class wasm_mutability_enum(Enum):
    WASM_CONST = auto()
    WASM_VAR = auto()

class wasm_limits_t(ctypes.Structure):
    _fields_ = [
        ("min", ctypes.c_uint32),
        ("max", ctypes.c_uint32),
    ]
    min: int
    max: int

class wasm_valtype_t(ctypes.Structure):
    pass

_wasm_valtype_delete = dll.wasm_valtype_delete
_wasm_valtype_delete.restype = None
_wasm_valtype_delete.argtypes = [ctypes.POINTER(wasm_valtype_t)]
def wasm_valtype_delete(arg0: Any) -> None:
    return _wasm_valtype_delete(arg0)  # type: ignore

class wasm_valtype_vec_t(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_size_t),
        ("data", ctypes.POINTER(ctypes.POINTER(wasm_valtype_t))),
    ]
    size: int
    data: ctypes._Pointer

_wasm_valtype_vec_new_empty = dll.wasm_valtype_vec_new_empty
_wasm_valtype_vec_new_empty.restype = None
_wasm_valtype_vec_new_empty.argtypes = [ctypes.POINTER(wasm_valtype_vec_t)]
def wasm_valtype_vec_new_empty(out: Any) -> None:
    return _wasm_valtype_vec_new_empty(out)  # type: ignore

_wasm_valtype_vec_new_uninitialized = dll.wasm_valtype_vec_new_uninitialized
_wasm_valtype_vec_new_uninitialized.restype = None
_wasm_valtype_vec_new_uninitialized.argtypes = [ctypes.POINTER(wasm_valtype_vec_t), ctypes.c_size_t]
def wasm_valtype_vec_new_uninitialized(out: Any, arg1: Any) -> None:
    return _wasm_valtype_vec_new_uninitialized(out, arg1)  # type: ignore

_wasm_valtype_vec_new = dll.wasm_valtype_vec_new
_wasm_valtype_vec_new.restype = None
_wasm_valtype_vec_new.argtypes = [ctypes.POINTER(wasm_valtype_vec_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(wasm_valtype_t))]
def wasm_valtype_vec_new(out: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_valtype_vec_new(out, arg1, arg2)  # type: ignore

_wasm_valtype_vec_copy = dll.wasm_valtype_vec_copy
_wasm_valtype_vec_copy.restype = None
_wasm_valtype_vec_copy.argtypes = [ctypes.POINTER(wasm_valtype_vec_t), ctypes.POINTER(wasm_valtype_vec_t)]
def wasm_valtype_vec_copy(out: Any, arg1: Any) -> None:
    return _wasm_valtype_vec_copy(out, arg1)  # type: ignore

_wasm_valtype_vec_delete = dll.wasm_valtype_vec_delete
_wasm_valtype_vec_delete.restype = None
_wasm_valtype_vec_delete.argtypes = [ctypes.POINTER(wasm_valtype_vec_t)]
def wasm_valtype_vec_delete(arg0: Any) -> None:
    return _wasm_valtype_vec_delete(arg0)  # type: ignore

_wasm_valtype_copy = dll.wasm_valtype_copy
_wasm_valtype_copy.restype = ctypes.POINTER(wasm_valtype_t)
_wasm_valtype_copy.argtypes = [ctypes.POINTER(wasm_valtype_t)]
def wasm_valtype_copy(arg0: Any) -> ctypes._Pointer:
    return _wasm_valtype_copy(arg0)  # type: ignore

wasm_valkind_t = ctypes.c_uint8

class wasm_valkind_enum(Enum):
    WASM_I32 = auto()
    WASM_I64 = auto()
    WASM_F32 = auto()
    WASM_F64 = auto()
    WASM_EXTERNREF = 128
    WASM_FUNCREF = auto()

_wasm_valtype_new = dll.wasm_valtype_new
_wasm_valtype_new.restype = ctypes.POINTER(wasm_valtype_t)
_wasm_valtype_new.argtypes = [wasm_valkind_t]
def wasm_valtype_new(arg0: Any) -> ctypes._Pointer:
    return _wasm_valtype_new(arg0)  # type: ignore

_wasm_valtype_kind = dll.wasm_valtype_kind
_wasm_valtype_kind.restype = wasm_valkind_t
_wasm_valtype_kind.argtypes = [ctypes.POINTER(wasm_valtype_t)]
def wasm_valtype_kind(arg0: Any) -> wasm_valkind_t:
    return _wasm_valtype_kind(arg0)  # type: ignore

class wasm_functype_t(ctypes.Structure):
    pass

_wasm_functype_delete = dll.wasm_functype_delete
_wasm_functype_delete.restype = None
_wasm_functype_delete.argtypes = [ctypes.POINTER(wasm_functype_t)]
def wasm_functype_delete(arg0: Any) -> None:
    return _wasm_functype_delete(arg0)  # type: ignore

class wasm_functype_vec_t(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_size_t),
        ("data", ctypes.POINTER(ctypes.POINTER(wasm_functype_t))),
    ]
    size: int
    data: ctypes._Pointer

_wasm_functype_vec_new_empty = dll.wasm_functype_vec_new_empty
_wasm_functype_vec_new_empty.restype = None
_wasm_functype_vec_new_empty.argtypes = [ctypes.POINTER(wasm_functype_vec_t)]
def wasm_functype_vec_new_empty(out: Any) -> None:
    return _wasm_functype_vec_new_empty(out)  # type: ignore

_wasm_functype_vec_new_uninitialized = dll.wasm_functype_vec_new_uninitialized
_wasm_functype_vec_new_uninitialized.restype = None
_wasm_functype_vec_new_uninitialized.argtypes = [ctypes.POINTER(wasm_functype_vec_t), ctypes.c_size_t]
def wasm_functype_vec_new_uninitialized(out: Any, arg1: Any) -> None:
    return _wasm_functype_vec_new_uninitialized(out, arg1)  # type: ignore

_wasm_functype_vec_new = dll.wasm_functype_vec_new
_wasm_functype_vec_new.restype = None
_wasm_functype_vec_new.argtypes = [ctypes.POINTER(wasm_functype_vec_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(wasm_functype_t))]
def wasm_functype_vec_new(out: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_functype_vec_new(out, arg1, arg2)  # type: ignore

_wasm_functype_vec_copy = dll.wasm_functype_vec_copy
_wasm_functype_vec_copy.restype = None
_wasm_functype_vec_copy.argtypes = [ctypes.POINTER(wasm_functype_vec_t), ctypes.POINTER(wasm_functype_vec_t)]
def wasm_functype_vec_copy(out: Any, arg1: Any) -> None:
    return _wasm_functype_vec_copy(out, arg1)  # type: ignore

_wasm_functype_vec_delete = dll.wasm_functype_vec_delete
_wasm_functype_vec_delete.restype = None
_wasm_functype_vec_delete.argtypes = [ctypes.POINTER(wasm_functype_vec_t)]
def wasm_functype_vec_delete(arg0: Any) -> None:
    return _wasm_functype_vec_delete(arg0)  # type: ignore

_wasm_functype_copy = dll.wasm_functype_copy
_wasm_functype_copy.restype = ctypes.POINTER(wasm_functype_t)
_wasm_functype_copy.argtypes = [ctypes.POINTER(wasm_functype_t)]
def wasm_functype_copy(arg0: Any) -> ctypes._Pointer:
    return _wasm_functype_copy(arg0)  # type: ignore

_wasm_functype_new = dll.wasm_functype_new
_wasm_functype_new.restype = ctypes.POINTER(wasm_functype_t)
_wasm_functype_new.argtypes = [ctypes.POINTER(wasm_valtype_vec_t), ctypes.POINTER(wasm_valtype_vec_t)]
def wasm_functype_new(params: Any, results: Any) -> ctypes._Pointer:
    return _wasm_functype_new(params, results)  # type: ignore

_wasm_functype_params = dll.wasm_functype_params
_wasm_functype_params.restype = ctypes.POINTER(wasm_valtype_vec_t)
_wasm_functype_params.argtypes = [ctypes.POINTER(wasm_functype_t)]
def wasm_functype_params(arg0: Any) -> ctypes._Pointer:
    return _wasm_functype_params(arg0)  # type: ignore

_wasm_functype_results = dll.wasm_functype_results
_wasm_functype_results.restype = ctypes.POINTER(wasm_valtype_vec_t)
_wasm_functype_results.argtypes = [ctypes.POINTER(wasm_functype_t)]
def wasm_functype_results(arg0: Any) -> ctypes._Pointer:
    return _wasm_functype_results(arg0)  # type: ignore

class wasm_globaltype_t(ctypes.Structure):
    pass

_wasm_globaltype_delete = dll.wasm_globaltype_delete
_wasm_globaltype_delete.restype = None
_wasm_globaltype_delete.argtypes = [ctypes.POINTER(wasm_globaltype_t)]
def wasm_globaltype_delete(arg0: Any) -> None:
    return _wasm_globaltype_delete(arg0)  # type: ignore

class wasm_globaltype_vec_t(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_size_t),
        ("data", ctypes.POINTER(ctypes.POINTER(wasm_globaltype_t))),
    ]
    size: int
    data: ctypes._Pointer

_wasm_globaltype_vec_new_empty = dll.wasm_globaltype_vec_new_empty
_wasm_globaltype_vec_new_empty.restype = None
_wasm_globaltype_vec_new_empty.argtypes = [ctypes.POINTER(wasm_globaltype_vec_t)]
def wasm_globaltype_vec_new_empty(out: Any) -> None:
    return _wasm_globaltype_vec_new_empty(out)  # type: ignore

_wasm_globaltype_vec_new_uninitialized = dll.wasm_globaltype_vec_new_uninitialized
_wasm_globaltype_vec_new_uninitialized.restype = None
_wasm_globaltype_vec_new_uninitialized.argtypes = [ctypes.POINTER(wasm_globaltype_vec_t), ctypes.c_size_t]
def wasm_globaltype_vec_new_uninitialized(out: Any, arg1: Any) -> None:
    return _wasm_globaltype_vec_new_uninitialized(out, arg1)  # type: ignore

_wasm_globaltype_vec_new = dll.wasm_globaltype_vec_new
_wasm_globaltype_vec_new.restype = None
_wasm_globaltype_vec_new.argtypes = [ctypes.POINTER(wasm_globaltype_vec_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(wasm_globaltype_t))]
def wasm_globaltype_vec_new(out: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_globaltype_vec_new(out, arg1, arg2)  # type: ignore

_wasm_globaltype_vec_copy = dll.wasm_globaltype_vec_copy
_wasm_globaltype_vec_copy.restype = None
_wasm_globaltype_vec_copy.argtypes = [ctypes.POINTER(wasm_globaltype_vec_t), ctypes.POINTER(wasm_globaltype_vec_t)]
def wasm_globaltype_vec_copy(out: Any, arg1: Any) -> None:
    return _wasm_globaltype_vec_copy(out, arg1)  # type: ignore

_wasm_globaltype_vec_delete = dll.wasm_globaltype_vec_delete
_wasm_globaltype_vec_delete.restype = None
_wasm_globaltype_vec_delete.argtypes = [ctypes.POINTER(wasm_globaltype_vec_t)]
def wasm_globaltype_vec_delete(arg0: Any) -> None:
    return _wasm_globaltype_vec_delete(arg0)  # type: ignore

_wasm_globaltype_copy = dll.wasm_globaltype_copy
_wasm_globaltype_copy.restype = ctypes.POINTER(wasm_globaltype_t)
_wasm_globaltype_copy.argtypes = [ctypes.POINTER(wasm_globaltype_t)]
def wasm_globaltype_copy(arg0: Any) -> ctypes._Pointer:
    return _wasm_globaltype_copy(arg0)  # type: ignore

_wasm_globaltype_new = dll.wasm_globaltype_new
_wasm_globaltype_new.restype = ctypes.POINTER(wasm_globaltype_t)
_wasm_globaltype_new.argtypes = [ctypes.POINTER(wasm_valtype_t), wasm_mutability_t]
def wasm_globaltype_new(arg0: Any, arg1: Any) -> ctypes._Pointer:
    return _wasm_globaltype_new(arg0, arg1)  # type: ignore

_wasm_globaltype_content = dll.wasm_globaltype_content
_wasm_globaltype_content.restype = ctypes.POINTER(wasm_valtype_t)
_wasm_globaltype_content.argtypes = [ctypes.POINTER(wasm_globaltype_t)]
def wasm_globaltype_content(arg0: Any) -> ctypes._Pointer:
    return _wasm_globaltype_content(arg0)  # type: ignore

_wasm_globaltype_mutability = dll.wasm_globaltype_mutability
_wasm_globaltype_mutability.restype = wasm_mutability_t
_wasm_globaltype_mutability.argtypes = [ctypes.POINTER(wasm_globaltype_t)]
def wasm_globaltype_mutability(arg0: Any) -> wasm_mutability_t:
    return _wasm_globaltype_mutability(arg0)  # type: ignore

class wasm_tabletype_t(ctypes.Structure):
    pass

_wasm_tabletype_delete = dll.wasm_tabletype_delete
_wasm_tabletype_delete.restype = None
_wasm_tabletype_delete.argtypes = [ctypes.POINTER(wasm_tabletype_t)]
def wasm_tabletype_delete(arg0: Any) -> None:
    return _wasm_tabletype_delete(arg0)  # type: ignore

class wasm_tabletype_vec_t(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_size_t),
        ("data", ctypes.POINTER(ctypes.POINTER(wasm_tabletype_t))),
    ]
    size: int
    data: ctypes._Pointer

_wasm_tabletype_vec_new_empty = dll.wasm_tabletype_vec_new_empty
_wasm_tabletype_vec_new_empty.restype = None
_wasm_tabletype_vec_new_empty.argtypes = [ctypes.POINTER(wasm_tabletype_vec_t)]
def wasm_tabletype_vec_new_empty(out: Any) -> None:
    return _wasm_tabletype_vec_new_empty(out)  # type: ignore

_wasm_tabletype_vec_new_uninitialized = dll.wasm_tabletype_vec_new_uninitialized
_wasm_tabletype_vec_new_uninitialized.restype = None
_wasm_tabletype_vec_new_uninitialized.argtypes = [ctypes.POINTER(wasm_tabletype_vec_t), ctypes.c_size_t]
def wasm_tabletype_vec_new_uninitialized(out: Any, arg1: Any) -> None:
    return _wasm_tabletype_vec_new_uninitialized(out, arg1)  # type: ignore

_wasm_tabletype_vec_new = dll.wasm_tabletype_vec_new
_wasm_tabletype_vec_new.restype = None
_wasm_tabletype_vec_new.argtypes = [ctypes.POINTER(wasm_tabletype_vec_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(wasm_tabletype_t))]
def wasm_tabletype_vec_new(out: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_tabletype_vec_new(out, arg1, arg2)  # type: ignore

_wasm_tabletype_vec_copy = dll.wasm_tabletype_vec_copy
_wasm_tabletype_vec_copy.restype = None
_wasm_tabletype_vec_copy.argtypes = [ctypes.POINTER(wasm_tabletype_vec_t), ctypes.POINTER(wasm_tabletype_vec_t)]
def wasm_tabletype_vec_copy(out: Any, arg1: Any) -> None:
    return _wasm_tabletype_vec_copy(out, arg1)  # type: ignore

_wasm_tabletype_vec_delete = dll.wasm_tabletype_vec_delete
_wasm_tabletype_vec_delete.restype = None
_wasm_tabletype_vec_delete.argtypes = [ctypes.POINTER(wasm_tabletype_vec_t)]
def wasm_tabletype_vec_delete(arg0: Any) -> None:
    return _wasm_tabletype_vec_delete(arg0)  # type: ignore

_wasm_tabletype_copy = dll.wasm_tabletype_copy
_wasm_tabletype_copy.restype = ctypes.POINTER(wasm_tabletype_t)
_wasm_tabletype_copy.argtypes = [ctypes.POINTER(wasm_tabletype_t)]
def wasm_tabletype_copy(arg0: Any) -> ctypes._Pointer:
    return _wasm_tabletype_copy(arg0)  # type: ignore

_wasm_tabletype_new = dll.wasm_tabletype_new
_wasm_tabletype_new.restype = ctypes.POINTER(wasm_tabletype_t)
_wasm_tabletype_new.argtypes = [ctypes.POINTER(wasm_valtype_t), ctypes.POINTER(wasm_limits_t)]
def wasm_tabletype_new(arg0: Any, arg1: Any) -> ctypes._Pointer:
    return _wasm_tabletype_new(arg0, arg1)  # type: ignore

_wasm_tabletype_element = dll.wasm_tabletype_element
_wasm_tabletype_element.restype = ctypes.POINTER(wasm_valtype_t)
_wasm_tabletype_element.argtypes = [ctypes.POINTER(wasm_tabletype_t)]
def wasm_tabletype_element(arg0: Any) -> ctypes._Pointer:
    return _wasm_tabletype_element(arg0)  # type: ignore

_wasm_tabletype_limits = dll.wasm_tabletype_limits
_wasm_tabletype_limits.restype = ctypes.POINTER(wasm_limits_t)
_wasm_tabletype_limits.argtypes = [ctypes.POINTER(wasm_tabletype_t)]
def wasm_tabletype_limits(arg0: Any) -> ctypes._Pointer:
    return _wasm_tabletype_limits(arg0)  # type: ignore

class wasm_memorytype_t(ctypes.Structure):
    pass

_wasm_memorytype_delete = dll.wasm_memorytype_delete
_wasm_memorytype_delete.restype = None
_wasm_memorytype_delete.argtypes = [ctypes.POINTER(wasm_memorytype_t)]
def wasm_memorytype_delete(arg0: Any) -> None:
    return _wasm_memorytype_delete(arg0)  # type: ignore

class wasm_memorytype_vec_t(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_size_t),
        ("data", ctypes.POINTER(ctypes.POINTER(wasm_memorytype_t))),
    ]
    size: int
    data: ctypes._Pointer

_wasm_memorytype_vec_new_empty = dll.wasm_memorytype_vec_new_empty
_wasm_memorytype_vec_new_empty.restype = None
_wasm_memorytype_vec_new_empty.argtypes = [ctypes.POINTER(wasm_memorytype_vec_t)]
def wasm_memorytype_vec_new_empty(out: Any) -> None:
    return _wasm_memorytype_vec_new_empty(out)  # type: ignore

_wasm_memorytype_vec_new_uninitialized = dll.wasm_memorytype_vec_new_uninitialized
_wasm_memorytype_vec_new_uninitialized.restype = None
_wasm_memorytype_vec_new_uninitialized.argtypes = [ctypes.POINTER(wasm_memorytype_vec_t), ctypes.c_size_t]
def wasm_memorytype_vec_new_uninitialized(out: Any, arg1: Any) -> None:
    return _wasm_memorytype_vec_new_uninitialized(out, arg1)  # type: ignore

_wasm_memorytype_vec_new = dll.wasm_memorytype_vec_new
_wasm_memorytype_vec_new.restype = None
_wasm_memorytype_vec_new.argtypes = [ctypes.POINTER(wasm_memorytype_vec_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(wasm_memorytype_t))]
def wasm_memorytype_vec_new(out: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_memorytype_vec_new(out, arg1, arg2)  # type: ignore

_wasm_memorytype_vec_copy = dll.wasm_memorytype_vec_copy
_wasm_memorytype_vec_copy.restype = None
_wasm_memorytype_vec_copy.argtypes = [ctypes.POINTER(wasm_memorytype_vec_t), ctypes.POINTER(wasm_memorytype_vec_t)]
def wasm_memorytype_vec_copy(out: Any, arg1: Any) -> None:
    return _wasm_memorytype_vec_copy(out, arg1)  # type: ignore

_wasm_memorytype_vec_delete = dll.wasm_memorytype_vec_delete
_wasm_memorytype_vec_delete.restype = None
_wasm_memorytype_vec_delete.argtypes = [ctypes.POINTER(wasm_memorytype_vec_t)]
def wasm_memorytype_vec_delete(arg0: Any) -> None:
    return _wasm_memorytype_vec_delete(arg0)  # type: ignore

_wasm_memorytype_copy = dll.wasm_memorytype_copy
_wasm_memorytype_copy.restype = ctypes.POINTER(wasm_memorytype_t)
_wasm_memorytype_copy.argtypes = [ctypes.POINTER(wasm_memorytype_t)]
def wasm_memorytype_copy(arg0: Any) -> ctypes._Pointer:
    return _wasm_memorytype_copy(arg0)  # type: ignore

_wasm_memorytype_new = dll.wasm_memorytype_new
_wasm_memorytype_new.restype = ctypes.POINTER(wasm_memorytype_t)
_wasm_memorytype_new.argtypes = [ctypes.POINTER(wasm_limits_t)]
def wasm_memorytype_new(arg0: Any) -> ctypes._Pointer:
    return _wasm_memorytype_new(arg0)  # type: ignore

_wasm_memorytype_limits = dll.wasm_memorytype_limits
_wasm_memorytype_limits.restype = ctypes.POINTER(wasm_limits_t)
_wasm_memorytype_limits.argtypes = [ctypes.POINTER(wasm_memorytype_t)]
def wasm_memorytype_limits(arg0: Any) -> ctypes._Pointer:
    return _wasm_memorytype_limits(arg0)  # type: ignore

class wasm_tagtype_t(ctypes.Structure):
    pass

_wasm_tagtype_delete = dll.wasm_tagtype_delete
_wasm_tagtype_delete.restype = None
_wasm_tagtype_delete.argtypes = [ctypes.POINTER(wasm_tagtype_t)]
def wasm_tagtype_delete(arg0: Any) -> None:
    return _wasm_tagtype_delete(arg0)  # type: ignore

class wasm_tagtype_vec_t(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_size_t),
        ("data", ctypes.POINTER(ctypes.POINTER(wasm_tagtype_t))),
    ]
    size: int
    data: ctypes._Pointer

_wasm_tagtype_copy = dll.wasm_tagtype_copy
_wasm_tagtype_copy.restype = ctypes.POINTER(wasm_tagtype_t)
_wasm_tagtype_copy.argtypes = [ctypes.POINTER(wasm_tagtype_t)]
def wasm_tagtype_copy(arg0: Any) -> ctypes._Pointer:
    return _wasm_tagtype_copy(arg0)  # type: ignore

_wasm_tagtype_new = dll.wasm_tagtype_new
_wasm_tagtype_new.restype = ctypes.POINTER(wasm_tagtype_t)
_wasm_tagtype_new.argtypes = [ctypes.POINTER(wasm_functype_t)]
def wasm_tagtype_new(arg0: Any) -> ctypes._Pointer:
    return _wasm_tagtype_new(arg0)  # type: ignore

_wasm_tagtype_functype = dll.wasm_tagtype_functype
_wasm_tagtype_functype.restype = ctypes.POINTER(wasm_functype_t)
_wasm_tagtype_functype.argtypes = [ctypes.POINTER(wasm_tagtype_t)]
def wasm_tagtype_functype(arg0: Any) -> ctypes._Pointer:
    return _wasm_tagtype_functype(arg0)  # type: ignore

class wasm_externtype_t(ctypes.Structure):
    pass

_wasm_externtype_delete = dll.wasm_externtype_delete
_wasm_externtype_delete.restype = None
_wasm_externtype_delete.argtypes = [ctypes.POINTER(wasm_externtype_t)]
def wasm_externtype_delete(arg0: Any) -> None:
    return _wasm_externtype_delete(arg0)  # type: ignore

class wasm_externtype_vec_t(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_size_t),
        ("data", ctypes.POINTER(ctypes.POINTER(wasm_externtype_t))),
    ]
    size: int
    data: ctypes._Pointer

_wasm_externtype_vec_new_empty = dll.wasm_externtype_vec_new_empty
_wasm_externtype_vec_new_empty.restype = None
_wasm_externtype_vec_new_empty.argtypes = [ctypes.POINTER(wasm_externtype_vec_t)]
def wasm_externtype_vec_new_empty(out: Any) -> None:
    return _wasm_externtype_vec_new_empty(out)  # type: ignore

_wasm_externtype_vec_new_uninitialized = dll.wasm_externtype_vec_new_uninitialized
_wasm_externtype_vec_new_uninitialized.restype = None
_wasm_externtype_vec_new_uninitialized.argtypes = [ctypes.POINTER(wasm_externtype_vec_t), ctypes.c_size_t]
def wasm_externtype_vec_new_uninitialized(out: Any, arg1: Any) -> None:
    return _wasm_externtype_vec_new_uninitialized(out, arg1)  # type: ignore

_wasm_externtype_vec_new = dll.wasm_externtype_vec_new
_wasm_externtype_vec_new.restype = None
_wasm_externtype_vec_new.argtypes = [ctypes.POINTER(wasm_externtype_vec_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(wasm_externtype_t))]
def wasm_externtype_vec_new(out: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_externtype_vec_new(out, arg1, arg2)  # type: ignore

_wasm_externtype_vec_copy = dll.wasm_externtype_vec_copy
_wasm_externtype_vec_copy.restype = None
_wasm_externtype_vec_copy.argtypes = [ctypes.POINTER(wasm_externtype_vec_t), ctypes.POINTER(wasm_externtype_vec_t)]
def wasm_externtype_vec_copy(out: Any, arg1: Any) -> None:
    return _wasm_externtype_vec_copy(out, arg1)  # type: ignore

_wasm_externtype_vec_delete = dll.wasm_externtype_vec_delete
_wasm_externtype_vec_delete.restype = None
_wasm_externtype_vec_delete.argtypes = [ctypes.POINTER(wasm_externtype_vec_t)]
def wasm_externtype_vec_delete(arg0: Any) -> None:
    return _wasm_externtype_vec_delete(arg0)  # type: ignore

_wasm_externtype_copy = dll.wasm_externtype_copy
_wasm_externtype_copy.restype = ctypes.POINTER(wasm_externtype_t)
_wasm_externtype_copy.argtypes = [ctypes.POINTER(wasm_externtype_t)]
def wasm_externtype_copy(arg0: Any) -> ctypes._Pointer:
    return _wasm_externtype_copy(arg0)  # type: ignore

wasm_externkind_t = ctypes.c_uint8

class wasm_externkind_enum(Enum):
    WASM_EXTERN_FUNC = auto()
    WASM_EXTERN_GLOBAL = auto()
    WASM_EXTERN_TABLE = auto()
    WASM_EXTERN_MEMORY = auto()
    WASM_EXTERN_TAG = auto()

_wasm_externtype_kind = dll.wasm_externtype_kind
_wasm_externtype_kind.restype = wasm_externkind_t
_wasm_externtype_kind.argtypes = [ctypes.POINTER(wasm_externtype_t)]
def wasm_externtype_kind(arg0: Any) -> wasm_externkind_t:
    return _wasm_externtype_kind(arg0)  # type: ignore

_wasm_functype_as_externtype = dll.wasm_functype_as_externtype
_wasm_functype_as_externtype.restype = ctypes.POINTER(wasm_externtype_t)
_wasm_functype_as_externtype.argtypes = [ctypes.POINTER(wasm_functype_t)]
def wasm_functype_as_externtype(arg0: Any) -> ctypes._Pointer:
    return _wasm_functype_as_externtype(arg0)  # type: ignore

_wasm_globaltype_as_externtype = dll.wasm_globaltype_as_externtype
_wasm_globaltype_as_externtype.restype = ctypes.POINTER(wasm_externtype_t)
_wasm_globaltype_as_externtype.argtypes = [ctypes.POINTER(wasm_globaltype_t)]
def wasm_globaltype_as_externtype(arg0: Any) -> ctypes._Pointer:
    return _wasm_globaltype_as_externtype(arg0)  # type: ignore

_wasm_tabletype_as_externtype = dll.wasm_tabletype_as_externtype
_wasm_tabletype_as_externtype.restype = ctypes.POINTER(wasm_externtype_t)
_wasm_tabletype_as_externtype.argtypes = [ctypes.POINTER(wasm_tabletype_t)]
def wasm_tabletype_as_externtype(arg0: Any) -> ctypes._Pointer:
    return _wasm_tabletype_as_externtype(arg0)  # type: ignore

_wasm_memorytype_as_externtype = dll.wasm_memorytype_as_externtype
_wasm_memorytype_as_externtype.restype = ctypes.POINTER(wasm_externtype_t)
_wasm_memorytype_as_externtype.argtypes = [ctypes.POINTER(wasm_memorytype_t)]
def wasm_memorytype_as_externtype(arg0: Any) -> ctypes._Pointer:
    return _wasm_memorytype_as_externtype(arg0)  # type: ignore

_wasm_tagtype_as_externtype = dll.wasm_tagtype_as_externtype
_wasm_tagtype_as_externtype.restype = ctypes.POINTER(wasm_externtype_t)
_wasm_tagtype_as_externtype.argtypes = [ctypes.POINTER(wasm_tagtype_t)]
def wasm_tagtype_as_externtype(arg0: Any) -> ctypes._Pointer:
    return _wasm_tagtype_as_externtype(arg0)  # type: ignore

_wasm_externtype_as_functype = dll.wasm_externtype_as_functype
_wasm_externtype_as_functype.restype = ctypes.POINTER(wasm_functype_t)
_wasm_externtype_as_functype.argtypes = [ctypes.POINTER(wasm_externtype_t)]
def wasm_externtype_as_functype(arg0: Any) -> ctypes._Pointer:
    return _wasm_externtype_as_functype(arg0)  # type: ignore

_wasm_externtype_as_globaltype = dll.wasm_externtype_as_globaltype
_wasm_externtype_as_globaltype.restype = ctypes.POINTER(wasm_globaltype_t)
_wasm_externtype_as_globaltype.argtypes = [ctypes.POINTER(wasm_externtype_t)]
def wasm_externtype_as_globaltype(arg0: Any) -> ctypes._Pointer:
    return _wasm_externtype_as_globaltype(arg0)  # type: ignore

_wasm_externtype_as_tabletype = dll.wasm_externtype_as_tabletype
_wasm_externtype_as_tabletype.restype = ctypes.POINTER(wasm_tabletype_t)
_wasm_externtype_as_tabletype.argtypes = [ctypes.POINTER(wasm_externtype_t)]
def wasm_externtype_as_tabletype(arg0: Any) -> ctypes._Pointer:
    return _wasm_externtype_as_tabletype(arg0)  # type: ignore

_wasm_externtype_as_memorytype = dll.wasm_externtype_as_memorytype
_wasm_externtype_as_memorytype.restype = ctypes.POINTER(wasm_memorytype_t)
_wasm_externtype_as_memorytype.argtypes = [ctypes.POINTER(wasm_externtype_t)]
def wasm_externtype_as_memorytype(arg0: Any) -> ctypes._Pointer:
    return _wasm_externtype_as_memorytype(arg0)  # type: ignore

_wasm_externtype_as_tagtype = dll.wasm_externtype_as_tagtype
_wasm_externtype_as_tagtype.restype = ctypes.POINTER(wasm_tagtype_t)
_wasm_externtype_as_tagtype.argtypes = [ctypes.POINTER(wasm_externtype_t)]
def wasm_externtype_as_tagtype(arg0: Any) -> ctypes._Pointer:
    return _wasm_externtype_as_tagtype(arg0)  # type: ignore

_wasm_functype_as_externtype_const = dll.wasm_functype_as_externtype_const
_wasm_functype_as_externtype_const.restype = ctypes.POINTER(wasm_externtype_t)
_wasm_functype_as_externtype_const.argtypes = [ctypes.POINTER(wasm_functype_t)]
def wasm_functype_as_externtype_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_functype_as_externtype_const(arg0)  # type: ignore

_wasm_globaltype_as_externtype_const = dll.wasm_globaltype_as_externtype_const
_wasm_globaltype_as_externtype_const.restype = ctypes.POINTER(wasm_externtype_t)
_wasm_globaltype_as_externtype_const.argtypes = [ctypes.POINTER(wasm_globaltype_t)]
def wasm_globaltype_as_externtype_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_globaltype_as_externtype_const(arg0)  # type: ignore

_wasm_tabletype_as_externtype_const = dll.wasm_tabletype_as_externtype_const
_wasm_tabletype_as_externtype_const.restype = ctypes.POINTER(wasm_externtype_t)
_wasm_tabletype_as_externtype_const.argtypes = [ctypes.POINTER(wasm_tabletype_t)]
def wasm_tabletype_as_externtype_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_tabletype_as_externtype_const(arg0)  # type: ignore

_wasm_memorytype_as_externtype_const = dll.wasm_memorytype_as_externtype_const
_wasm_memorytype_as_externtype_const.restype = ctypes.POINTER(wasm_externtype_t)
_wasm_memorytype_as_externtype_const.argtypes = [ctypes.POINTER(wasm_memorytype_t)]
def wasm_memorytype_as_externtype_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_memorytype_as_externtype_const(arg0)  # type: ignore

_wasm_tagtype_as_externtype_const = dll.wasm_tagtype_as_externtype_const
_wasm_tagtype_as_externtype_const.restype = ctypes.POINTER(wasm_externtype_t)
_wasm_tagtype_as_externtype_const.argtypes = [ctypes.POINTER(wasm_tagtype_t)]
def wasm_tagtype_as_externtype_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_tagtype_as_externtype_const(arg0)  # type: ignore

_wasm_externtype_as_functype_const = dll.wasm_externtype_as_functype_const
_wasm_externtype_as_functype_const.restype = ctypes.POINTER(wasm_functype_t)
_wasm_externtype_as_functype_const.argtypes = [ctypes.POINTER(wasm_externtype_t)]
def wasm_externtype_as_functype_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_externtype_as_functype_const(arg0)  # type: ignore

_wasm_externtype_as_globaltype_const = dll.wasm_externtype_as_globaltype_const
_wasm_externtype_as_globaltype_const.restype = ctypes.POINTER(wasm_globaltype_t)
_wasm_externtype_as_globaltype_const.argtypes = [ctypes.POINTER(wasm_externtype_t)]
def wasm_externtype_as_globaltype_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_externtype_as_globaltype_const(arg0)  # type: ignore

_wasm_externtype_as_tabletype_const = dll.wasm_externtype_as_tabletype_const
_wasm_externtype_as_tabletype_const.restype = ctypes.POINTER(wasm_tabletype_t)
_wasm_externtype_as_tabletype_const.argtypes = [ctypes.POINTER(wasm_externtype_t)]
def wasm_externtype_as_tabletype_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_externtype_as_tabletype_const(arg0)  # type: ignore

_wasm_externtype_as_memorytype_const = dll.wasm_externtype_as_memorytype_const
_wasm_externtype_as_memorytype_const.restype = ctypes.POINTER(wasm_memorytype_t)
_wasm_externtype_as_memorytype_const.argtypes = [ctypes.POINTER(wasm_externtype_t)]
def wasm_externtype_as_memorytype_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_externtype_as_memorytype_const(arg0)  # type: ignore

_wasm_externtype_as_tagtype_const = dll.wasm_externtype_as_tagtype_const
_wasm_externtype_as_tagtype_const.restype = ctypes.POINTER(wasm_tagtype_t)
_wasm_externtype_as_tagtype_const.argtypes = [ctypes.POINTER(wasm_externtype_t)]
def wasm_externtype_as_tagtype_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_externtype_as_tagtype_const(arg0)  # type: ignore

class wasm_importtype_t(ctypes.Structure):
    pass

_wasm_importtype_delete = dll.wasm_importtype_delete
_wasm_importtype_delete.restype = None
_wasm_importtype_delete.argtypes = [ctypes.POINTER(wasm_importtype_t)]
def wasm_importtype_delete(arg0: Any) -> None:
    return _wasm_importtype_delete(arg0)  # type: ignore

class wasm_importtype_vec_t(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_size_t),
        ("data", ctypes.POINTER(ctypes.POINTER(wasm_importtype_t))),
    ]
    size: int
    data: ctypes._Pointer

_wasm_importtype_vec_new_empty = dll.wasm_importtype_vec_new_empty
_wasm_importtype_vec_new_empty.restype = None
_wasm_importtype_vec_new_empty.argtypes = [ctypes.POINTER(wasm_importtype_vec_t)]
def wasm_importtype_vec_new_empty(out: Any) -> None:
    return _wasm_importtype_vec_new_empty(out)  # type: ignore

_wasm_importtype_vec_new_uninitialized = dll.wasm_importtype_vec_new_uninitialized
_wasm_importtype_vec_new_uninitialized.restype = None
_wasm_importtype_vec_new_uninitialized.argtypes = [ctypes.POINTER(wasm_importtype_vec_t), ctypes.c_size_t]
def wasm_importtype_vec_new_uninitialized(out: Any, arg1: Any) -> None:
    return _wasm_importtype_vec_new_uninitialized(out, arg1)  # type: ignore

_wasm_importtype_vec_new = dll.wasm_importtype_vec_new
_wasm_importtype_vec_new.restype = None
_wasm_importtype_vec_new.argtypes = [ctypes.POINTER(wasm_importtype_vec_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(wasm_importtype_t))]
def wasm_importtype_vec_new(out: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_importtype_vec_new(out, arg1, arg2)  # type: ignore

_wasm_importtype_vec_copy = dll.wasm_importtype_vec_copy
_wasm_importtype_vec_copy.restype = None
_wasm_importtype_vec_copy.argtypes = [ctypes.POINTER(wasm_importtype_vec_t), ctypes.POINTER(wasm_importtype_vec_t)]
def wasm_importtype_vec_copy(out: Any, arg1: Any) -> None:
    return _wasm_importtype_vec_copy(out, arg1)  # type: ignore

_wasm_importtype_vec_delete = dll.wasm_importtype_vec_delete
_wasm_importtype_vec_delete.restype = None
_wasm_importtype_vec_delete.argtypes = [ctypes.POINTER(wasm_importtype_vec_t)]
def wasm_importtype_vec_delete(arg0: Any) -> None:
    return _wasm_importtype_vec_delete(arg0)  # type: ignore

_wasm_importtype_copy = dll.wasm_importtype_copy
_wasm_importtype_copy.restype = ctypes.POINTER(wasm_importtype_t)
_wasm_importtype_copy.argtypes = [ctypes.POINTER(wasm_importtype_t)]
def wasm_importtype_copy(arg0: Any) -> ctypes._Pointer:
    return _wasm_importtype_copy(arg0)  # type: ignore

_wasm_importtype_new = dll.wasm_importtype_new
_wasm_importtype_new.restype = ctypes.POINTER(wasm_importtype_t)
_wasm_importtype_new.argtypes = [ctypes.POINTER(wasm_name_t), ctypes.POINTER(wasm_name_t), ctypes.POINTER(wasm_externtype_t)]
def wasm_importtype_new(module: Any, name: Any, arg2: Any) -> ctypes._Pointer:
    return _wasm_importtype_new(module, name, arg2)  # type: ignore

_wasm_importtype_module = dll.wasm_importtype_module
_wasm_importtype_module.restype = ctypes.POINTER(wasm_name_t)
_wasm_importtype_module.argtypes = [ctypes.POINTER(wasm_importtype_t)]
def wasm_importtype_module(arg0: Any) -> ctypes._Pointer:
    return _wasm_importtype_module(arg0)  # type: ignore

_wasm_importtype_name = dll.wasm_importtype_name
_wasm_importtype_name.restype = ctypes.POINTER(wasm_name_t)
_wasm_importtype_name.argtypes = [ctypes.POINTER(wasm_importtype_t)]
def wasm_importtype_name(arg0: Any) -> ctypes._Pointer:
    return _wasm_importtype_name(arg0)  # type: ignore

_wasm_importtype_type = dll.wasm_importtype_type
_wasm_importtype_type.restype = ctypes.POINTER(wasm_externtype_t)
_wasm_importtype_type.argtypes = [ctypes.POINTER(wasm_importtype_t)]
def wasm_importtype_type(arg0: Any) -> ctypes._Pointer:
    return _wasm_importtype_type(arg0)  # type: ignore

class wasm_exporttype_t(ctypes.Structure):
    pass

_wasm_exporttype_delete = dll.wasm_exporttype_delete
_wasm_exporttype_delete.restype = None
_wasm_exporttype_delete.argtypes = [ctypes.POINTER(wasm_exporttype_t)]
def wasm_exporttype_delete(arg0: Any) -> None:
    return _wasm_exporttype_delete(arg0)  # type: ignore

class wasm_exporttype_vec_t(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_size_t),
        ("data", ctypes.POINTER(ctypes.POINTER(wasm_exporttype_t))),
    ]
    size: int
    data: ctypes._Pointer

_wasm_exporttype_vec_new_empty = dll.wasm_exporttype_vec_new_empty
_wasm_exporttype_vec_new_empty.restype = None
_wasm_exporttype_vec_new_empty.argtypes = [ctypes.POINTER(wasm_exporttype_vec_t)]
def wasm_exporttype_vec_new_empty(out: Any) -> None:
    return _wasm_exporttype_vec_new_empty(out)  # type: ignore

_wasm_exporttype_vec_new_uninitialized = dll.wasm_exporttype_vec_new_uninitialized
_wasm_exporttype_vec_new_uninitialized.restype = None
_wasm_exporttype_vec_new_uninitialized.argtypes = [ctypes.POINTER(wasm_exporttype_vec_t), ctypes.c_size_t]
def wasm_exporttype_vec_new_uninitialized(out: Any, arg1: Any) -> None:
    return _wasm_exporttype_vec_new_uninitialized(out, arg1)  # type: ignore

_wasm_exporttype_vec_new = dll.wasm_exporttype_vec_new
_wasm_exporttype_vec_new.restype = None
_wasm_exporttype_vec_new.argtypes = [ctypes.POINTER(wasm_exporttype_vec_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(wasm_exporttype_t))]
def wasm_exporttype_vec_new(out: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_exporttype_vec_new(out, arg1, arg2)  # type: ignore

_wasm_exporttype_vec_copy = dll.wasm_exporttype_vec_copy
_wasm_exporttype_vec_copy.restype = None
_wasm_exporttype_vec_copy.argtypes = [ctypes.POINTER(wasm_exporttype_vec_t), ctypes.POINTER(wasm_exporttype_vec_t)]
def wasm_exporttype_vec_copy(out: Any, arg1: Any) -> None:
    return _wasm_exporttype_vec_copy(out, arg1)  # type: ignore

_wasm_exporttype_vec_delete = dll.wasm_exporttype_vec_delete
_wasm_exporttype_vec_delete.restype = None
_wasm_exporttype_vec_delete.argtypes = [ctypes.POINTER(wasm_exporttype_vec_t)]
def wasm_exporttype_vec_delete(arg0: Any) -> None:
    return _wasm_exporttype_vec_delete(arg0)  # type: ignore

_wasm_exporttype_copy = dll.wasm_exporttype_copy
_wasm_exporttype_copy.restype = ctypes.POINTER(wasm_exporttype_t)
_wasm_exporttype_copy.argtypes = [ctypes.POINTER(wasm_exporttype_t)]
def wasm_exporttype_copy(arg0: Any) -> ctypes._Pointer:
    return _wasm_exporttype_copy(arg0)  # type: ignore

_wasm_exporttype_new = dll.wasm_exporttype_new
_wasm_exporttype_new.restype = ctypes.POINTER(wasm_exporttype_t)
_wasm_exporttype_new.argtypes = [ctypes.POINTER(wasm_name_t), ctypes.POINTER(wasm_externtype_t)]
def wasm_exporttype_new(arg0: Any, arg1: Any) -> ctypes._Pointer:
    return _wasm_exporttype_new(arg0, arg1)  # type: ignore

_wasm_exporttype_name = dll.wasm_exporttype_name
_wasm_exporttype_name.restype = ctypes.POINTER(wasm_name_t)
_wasm_exporttype_name.argtypes = [ctypes.POINTER(wasm_exporttype_t)]
def wasm_exporttype_name(arg0: Any) -> ctypes._Pointer:
    return _wasm_exporttype_name(arg0)  # type: ignore

_wasm_exporttype_type = dll.wasm_exporttype_type
_wasm_exporttype_type.restype = ctypes.POINTER(wasm_externtype_t)
_wasm_exporttype_type.argtypes = [ctypes.POINTER(wasm_exporttype_t)]
def wasm_exporttype_type(arg0: Any) -> ctypes._Pointer:
    return _wasm_exporttype_type(arg0)  # type: ignore

_wasm_val_delete = dll.wasm_val_delete
_wasm_val_delete.restype = None
_wasm_val_delete.argtypes = [ctypes.POINTER(wasm_val_t)]
def wasm_val_delete(v: Any) -> None:
    return _wasm_val_delete(v)  # type: ignore

_wasm_val_copy = dll.wasm_val_copy
_wasm_val_copy.restype = None
_wasm_val_copy.argtypes = [ctypes.POINTER(wasm_val_t), ctypes.POINTER(wasm_val_t)]
def wasm_val_copy(out: Any, arg1: Any) -> None:
    return _wasm_val_copy(out, arg1)  # type: ignore

class wasm_val_vec_t(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_size_t),
        ("data", ctypes.POINTER(wasm_val_t)),
    ]
    size: int
    data: ctypes._Pointer

_wasm_val_vec_new_empty = dll.wasm_val_vec_new_empty
_wasm_val_vec_new_empty.restype = None
_wasm_val_vec_new_empty.argtypes = [ctypes.POINTER(wasm_val_vec_t)]
def wasm_val_vec_new_empty(out: Any) -> None:
    return _wasm_val_vec_new_empty(out)  # type: ignore

_wasm_val_vec_new_uninitialized = dll.wasm_val_vec_new_uninitialized
_wasm_val_vec_new_uninitialized.restype = None
_wasm_val_vec_new_uninitialized.argtypes = [ctypes.POINTER(wasm_val_vec_t), ctypes.c_size_t]
def wasm_val_vec_new_uninitialized(out: Any, arg1: Any) -> None:
    return _wasm_val_vec_new_uninitialized(out, arg1)  # type: ignore

_wasm_val_vec_new = dll.wasm_val_vec_new
_wasm_val_vec_new.restype = None
_wasm_val_vec_new.argtypes = [ctypes.POINTER(wasm_val_vec_t), ctypes.c_size_t, ctypes.POINTER(wasm_val_t)]
def wasm_val_vec_new(out: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_val_vec_new(out, arg1, arg2)  # type: ignore

_wasm_val_vec_copy = dll.wasm_val_vec_copy
_wasm_val_vec_copy.restype = None
_wasm_val_vec_copy.argtypes = [ctypes.POINTER(wasm_val_vec_t), ctypes.POINTER(wasm_val_vec_t)]
def wasm_val_vec_copy(out: Any, arg1: Any) -> None:
    return _wasm_val_vec_copy(out, arg1)  # type: ignore

_wasm_val_vec_delete = dll.wasm_val_vec_delete
_wasm_val_vec_delete.restype = None
_wasm_val_vec_delete.argtypes = [ctypes.POINTER(wasm_val_vec_t)]
def wasm_val_vec_delete(arg0: Any) -> None:
    return _wasm_val_vec_delete(arg0)  # type: ignore

_wasm_ref_delete = dll.wasm_ref_delete
_wasm_ref_delete.restype = None
_wasm_ref_delete.argtypes = [ctypes.POINTER(wasm_ref_t)]
def wasm_ref_delete(arg0: Any) -> None:
    return _wasm_ref_delete(arg0)  # type: ignore

_wasm_ref_copy = dll.wasm_ref_copy
_wasm_ref_copy.restype = ctypes.POINTER(wasm_ref_t)
_wasm_ref_copy.argtypes = [ctypes.POINTER(wasm_ref_t)]
def wasm_ref_copy(arg0: Any) -> ctypes._Pointer:
    return _wasm_ref_copy(arg0)  # type: ignore

_wasm_ref_same = dll.wasm_ref_same
_wasm_ref_same.restype = ctypes.c_bool
_wasm_ref_same.argtypes = [ctypes.POINTER(wasm_ref_t), ctypes.POINTER(wasm_ref_t)]
def wasm_ref_same(arg0: Any, arg1: Any) -> bool:
    return _wasm_ref_same(arg0, arg1)  # type: ignore

_wasm_ref_get_host_info = dll.wasm_ref_get_host_info
_wasm_ref_get_host_info.restype = ctypes.c_void_p
_wasm_ref_get_host_info.argtypes = [ctypes.POINTER(wasm_ref_t)]
def wasm_ref_get_host_info(arg0: Any) -> ctypes._Pointer:
    return _wasm_ref_get_host_info(arg0)  # type: ignore

_wasm_ref_set_host_info = dll.wasm_ref_set_host_info
_wasm_ref_set_host_info.restype = None
_wasm_ref_set_host_info.argtypes = [ctypes.POINTER(wasm_ref_t), ctypes.c_void_p]
def wasm_ref_set_host_info(arg0: Any, arg1: Any) -> None:
    return _wasm_ref_set_host_info(arg0, arg1)  # type: ignore

_wasm_ref_set_host_info_with_finalizer = dll.wasm_ref_set_host_info_with_finalizer
_wasm_ref_set_host_info_with_finalizer.restype = None
_wasm_ref_set_host_info_with_finalizer.argtypes = [ctypes.POINTER(wasm_ref_t), ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p)]
def wasm_ref_set_host_info_with_finalizer(arg0: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_ref_set_host_info_with_finalizer(arg0, arg1, arg2)  # type: ignore

class wasm_frame_t(ctypes.Structure):
    pass

_wasm_frame_delete = dll.wasm_frame_delete
_wasm_frame_delete.restype = None
_wasm_frame_delete.argtypes = [ctypes.POINTER(wasm_frame_t)]
def wasm_frame_delete(arg0: Any) -> None:
    return _wasm_frame_delete(arg0)  # type: ignore

class wasm_frame_vec_t(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_size_t),
        ("data", ctypes.POINTER(ctypes.POINTER(wasm_frame_t))),
    ]
    size: int
    data: ctypes._Pointer

_wasm_frame_vec_new_empty = dll.wasm_frame_vec_new_empty
_wasm_frame_vec_new_empty.restype = None
_wasm_frame_vec_new_empty.argtypes = [ctypes.POINTER(wasm_frame_vec_t)]
def wasm_frame_vec_new_empty(out: Any) -> None:
    return _wasm_frame_vec_new_empty(out)  # type: ignore

_wasm_frame_vec_new_uninitialized = dll.wasm_frame_vec_new_uninitialized
_wasm_frame_vec_new_uninitialized.restype = None
_wasm_frame_vec_new_uninitialized.argtypes = [ctypes.POINTER(wasm_frame_vec_t), ctypes.c_size_t]
def wasm_frame_vec_new_uninitialized(out: Any, arg1: Any) -> None:
    return _wasm_frame_vec_new_uninitialized(out, arg1)  # type: ignore

_wasm_frame_vec_new = dll.wasm_frame_vec_new
_wasm_frame_vec_new.restype = None
_wasm_frame_vec_new.argtypes = [ctypes.POINTER(wasm_frame_vec_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(wasm_frame_t))]
def wasm_frame_vec_new(out: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_frame_vec_new(out, arg1, arg2)  # type: ignore

_wasm_frame_vec_copy = dll.wasm_frame_vec_copy
_wasm_frame_vec_copy.restype = None
_wasm_frame_vec_copy.argtypes = [ctypes.POINTER(wasm_frame_vec_t), ctypes.POINTER(wasm_frame_vec_t)]
def wasm_frame_vec_copy(out: Any, arg1: Any) -> None:
    return _wasm_frame_vec_copy(out, arg1)  # type: ignore

_wasm_frame_vec_delete = dll.wasm_frame_vec_delete
_wasm_frame_vec_delete.restype = None
_wasm_frame_vec_delete.argtypes = [ctypes.POINTER(wasm_frame_vec_t)]
def wasm_frame_vec_delete(arg0: Any) -> None:
    return _wasm_frame_vec_delete(arg0)  # type: ignore

_wasm_frame_copy = dll.wasm_frame_copy
_wasm_frame_copy.restype = ctypes.POINTER(wasm_frame_t)
_wasm_frame_copy.argtypes = [ctypes.POINTER(wasm_frame_t)]
def wasm_frame_copy(arg0: Any) -> ctypes._Pointer:
    return _wasm_frame_copy(arg0)  # type: ignore

_wasm_frame_func_index = dll.wasm_frame_func_index
_wasm_frame_func_index.restype = ctypes.c_uint32
_wasm_frame_func_index.argtypes = [ctypes.POINTER(wasm_frame_t)]
def wasm_frame_func_index(arg0: Any) -> int:
    return _wasm_frame_func_index(arg0)  # type: ignore

_wasm_frame_func_offset = dll.wasm_frame_func_offset
_wasm_frame_func_offset.restype = ctypes.c_size_t
_wasm_frame_func_offset.argtypes = [ctypes.POINTER(wasm_frame_t)]
def wasm_frame_func_offset(arg0: Any) -> int:
    return _wasm_frame_func_offset(arg0)  # type: ignore

_wasm_frame_module_offset = dll.wasm_frame_module_offset
_wasm_frame_module_offset.restype = ctypes.c_size_t
_wasm_frame_module_offset.argtypes = [ctypes.POINTER(wasm_frame_t)]
def wasm_frame_module_offset(arg0: Any) -> int:
    return _wasm_frame_module_offset(arg0)  # type: ignore

wasm_message_t = wasm_name_t

class wasm_trap_t(ctypes.Structure):
    pass

_wasm_trap_delete = dll.wasm_trap_delete
_wasm_trap_delete.restype = None
_wasm_trap_delete.argtypes = [ctypes.POINTER(wasm_trap_t)]
def wasm_trap_delete(arg0: Any) -> None:
    return _wasm_trap_delete(arg0)  # type: ignore

_wasm_trap_copy = dll.wasm_trap_copy
_wasm_trap_copy.restype = ctypes.POINTER(wasm_trap_t)
_wasm_trap_copy.argtypes = [ctypes.POINTER(wasm_trap_t)]
def wasm_trap_copy(arg0: Any) -> ctypes._Pointer:
    return _wasm_trap_copy(arg0)  # type: ignore

_wasm_trap_same = dll.wasm_trap_same
_wasm_trap_same.restype = ctypes.c_bool
_wasm_trap_same.argtypes = [ctypes.POINTER(wasm_trap_t), ctypes.POINTER(wasm_trap_t)]
def wasm_trap_same(arg0: Any, arg1: Any) -> bool:
    return _wasm_trap_same(arg0, arg1)  # type: ignore

_wasm_trap_get_host_info = dll.wasm_trap_get_host_info
_wasm_trap_get_host_info.restype = ctypes.c_void_p
_wasm_trap_get_host_info.argtypes = [ctypes.POINTER(wasm_trap_t)]
def wasm_trap_get_host_info(arg0: Any) -> ctypes._Pointer:
    return _wasm_trap_get_host_info(arg0)  # type: ignore

_wasm_trap_set_host_info = dll.wasm_trap_set_host_info
_wasm_trap_set_host_info.restype = None
_wasm_trap_set_host_info.argtypes = [ctypes.POINTER(wasm_trap_t), ctypes.c_void_p]
def wasm_trap_set_host_info(arg0: Any, arg1: Any) -> None:
    return _wasm_trap_set_host_info(arg0, arg1)  # type: ignore

_wasm_trap_set_host_info_with_finalizer = dll.wasm_trap_set_host_info_with_finalizer
_wasm_trap_set_host_info_with_finalizer.restype = None
_wasm_trap_set_host_info_with_finalizer.argtypes = [ctypes.POINTER(wasm_trap_t), ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p)]
def wasm_trap_set_host_info_with_finalizer(arg0: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_trap_set_host_info_with_finalizer(arg0, arg1, arg2)  # type: ignore

_wasm_trap_as_ref = dll.wasm_trap_as_ref
_wasm_trap_as_ref.restype = ctypes.POINTER(wasm_ref_t)
_wasm_trap_as_ref.argtypes = [ctypes.POINTER(wasm_trap_t)]
def wasm_trap_as_ref(arg0: Any) -> ctypes._Pointer:
    return _wasm_trap_as_ref(arg0)  # type: ignore

_wasm_ref_as_trap = dll.wasm_ref_as_trap
_wasm_ref_as_trap.restype = ctypes.POINTER(wasm_trap_t)
_wasm_ref_as_trap.argtypes = [ctypes.POINTER(wasm_ref_t)]
def wasm_ref_as_trap(arg0: Any) -> ctypes._Pointer:
    return _wasm_ref_as_trap(arg0)  # type: ignore

_wasm_trap_as_ref_const = dll.wasm_trap_as_ref_const
_wasm_trap_as_ref_const.restype = ctypes.POINTER(wasm_ref_t)
_wasm_trap_as_ref_const.argtypes = [ctypes.POINTER(wasm_trap_t)]
def wasm_trap_as_ref_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_trap_as_ref_const(arg0)  # type: ignore

_wasm_ref_as_trap_const = dll.wasm_ref_as_trap_const
_wasm_ref_as_trap_const.restype = ctypes.POINTER(wasm_trap_t)
_wasm_ref_as_trap_const.argtypes = [ctypes.POINTER(wasm_ref_t)]
def wasm_ref_as_trap_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_ref_as_trap_const(arg0)  # type: ignore

_wasm_trap_new = dll.wasm_trap_new
_wasm_trap_new.restype = ctypes.POINTER(wasm_trap_t)
_wasm_trap_new.argtypes = [ctypes.POINTER(wasm_store_t), ctypes.POINTER(wasm_message_t)]
def wasm_trap_new(store: Any, arg1: Any) -> ctypes._Pointer:
    return _wasm_trap_new(store, arg1)  # type: ignore

_wasm_trap_message = dll.wasm_trap_message
_wasm_trap_message.restype = None
_wasm_trap_message.argtypes = [ctypes.POINTER(wasm_trap_t), ctypes.POINTER(wasm_message_t)]
def wasm_trap_message(arg0: Any, out: Any) -> None:
    return _wasm_trap_message(arg0, out)  # type: ignore

_wasm_trap_origin = dll.wasm_trap_origin
_wasm_trap_origin.restype = ctypes.POINTER(wasm_frame_t)
_wasm_trap_origin.argtypes = [ctypes.POINTER(wasm_trap_t)]
def wasm_trap_origin(arg0: Any) -> ctypes._Pointer:
    return _wasm_trap_origin(arg0)  # type: ignore

_wasm_trap_trace = dll.wasm_trap_trace
_wasm_trap_trace.restype = None
_wasm_trap_trace.argtypes = [ctypes.POINTER(wasm_trap_t), ctypes.POINTER(wasm_frame_vec_t)]
def wasm_trap_trace(arg0: Any, out: Any) -> None:
    return _wasm_trap_trace(arg0, out)  # type: ignore

class wasm_foreign_t(ctypes.Structure):
    pass

_wasm_foreign_delete = dll.wasm_foreign_delete
_wasm_foreign_delete.restype = None
_wasm_foreign_delete.argtypes = [ctypes.POINTER(wasm_foreign_t)]
def wasm_foreign_delete(arg0: Any) -> None:
    return _wasm_foreign_delete(arg0)  # type: ignore

_wasm_foreign_copy = dll.wasm_foreign_copy
_wasm_foreign_copy.restype = ctypes.POINTER(wasm_foreign_t)
_wasm_foreign_copy.argtypes = [ctypes.POINTER(wasm_foreign_t)]
def wasm_foreign_copy(arg0: Any) -> ctypes._Pointer:
    return _wasm_foreign_copy(arg0)  # type: ignore

_wasm_foreign_same = dll.wasm_foreign_same
_wasm_foreign_same.restype = ctypes.c_bool
_wasm_foreign_same.argtypes = [ctypes.POINTER(wasm_foreign_t), ctypes.POINTER(wasm_foreign_t)]
def wasm_foreign_same(arg0: Any, arg1: Any) -> bool:
    return _wasm_foreign_same(arg0, arg1)  # type: ignore

_wasm_foreign_get_host_info = dll.wasm_foreign_get_host_info
_wasm_foreign_get_host_info.restype = ctypes.c_void_p
_wasm_foreign_get_host_info.argtypes = [ctypes.POINTER(wasm_foreign_t)]
def wasm_foreign_get_host_info(arg0: Any) -> ctypes._Pointer:
    return _wasm_foreign_get_host_info(arg0)  # type: ignore

_wasm_foreign_set_host_info = dll.wasm_foreign_set_host_info
_wasm_foreign_set_host_info.restype = None
_wasm_foreign_set_host_info.argtypes = [ctypes.POINTER(wasm_foreign_t), ctypes.c_void_p]
def wasm_foreign_set_host_info(arg0: Any, arg1: Any) -> None:
    return _wasm_foreign_set_host_info(arg0, arg1)  # type: ignore

_wasm_foreign_set_host_info_with_finalizer = dll.wasm_foreign_set_host_info_with_finalizer
_wasm_foreign_set_host_info_with_finalizer.restype = None
_wasm_foreign_set_host_info_with_finalizer.argtypes = [ctypes.POINTER(wasm_foreign_t), ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p)]
def wasm_foreign_set_host_info_with_finalizer(arg0: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_foreign_set_host_info_with_finalizer(arg0, arg1, arg2)  # type: ignore

_wasm_foreign_as_ref = dll.wasm_foreign_as_ref
_wasm_foreign_as_ref.restype = ctypes.POINTER(wasm_ref_t)
_wasm_foreign_as_ref.argtypes = [ctypes.POINTER(wasm_foreign_t)]
def wasm_foreign_as_ref(arg0: Any) -> ctypes._Pointer:
    return _wasm_foreign_as_ref(arg0)  # type: ignore

_wasm_ref_as_foreign = dll.wasm_ref_as_foreign
_wasm_ref_as_foreign.restype = ctypes.POINTER(wasm_foreign_t)
_wasm_ref_as_foreign.argtypes = [ctypes.POINTER(wasm_ref_t)]
def wasm_ref_as_foreign(arg0: Any) -> ctypes._Pointer:
    return _wasm_ref_as_foreign(arg0)  # type: ignore

_wasm_foreign_as_ref_const = dll.wasm_foreign_as_ref_const
_wasm_foreign_as_ref_const.restype = ctypes.POINTER(wasm_ref_t)
_wasm_foreign_as_ref_const.argtypes = [ctypes.POINTER(wasm_foreign_t)]
def wasm_foreign_as_ref_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_foreign_as_ref_const(arg0)  # type: ignore

_wasm_ref_as_foreign_const = dll.wasm_ref_as_foreign_const
_wasm_ref_as_foreign_const.restype = ctypes.POINTER(wasm_foreign_t)
_wasm_ref_as_foreign_const.argtypes = [ctypes.POINTER(wasm_ref_t)]
def wasm_ref_as_foreign_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_ref_as_foreign_const(arg0)  # type: ignore

_wasm_foreign_new = dll.wasm_foreign_new
_wasm_foreign_new.restype = ctypes.POINTER(wasm_foreign_t)
_wasm_foreign_new.argtypes = [ctypes.POINTER(wasm_store_t)]
def wasm_foreign_new(arg0: Any) -> ctypes._Pointer:
    return _wasm_foreign_new(arg0)  # type: ignore

class wasm_module_t(ctypes.Structure):
    pass

_wasm_module_delete = dll.wasm_module_delete
_wasm_module_delete.restype = None
_wasm_module_delete.argtypes = [ctypes.POINTER(wasm_module_t)]
def wasm_module_delete(arg0: Any) -> None:
    return _wasm_module_delete(arg0)  # type: ignore

_wasm_module_copy = dll.wasm_module_copy
_wasm_module_copy.restype = ctypes.POINTER(wasm_module_t)
_wasm_module_copy.argtypes = [ctypes.POINTER(wasm_module_t)]
def wasm_module_copy(arg0: Any) -> ctypes._Pointer:
    return _wasm_module_copy(arg0)  # type: ignore

_wasm_module_same = dll.wasm_module_same
_wasm_module_same.restype = ctypes.c_bool
_wasm_module_same.argtypes = [ctypes.POINTER(wasm_module_t), ctypes.POINTER(wasm_module_t)]
def wasm_module_same(arg0: Any, arg1: Any) -> bool:
    return _wasm_module_same(arg0, arg1)  # type: ignore

_wasm_module_get_host_info = dll.wasm_module_get_host_info
_wasm_module_get_host_info.restype = ctypes.c_void_p
_wasm_module_get_host_info.argtypes = [ctypes.POINTER(wasm_module_t)]
def wasm_module_get_host_info(arg0: Any) -> ctypes._Pointer:
    return _wasm_module_get_host_info(arg0)  # type: ignore

_wasm_module_set_host_info = dll.wasm_module_set_host_info
_wasm_module_set_host_info.restype = None
_wasm_module_set_host_info.argtypes = [ctypes.POINTER(wasm_module_t), ctypes.c_void_p]
def wasm_module_set_host_info(arg0: Any, arg1: Any) -> None:
    return _wasm_module_set_host_info(arg0, arg1)  # type: ignore

_wasm_module_set_host_info_with_finalizer = dll.wasm_module_set_host_info_with_finalizer
_wasm_module_set_host_info_with_finalizer.restype = None
_wasm_module_set_host_info_with_finalizer.argtypes = [ctypes.POINTER(wasm_module_t), ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p)]
def wasm_module_set_host_info_with_finalizer(arg0: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_module_set_host_info_with_finalizer(arg0, arg1, arg2)  # type: ignore

_wasm_module_as_ref = dll.wasm_module_as_ref
_wasm_module_as_ref.restype = ctypes.POINTER(wasm_ref_t)
_wasm_module_as_ref.argtypes = [ctypes.POINTER(wasm_module_t)]
def wasm_module_as_ref(arg0: Any) -> ctypes._Pointer:
    return _wasm_module_as_ref(arg0)  # type: ignore

_wasm_ref_as_module = dll.wasm_ref_as_module
_wasm_ref_as_module.restype = ctypes.POINTER(wasm_module_t)
_wasm_ref_as_module.argtypes = [ctypes.POINTER(wasm_ref_t)]
def wasm_ref_as_module(arg0: Any) -> ctypes._Pointer:
    return _wasm_ref_as_module(arg0)  # type: ignore

_wasm_module_as_ref_const = dll.wasm_module_as_ref_const
_wasm_module_as_ref_const.restype = ctypes.POINTER(wasm_ref_t)
_wasm_module_as_ref_const.argtypes = [ctypes.POINTER(wasm_module_t)]
def wasm_module_as_ref_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_module_as_ref_const(arg0)  # type: ignore

_wasm_ref_as_module_const = dll.wasm_ref_as_module_const
_wasm_ref_as_module_const.restype = ctypes.POINTER(wasm_module_t)
_wasm_ref_as_module_const.argtypes = [ctypes.POINTER(wasm_ref_t)]
def wasm_ref_as_module_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_ref_as_module_const(arg0)  # type: ignore

class wasm_shared_module_t(ctypes.Structure):
    pass

_wasm_shared_module_delete = dll.wasm_shared_module_delete
_wasm_shared_module_delete.restype = None
_wasm_shared_module_delete.argtypes = [ctypes.POINTER(wasm_shared_module_t)]
def wasm_shared_module_delete(arg0: Any) -> None:
    return _wasm_shared_module_delete(arg0)  # type: ignore

_wasm_module_share = dll.wasm_module_share
_wasm_module_share.restype = ctypes.POINTER(wasm_shared_module_t)
_wasm_module_share.argtypes = [ctypes.POINTER(wasm_module_t)]
def wasm_module_share(arg0: Any) -> ctypes._Pointer:
    return _wasm_module_share(arg0)  # type: ignore

_wasm_module_obtain = dll.wasm_module_obtain
_wasm_module_obtain.restype = ctypes.POINTER(wasm_module_t)
_wasm_module_obtain.argtypes = [ctypes.POINTER(wasm_store_t), ctypes.POINTER(wasm_shared_module_t)]
def wasm_module_obtain(arg0: Any, arg1: Any) -> ctypes._Pointer:
    return _wasm_module_obtain(arg0, arg1)  # type: ignore

_wasm_module_new = dll.wasm_module_new
_wasm_module_new.restype = ctypes.POINTER(wasm_module_t)
_wasm_module_new.argtypes = [ctypes.POINTER(wasm_store_t), ctypes.POINTER(wasm_byte_vec_t)]
def wasm_module_new(arg0: Any, binary: Any) -> ctypes._Pointer:
    return _wasm_module_new(arg0, binary)  # type: ignore

_wasm_module_validate = dll.wasm_module_validate
_wasm_module_validate.restype = ctypes.c_bool
_wasm_module_validate.argtypes = [ctypes.POINTER(wasm_store_t), ctypes.POINTER(wasm_byte_vec_t)]
def wasm_module_validate(arg0: Any, binary: Any) -> bool:
    return _wasm_module_validate(arg0, binary)  # type: ignore

_wasm_module_imports = dll.wasm_module_imports
_wasm_module_imports.restype = None
_wasm_module_imports.argtypes = [ctypes.POINTER(wasm_module_t), ctypes.POINTER(wasm_importtype_vec_t)]
def wasm_module_imports(arg0: Any, out: Any) -> None:
    return _wasm_module_imports(arg0, out)  # type: ignore

_wasm_module_exports = dll.wasm_module_exports
_wasm_module_exports.restype = None
_wasm_module_exports.argtypes = [ctypes.POINTER(wasm_module_t), ctypes.POINTER(wasm_exporttype_vec_t)]
def wasm_module_exports(arg0: Any, out: Any) -> None:
    return _wasm_module_exports(arg0, out)  # type: ignore

_wasm_module_serialize = dll.wasm_module_serialize
_wasm_module_serialize.restype = None
_wasm_module_serialize.argtypes = [ctypes.POINTER(wasm_module_t), ctypes.POINTER(wasm_byte_vec_t)]
def wasm_module_serialize(arg0: Any, out: Any) -> None:
    return _wasm_module_serialize(arg0, out)  # type: ignore

_wasm_module_deserialize = dll.wasm_module_deserialize
_wasm_module_deserialize.restype = ctypes.POINTER(wasm_module_t)
_wasm_module_deserialize.argtypes = [ctypes.POINTER(wasm_store_t), ctypes.POINTER(wasm_byte_vec_t)]
def wasm_module_deserialize(arg0: Any, arg1: Any) -> ctypes._Pointer:
    return _wasm_module_deserialize(arg0, arg1)  # type: ignore

class wasm_func_t(ctypes.Structure):
    pass

_wasm_func_delete = dll.wasm_func_delete
_wasm_func_delete.restype = None
_wasm_func_delete.argtypes = [ctypes.POINTER(wasm_func_t)]
def wasm_func_delete(arg0: Any) -> None:
    return _wasm_func_delete(arg0)  # type: ignore

_wasm_func_copy = dll.wasm_func_copy
_wasm_func_copy.restype = ctypes.POINTER(wasm_func_t)
_wasm_func_copy.argtypes = [ctypes.POINTER(wasm_func_t)]
def wasm_func_copy(arg0: Any) -> ctypes._Pointer:
    return _wasm_func_copy(arg0)  # type: ignore

_wasm_func_same = dll.wasm_func_same
_wasm_func_same.restype = ctypes.c_bool
_wasm_func_same.argtypes = [ctypes.POINTER(wasm_func_t), ctypes.POINTER(wasm_func_t)]
def wasm_func_same(arg0: Any, arg1: Any) -> bool:
    return _wasm_func_same(arg0, arg1)  # type: ignore

_wasm_func_get_host_info = dll.wasm_func_get_host_info
_wasm_func_get_host_info.restype = ctypes.c_void_p
_wasm_func_get_host_info.argtypes = [ctypes.POINTER(wasm_func_t)]
def wasm_func_get_host_info(arg0: Any) -> ctypes._Pointer:
    return _wasm_func_get_host_info(arg0)  # type: ignore

_wasm_func_set_host_info = dll.wasm_func_set_host_info
_wasm_func_set_host_info.restype = None
_wasm_func_set_host_info.argtypes = [ctypes.POINTER(wasm_func_t), ctypes.c_void_p]
def wasm_func_set_host_info(arg0: Any, arg1: Any) -> None:
    return _wasm_func_set_host_info(arg0, arg1)  # type: ignore

_wasm_func_set_host_info_with_finalizer = dll.wasm_func_set_host_info_with_finalizer
_wasm_func_set_host_info_with_finalizer.restype = None
_wasm_func_set_host_info_with_finalizer.argtypes = [ctypes.POINTER(wasm_func_t), ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p)]
def wasm_func_set_host_info_with_finalizer(arg0: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_func_set_host_info_with_finalizer(arg0, arg1, arg2)  # type: ignore

_wasm_func_as_ref = dll.wasm_func_as_ref
_wasm_func_as_ref.restype = ctypes.POINTER(wasm_ref_t)
_wasm_func_as_ref.argtypes = [ctypes.POINTER(wasm_func_t)]
def wasm_func_as_ref(arg0: Any) -> ctypes._Pointer:
    return _wasm_func_as_ref(arg0)  # type: ignore

_wasm_ref_as_func = dll.wasm_ref_as_func
_wasm_ref_as_func.restype = ctypes.POINTER(wasm_func_t)
_wasm_ref_as_func.argtypes = [ctypes.POINTER(wasm_ref_t)]
def wasm_ref_as_func(arg0: Any) -> ctypes._Pointer:
    return _wasm_ref_as_func(arg0)  # type: ignore

_wasm_func_as_ref_const = dll.wasm_func_as_ref_const
_wasm_func_as_ref_const.restype = ctypes.POINTER(wasm_ref_t)
_wasm_func_as_ref_const.argtypes = [ctypes.POINTER(wasm_func_t)]
def wasm_func_as_ref_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_func_as_ref_const(arg0)  # type: ignore

_wasm_ref_as_func_const = dll.wasm_ref_as_func_const
_wasm_ref_as_func_const.restype = ctypes.POINTER(wasm_func_t)
_wasm_ref_as_func_const.argtypes = [ctypes.POINTER(wasm_ref_t)]
def wasm_ref_as_func_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_ref_as_func_const(arg0)  # type: ignore

wasm_func_callback_t = ctypes.CFUNCTYPE(ctypes.c_size_t, ctypes.POINTER(wasm_val_vec_t), ctypes.POINTER(wasm_val_vec_t))

wasm_func_callback_with_env_t = ctypes.CFUNCTYPE(ctypes.c_size_t, ctypes.c_void_p, ctypes.POINTER(wasm_val_vec_t), ctypes.POINTER(wasm_val_vec_t))

_wasm_func_new = dll.wasm_func_new
_wasm_func_new.restype = ctypes.POINTER(wasm_func_t)
_wasm_func_new.argtypes = [ctypes.POINTER(wasm_store_t), ctypes.POINTER(wasm_functype_t), wasm_func_callback_t]
def wasm_func_new(arg0: Any, arg1: Any, arg2: Any) -> ctypes._Pointer:
    return _wasm_func_new(arg0, arg1, arg2)  # type: ignore

_wasm_func_new_with_env = dll.wasm_func_new_with_env
_wasm_func_new_with_env.restype = ctypes.POINTER(wasm_func_t)
_wasm_func_new_with_env.argtypes = [ctypes.POINTER(wasm_store_t), ctypes.POINTER(wasm_functype_t), wasm_func_callback_with_env_t, ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p)]
def wasm_func_new_with_env(arg0: Any, type: Any, arg2: Any, env: Any, finalizer: Any) -> ctypes._Pointer:
    return _wasm_func_new_with_env(arg0, type, arg2, env, finalizer)  # type: ignore

_wasm_func_type = dll.wasm_func_type
_wasm_func_type.restype = ctypes.POINTER(wasm_functype_t)
_wasm_func_type.argtypes = [ctypes.POINTER(wasm_func_t)]
def wasm_func_type(arg0: Any) -> ctypes._Pointer:
    return _wasm_func_type(arg0)  # type: ignore

_wasm_func_param_arity = dll.wasm_func_param_arity
_wasm_func_param_arity.restype = ctypes.c_size_t
_wasm_func_param_arity.argtypes = [ctypes.POINTER(wasm_func_t)]
def wasm_func_param_arity(arg0: Any) -> int:
    return _wasm_func_param_arity(arg0)  # type: ignore

_wasm_func_result_arity = dll.wasm_func_result_arity
_wasm_func_result_arity.restype = ctypes.c_size_t
_wasm_func_result_arity.argtypes = [ctypes.POINTER(wasm_func_t)]
def wasm_func_result_arity(arg0: Any) -> int:
    return _wasm_func_result_arity(arg0)  # type: ignore

_wasm_func_call = dll.wasm_func_call
_wasm_func_call.restype = ctypes.POINTER(wasm_trap_t)
_wasm_func_call.argtypes = [ctypes.POINTER(wasm_func_t), ctypes.POINTER(wasm_val_vec_t), ctypes.POINTER(wasm_val_vec_t)]
def wasm_func_call(arg0: Any, args: Any, results: Any) -> ctypes._Pointer:
    return _wasm_func_call(arg0, args, results)  # type: ignore

class wasm_global_t(ctypes.Structure):
    pass

_wasm_global_delete = dll.wasm_global_delete
_wasm_global_delete.restype = None
_wasm_global_delete.argtypes = [ctypes.POINTER(wasm_global_t)]
def wasm_global_delete(arg0: Any) -> None:
    return _wasm_global_delete(arg0)  # type: ignore

_wasm_global_copy = dll.wasm_global_copy
_wasm_global_copy.restype = ctypes.POINTER(wasm_global_t)
_wasm_global_copy.argtypes = [ctypes.POINTER(wasm_global_t)]
def wasm_global_copy(arg0: Any) -> ctypes._Pointer:
    return _wasm_global_copy(arg0)  # type: ignore

_wasm_global_same = dll.wasm_global_same
_wasm_global_same.restype = ctypes.c_bool
_wasm_global_same.argtypes = [ctypes.POINTER(wasm_global_t), ctypes.POINTER(wasm_global_t)]
def wasm_global_same(arg0: Any, arg1: Any) -> bool:
    return _wasm_global_same(arg0, arg1)  # type: ignore

_wasm_global_get_host_info = dll.wasm_global_get_host_info
_wasm_global_get_host_info.restype = ctypes.c_void_p
_wasm_global_get_host_info.argtypes = [ctypes.POINTER(wasm_global_t)]
def wasm_global_get_host_info(arg0: Any) -> ctypes._Pointer:
    return _wasm_global_get_host_info(arg0)  # type: ignore

_wasm_global_set_host_info = dll.wasm_global_set_host_info
_wasm_global_set_host_info.restype = None
_wasm_global_set_host_info.argtypes = [ctypes.POINTER(wasm_global_t), ctypes.c_void_p]
def wasm_global_set_host_info(arg0: Any, arg1: Any) -> None:
    return _wasm_global_set_host_info(arg0, arg1)  # type: ignore

_wasm_global_set_host_info_with_finalizer = dll.wasm_global_set_host_info_with_finalizer
_wasm_global_set_host_info_with_finalizer.restype = None
_wasm_global_set_host_info_with_finalizer.argtypes = [ctypes.POINTER(wasm_global_t), ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p)]
def wasm_global_set_host_info_with_finalizer(arg0: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_global_set_host_info_with_finalizer(arg0, arg1, arg2)  # type: ignore

_wasm_global_as_ref = dll.wasm_global_as_ref
_wasm_global_as_ref.restype = ctypes.POINTER(wasm_ref_t)
_wasm_global_as_ref.argtypes = [ctypes.POINTER(wasm_global_t)]
def wasm_global_as_ref(arg0: Any) -> ctypes._Pointer:
    return _wasm_global_as_ref(arg0)  # type: ignore

_wasm_ref_as_global = dll.wasm_ref_as_global
_wasm_ref_as_global.restype = ctypes.POINTER(wasm_global_t)
_wasm_ref_as_global.argtypes = [ctypes.POINTER(wasm_ref_t)]
def wasm_ref_as_global(arg0: Any) -> ctypes._Pointer:
    return _wasm_ref_as_global(arg0)  # type: ignore

_wasm_global_as_ref_const = dll.wasm_global_as_ref_const
_wasm_global_as_ref_const.restype = ctypes.POINTER(wasm_ref_t)
_wasm_global_as_ref_const.argtypes = [ctypes.POINTER(wasm_global_t)]
def wasm_global_as_ref_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_global_as_ref_const(arg0)  # type: ignore

_wasm_ref_as_global_const = dll.wasm_ref_as_global_const
_wasm_ref_as_global_const.restype = ctypes.POINTER(wasm_global_t)
_wasm_ref_as_global_const.argtypes = [ctypes.POINTER(wasm_ref_t)]
def wasm_ref_as_global_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_ref_as_global_const(arg0)  # type: ignore

_wasm_global_new = dll.wasm_global_new
_wasm_global_new.restype = ctypes.POINTER(wasm_global_t)
_wasm_global_new.argtypes = [ctypes.POINTER(wasm_store_t), ctypes.POINTER(wasm_globaltype_t), ctypes.POINTER(wasm_val_t)]
def wasm_global_new(arg0: Any, arg1: Any, arg2: Any) -> ctypes._Pointer:
    return _wasm_global_new(arg0, arg1, arg2)  # type: ignore

_wasm_global_type = dll.wasm_global_type
_wasm_global_type.restype = ctypes.POINTER(wasm_globaltype_t)
_wasm_global_type.argtypes = [ctypes.POINTER(wasm_global_t)]
def wasm_global_type(arg0: Any) -> ctypes._Pointer:
    return _wasm_global_type(arg0)  # type: ignore

_wasm_global_get = dll.wasm_global_get
_wasm_global_get.restype = None
_wasm_global_get.argtypes = [ctypes.POINTER(wasm_global_t), ctypes.POINTER(wasm_val_t)]
def wasm_global_get(arg0: Any, out: Any) -> None:
    return _wasm_global_get(arg0, out)  # type: ignore

_wasm_global_set = dll.wasm_global_set
_wasm_global_set.restype = None
_wasm_global_set.argtypes = [ctypes.POINTER(wasm_global_t), ctypes.POINTER(wasm_val_t)]
def wasm_global_set(arg0: Any, arg1: Any) -> None:
    return _wasm_global_set(arg0, arg1)  # type: ignore

class wasm_table_t(ctypes.Structure):
    pass

_wasm_table_delete = dll.wasm_table_delete
_wasm_table_delete.restype = None
_wasm_table_delete.argtypes = [ctypes.POINTER(wasm_table_t)]
def wasm_table_delete(arg0: Any) -> None:
    return _wasm_table_delete(arg0)  # type: ignore

_wasm_table_copy = dll.wasm_table_copy
_wasm_table_copy.restype = ctypes.POINTER(wasm_table_t)
_wasm_table_copy.argtypes = [ctypes.POINTER(wasm_table_t)]
def wasm_table_copy(arg0: Any) -> ctypes._Pointer:
    return _wasm_table_copy(arg0)  # type: ignore

_wasm_table_same = dll.wasm_table_same
_wasm_table_same.restype = ctypes.c_bool
_wasm_table_same.argtypes = [ctypes.POINTER(wasm_table_t), ctypes.POINTER(wasm_table_t)]
def wasm_table_same(arg0: Any, arg1: Any) -> bool:
    return _wasm_table_same(arg0, arg1)  # type: ignore

_wasm_table_get_host_info = dll.wasm_table_get_host_info
_wasm_table_get_host_info.restype = ctypes.c_void_p
_wasm_table_get_host_info.argtypes = [ctypes.POINTER(wasm_table_t)]
def wasm_table_get_host_info(arg0: Any) -> ctypes._Pointer:
    return _wasm_table_get_host_info(arg0)  # type: ignore

_wasm_table_set_host_info = dll.wasm_table_set_host_info
_wasm_table_set_host_info.restype = None
_wasm_table_set_host_info.argtypes = [ctypes.POINTER(wasm_table_t), ctypes.c_void_p]
def wasm_table_set_host_info(arg0: Any, arg1: Any) -> None:
    return _wasm_table_set_host_info(arg0, arg1)  # type: ignore

_wasm_table_set_host_info_with_finalizer = dll.wasm_table_set_host_info_with_finalizer
_wasm_table_set_host_info_with_finalizer.restype = None
_wasm_table_set_host_info_with_finalizer.argtypes = [ctypes.POINTER(wasm_table_t), ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p)]
def wasm_table_set_host_info_with_finalizer(arg0: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_table_set_host_info_with_finalizer(arg0, arg1, arg2)  # type: ignore

_wasm_table_as_ref = dll.wasm_table_as_ref
_wasm_table_as_ref.restype = ctypes.POINTER(wasm_ref_t)
_wasm_table_as_ref.argtypes = [ctypes.POINTER(wasm_table_t)]
def wasm_table_as_ref(arg0: Any) -> ctypes._Pointer:
    return _wasm_table_as_ref(arg0)  # type: ignore

_wasm_ref_as_table = dll.wasm_ref_as_table
_wasm_ref_as_table.restype = ctypes.POINTER(wasm_table_t)
_wasm_ref_as_table.argtypes = [ctypes.POINTER(wasm_ref_t)]
def wasm_ref_as_table(arg0: Any) -> ctypes._Pointer:
    return _wasm_ref_as_table(arg0)  # type: ignore

_wasm_table_as_ref_const = dll.wasm_table_as_ref_const
_wasm_table_as_ref_const.restype = ctypes.POINTER(wasm_ref_t)
_wasm_table_as_ref_const.argtypes = [ctypes.POINTER(wasm_table_t)]
def wasm_table_as_ref_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_table_as_ref_const(arg0)  # type: ignore

_wasm_ref_as_table_const = dll.wasm_ref_as_table_const
_wasm_ref_as_table_const.restype = ctypes.POINTER(wasm_table_t)
_wasm_ref_as_table_const.argtypes = [ctypes.POINTER(wasm_ref_t)]
def wasm_ref_as_table_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_ref_as_table_const(arg0)  # type: ignore

wasm_table_size_t = ctypes.c_uint32

_wasm_table_new = dll.wasm_table_new
_wasm_table_new.restype = ctypes.POINTER(wasm_table_t)
_wasm_table_new.argtypes = [ctypes.POINTER(wasm_store_t), ctypes.POINTER(wasm_tabletype_t), ctypes.POINTER(wasm_ref_t)]
def wasm_table_new(arg0: Any, arg1: Any, init: Any) -> ctypes._Pointer:
    return _wasm_table_new(arg0, arg1, init)  # type: ignore

_wasm_table_type = dll.wasm_table_type
_wasm_table_type.restype = ctypes.POINTER(wasm_tabletype_t)
_wasm_table_type.argtypes = [ctypes.POINTER(wasm_table_t)]
def wasm_table_type(arg0: Any) -> ctypes._Pointer:
    return _wasm_table_type(arg0)  # type: ignore

_wasm_table_get = dll.wasm_table_get
_wasm_table_get.restype = ctypes.POINTER(wasm_ref_t)
_wasm_table_get.argtypes = [ctypes.POINTER(wasm_table_t), wasm_table_size_t]
def wasm_table_get(arg0: Any, index: Any) -> ctypes._Pointer:
    return _wasm_table_get(arg0, index)  # type: ignore

_wasm_table_set = dll.wasm_table_set
_wasm_table_set.restype = ctypes.c_bool
_wasm_table_set.argtypes = [ctypes.POINTER(wasm_table_t), wasm_table_size_t, ctypes.POINTER(wasm_ref_t)]
def wasm_table_set(arg0: Any, index: Any, arg2: Any) -> bool:
    return _wasm_table_set(arg0, index, arg2)  # type: ignore

_wasm_table_size = dll.wasm_table_size
_wasm_table_size.restype = wasm_table_size_t
_wasm_table_size.argtypes = [ctypes.POINTER(wasm_table_t)]
def wasm_table_size(arg0: Any) -> int:
    return _wasm_table_size(arg0)  # type: ignore

_wasm_table_grow = dll.wasm_table_grow
_wasm_table_grow.restype = ctypes.c_bool
_wasm_table_grow.argtypes = [ctypes.POINTER(wasm_table_t), wasm_table_size_t, ctypes.POINTER(wasm_ref_t)]
def wasm_table_grow(arg0: Any, delta: Any, init: Any) -> bool:
    return _wasm_table_grow(arg0, delta, init)  # type: ignore

class wasm_memory_t(ctypes.Structure):
    pass

_wasm_memory_delete = dll.wasm_memory_delete
_wasm_memory_delete.restype = None
_wasm_memory_delete.argtypes = [ctypes.POINTER(wasm_memory_t)]
def wasm_memory_delete(arg0: Any) -> None:
    return _wasm_memory_delete(arg0)  # type: ignore

_wasm_memory_copy = dll.wasm_memory_copy
_wasm_memory_copy.restype = ctypes.POINTER(wasm_memory_t)
_wasm_memory_copy.argtypes = [ctypes.POINTER(wasm_memory_t)]
def wasm_memory_copy(arg0: Any) -> ctypes._Pointer:
    return _wasm_memory_copy(arg0)  # type: ignore

_wasm_memory_same = dll.wasm_memory_same
_wasm_memory_same.restype = ctypes.c_bool
_wasm_memory_same.argtypes = [ctypes.POINTER(wasm_memory_t), ctypes.POINTER(wasm_memory_t)]
def wasm_memory_same(arg0: Any, arg1: Any) -> bool:
    return _wasm_memory_same(arg0, arg1)  # type: ignore

_wasm_memory_get_host_info = dll.wasm_memory_get_host_info
_wasm_memory_get_host_info.restype = ctypes.c_void_p
_wasm_memory_get_host_info.argtypes = [ctypes.POINTER(wasm_memory_t)]
def wasm_memory_get_host_info(arg0: Any) -> ctypes._Pointer:
    return _wasm_memory_get_host_info(arg0)  # type: ignore

_wasm_memory_set_host_info = dll.wasm_memory_set_host_info
_wasm_memory_set_host_info.restype = None
_wasm_memory_set_host_info.argtypes = [ctypes.POINTER(wasm_memory_t), ctypes.c_void_p]
def wasm_memory_set_host_info(arg0: Any, arg1: Any) -> None:
    return _wasm_memory_set_host_info(arg0, arg1)  # type: ignore

_wasm_memory_set_host_info_with_finalizer = dll.wasm_memory_set_host_info_with_finalizer
_wasm_memory_set_host_info_with_finalizer.restype = None
_wasm_memory_set_host_info_with_finalizer.argtypes = [ctypes.POINTER(wasm_memory_t), ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p)]
def wasm_memory_set_host_info_with_finalizer(arg0: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_memory_set_host_info_with_finalizer(arg0, arg1, arg2)  # type: ignore

_wasm_memory_as_ref = dll.wasm_memory_as_ref
_wasm_memory_as_ref.restype = ctypes.POINTER(wasm_ref_t)
_wasm_memory_as_ref.argtypes = [ctypes.POINTER(wasm_memory_t)]
def wasm_memory_as_ref(arg0: Any) -> ctypes._Pointer:
    return _wasm_memory_as_ref(arg0)  # type: ignore

_wasm_ref_as_memory = dll.wasm_ref_as_memory
_wasm_ref_as_memory.restype = ctypes.POINTER(wasm_memory_t)
_wasm_ref_as_memory.argtypes = [ctypes.POINTER(wasm_ref_t)]
def wasm_ref_as_memory(arg0: Any) -> ctypes._Pointer:
    return _wasm_ref_as_memory(arg0)  # type: ignore

_wasm_memory_as_ref_const = dll.wasm_memory_as_ref_const
_wasm_memory_as_ref_const.restype = ctypes.POINTER(wasm_ref_t)
_wasm_memory_as_ref_const.argtypes = [ctypes.POINTER(wasm_memory_t)]
def wasm_memory_as_ref_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_memory_as_ref_const(arg0)  # type: ignore

_wasm_ref_as_memory_const = dll.wasm_ref_as_memory_const
_wasm_ref_as_memory_const.restype = ctypes.POINTER(wasm_memory_t)
_wasm_ref_as_memory_const.argtypes = [ctypes.POINTER(wasm_ref_t)]
def wasm_ref_as_memory_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_ref_as_memory_const(arg0)  # type: ignore

wasm_memory_pages_t = ctypes.c_uint32

_wasm_memory_new = dll.wasm_memory_new
_wasm_memory_new.restype = ctypes.POINTER(wasm_memory_t)
_wasm_memory_new.argtypes = [ctypes.POINTER(wasm_store_t), ctypes.POINTER(wasm_memorytype_t)]
def wasm_memory_new(arg0: Any, arg1: Any) -> ctypes._Pointer:
    return _wasm_memory_new(arg0, arg1)  # type: ignore

_wasm_memory_type = dll.wasm_memory_type
_wasm_memory_type.restype = ctypes.POINTER(wasm_memorytype_t)
_wasm_memory_type.argtypes = [ctypes.POINTER(wasm_memory_t)]
def wasm_memory_type(arg0: Any) -> ctypes._Pointer:
    return _wasm_memory_type(arg0)  # type: ignore

_wasm_memory_data = dll.wasm_memory_data
_wasm_memory_data.restype = ctypes.POINTER(ctypes.c_ubyte)
_wasm_memory_data.argtypes = [ctypes.POINTER(wasm_memory_t)]
def wasm_memory_data(arg0: Any) -> ctypes._Pointer:
    return _wasm_memory_data(arg0)  # type: ignore

_wasm_memory_data_size = dll.wasm_memory_data_size
_wasm_memory_data_size.restype = ctypes.c_size_t
_wasm_memory_data_size.argtypes = [ctypes.POINTER(wasm_memory_t)]
def wasm_memory_data_size(arg0: Any) -> int:
    return _wasm_memory_data_size(arg0)  # type: ignore

_wasm_memory_size = dll.wasm_memory_size
_wasm_memory_size.restype = wasm_memory_pages_t
_wasm_memory_size.argtypes = [ctypes.POINTER(wasm_memory_t)]
def wasm_memory_size(arg0: Any) -> int:
    return _wasm_memory_size(arg0)  # type: ignore

_wasm_memory_grow = dll.wasm_memory_grow
_wasm_memory_grow.restype = ctypes.c_bool
_wasm_memory_grow.argtypes = [ctypes.POINTER(wasm_memory_t), wasm_memory_pages_t]
def wasm_memory_grow(arg0: Any, delta: Any) -> bool:
    return _wasm_memory_grow(arg0, delta)  # type: ignore

class wasm_extern_t(ctypes.Structure):
    pass

_wasm_extern_delete = dll.wasm_extern_delete
_wasm_extern_delete.restype = None
_wasm_extern_delete.argtypes = [ctypes.POINTER(wasm_extern_t)]
def wasm_extern_delete(arg0: Any) -> None:
    return _wasm_extern_delete(arg0)  # type: ignore

_wasm_extern_copy = dll.wasm_extern_copy
_wasm_extern_copy.restype = ctypes.POINTER(wasm_extern_t)
_wasm_extern_copy.argtypes = [ctypes.POINTER(wasm_extern_t)]
def wasm_extern_copy(arg0: Any) -> ctypes._Pointer:
    return _wasm_extern_copy(arg0)  # type: ignore

_wasm_extern_same = dll.wasm_extern_same
_wasm_extern_same.restype = ctypes.c_bool
_wasm_extern_same.argtypes = [ctypes.POINTER(wasm_extern_t), ctypes.POINTER(wasm_extern_t)]
def wasm_extern_same(arg0: Any, arg1: Any) -> bool:
    return _wasm_extern_same(arg0, arg1)  # type: ignore

_wasm_extern_get_host_info = dll.wasm_extern_get_host_info
_wasm_extern_get_host_info.restype = ctypes.c_void_p
_wasm_extern_get_host_info.argtypes = [ctypes.POINTER(wasm_extern_t)]
def wasm_extern_get_host_info(arg0: Any) -> ctypes._Pointer:
    return _wasm_extern_get_host_info(arg0)  # type: ignore

_wasm_extern_set_host_info = dll.wasm_extern_set_host_info
_wasm_extern_set_host_info.restype = None
_wasm_extern_set_host_info.argtypes = [ctypes.POINTER(wasm_extern_t), ctypes.c_void_p]
def wasm_extern_set_host_info(arg0: Any, arg1: Any) -> None:
    return _wasm_extern_set_host_info(arg0, arg1)  # type: ignore

_wasm_extern_set_host_info_with_finalizer = dll.wasm_extern_set_host_info_with_finalizer
_wasm_extern_set_host_info_with_finalizer.restype = None
_wasm_extern_set_host_info_with_finalizer.argtypes = [ctypes.POINTER(wasm_extern_t), ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p)]
def wasm_extern_set_host_info_with_finalizer(arg0: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_extern_set_host_info_with_finalizer(arg0, arg1, arg2)  # type: ignore

_wasm_extern_as_ref = dll.wasm_extern_as_ref
_wasm_extern_as_ref.restype = ctypes.POINTER(wasm_ref_t)
_wasm_extern_as_ref.argtypes = [ctypes.POINTER(wasm_extern_t)]
def wasm_extern_as_ref(arg0: Any) -> ctypes._Pointer:
    return _wasm_extern_as_ref(arg0)  # type: ignore

_wasm_ref_as_extern = dll.wasm_ref_as_extern
_wasm_ref_as_extern.restype = ctypes.POINTER(wasm_extern_t)
_wasm_ref_as_extern.argtypes = [ctypes.POINTER(wasm_ref_t)]
def wasm_ref_as_extern(arg0: Any) -> ctypes._Pointer:
    return _wasm_ref_as_extern(arg0)  # type: ignore

_wasm_extern_as_ref_const = dll.wasm_extern_as_ref_const
_wasm_extern_as_ref_const.restype = ctypes.POINTER(wasm_ref_t)
_wasm_extern_as_ref_const.argtypes = [ctypes.POINTER(wasm_extern_t)]
def wasm_extern_as_ref_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_extern_as_ref_const(arg0)  # type: ignore

_wasm_ref_as_extern_const = dll.wasm_ref_as_extern_const
_wasm_ref_as_extern_const.restype = ctypes.POINTER(wasm_extern_t)
_wasm_ref_as_extern_const.argtypes = [ctypes.POINTER(wasm_ref_t)]
def wasm_ref_as_extern_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_ref_as_extern_const(arg0)  # type: ignore

class wasm_extern_vec_t(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_size_t),
        ("data", ctypes.POINTER(ctypes.POINTER(wasm_extern_t))),
    ]
    size: int
    data: ctypes._Pointer

_wasm_extern_vec_new_empty = dll.wasm_extern_vec_new_empty
_wasm_extern_vec_new_empty.restype = None
_wasm_extern_vec_new_empty.argtypes = [ctypes.POINTER(wasm_extern_vec_t)]
def wasm_extern_vec_new_empty(out: Any) -> None:
    return _wasm_extern_vec_new_empty(out)  # type: ignore

_wasm_extern_vec_new_uninitialized = dll.wasm_extern_vec_new_uninitialized
_wasm_extern_vec_new_uninitialized.restype = None
_wasm_extern_vec_new_uninitialized.argtypes = [ctypes.POINTER(wasm_extern_vec_t), ctypes.c_size_t]
def wasm_extern_vec_new_uninitialized(out: Any, arg1: Any) -> None:
    return _wasm_extern_vec_new_uninitialized(out, arg1)  # type: ignore

_wasm_extern_vec_new = dll.wasm_extern_vec_new
_wasm_extern_vec_new.restype = None
_wasm_extern_vec_new.argtypes = [ctypes.POINTER(wasm_extern_vec_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(wasm_extern_t))]
def wasm_extern_vec_new(out: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_extern_vec_new(out, arg1, arg2)  # type: ignore

_wasm_extern_vec_copy = dll.wasm_extern_vec_copy
_wasm_extern_vec_copy.restype = None
_wasm_extern_vec_copy.argtypes = [ctypes.POINTER(wasm_extern_vec_t), ctypes.POINTER(wasm_extern_vec_t)]
def wasm_extern_vec_copy(out: Any, arg1: Any) -> None:
    return _wasm_extern_vec_copy(out, arg1)  # type: ignore

_wasm_extern_vec_delete = dll.wasm_extern_vec_delete
_wasm_extern_vec_delete.restype = None
_wasm_extern_vec_delete.argtypes = [ctypes.POINTER(wasm_extern_vec_t)]
def wasm_extern_vec_delete(arg0: Any) -> None:
    return _wasm_extern_vec_delete(arg0)  # type: ignore

_wasm_extern_kind = dll.wasm_extern_kind
_wasm_extern_kind.restype = wasm_externkind_t
_wasm_extern_kind.argtypes = [ctypes.POINTER(wasm_extern_t)]
def wasm_extern_kind(arg0: Any) -> wasm_externkind_t:
    return _wasm_extern_kind(arg0)  # type: ignore

_wasm_extern_type = dll.wasm_extern_type
_wasm_extern_type.restype = ctypes.POINTER(wasm_externtype_t)
_wasm_extern_type.argtypes = [ctypes.POINTER(wasm_extern_t)]
def wasm_extern_type(arg0: Any) -> ctypes._Pointer:
    return _wasm_extern_type(arg0)  # type: ignore

_wasm_func_as_extern = dll.wasm_func_as_extern
_wasm_func_as_extern.restype = ctypes.POINTER(wasm_extern_t)
_wasm_func_as_extern.argtypes = [ctypes.POINTER(wasm_func_t)]
def wasm_func_as_extern(arg0: Any) -> ctypes._Pointer:
    return _wasm_func_as_extern(arg0)  # type: ignore

_wasm_global_as_extern = dll.wasm_global_as_extern
_wasm_global_as_extern.restype = ctypes.POINTER(wasm_extern_t)
_wasm_global_as_extern.argtypes = [ctypes.POINTER(wasm_global_t)]
def wasm_global_as_extern(arg0: Any) -> ctypes._Pointer:
    return _wasm_global_as_extern(arg0)  # type: ignore

_wasm_table_as_extern = dll.wasm_table_as_extern
_wasm_table_as_extern.restype = ctypes.POINTER(wasm_extern_t)
_wasm_table_as_extern.argtypes = [ctypes.POINTER(wasm_table_t)]
def wasm_table_as_extern(arg0: Any) -> ctypes._Pointer:
    return _wasm_table_as_extern(arg0)  # type: ignore

_wasm_memory_as_extern = dll.wasm_memory_as_extern
_wasm_memory_as_extern.restype = ctypes.POINTER(wasm_extern_t)
_wasm_memory_as_extern.argtypes = [ctypes.POINTER(wasm_memory_t)]
def wasm_memory_as_extern(arg0: Any) -> ctypes._Pointer:
    return _wasm_memory_as_extern(arg0)  # type: ignore

_wasm_extern_as_func = dll.wasm_extern_as_func
_wasm_extern_as_func.restype = ctypes.POINTER(wasm_func_t)
_wasm_extern_as_func.argtypes = [ctypes.POINTER(wasm_extern_t)]
def wasm_extern_as_func(arg0: Any) -> ctypes._Pointer:
    return _wasm_extern_as_func(arg0)  # type: ignore

_wasm_extern_as_global = dll.wasm_extern_as_global
_wasm_extern_as_global.restype = ctypes.POINTER(wasm_global_t)
_wasm_extern_as_global.argtypes = [ctypes.POINTER(wasm_extern_t)]
def wasm_extern_as_global(arg0: Any) -> ctypes._Pointer:
    return _wasm_extern_as_global(arg0)  # type: ignore

_wasm_extern_as_table = dll.wasm_extern_as_table
_wasm_extern_as_table.restype = ctypes.POINTER(wasm_table_t)
_wasm_extern_as_table.argtypes = [ctypes.POINTER(wasm_extern_t)]
def wasm_extern_as_table(arg0: Any) -> ctypes._Pointer:
    return _wasm_extern_as_table(arg0)  # type: ignore

_wasm_extern_as_memory = dll.wasm_extern_as_memory
_wasm_extern_as_memory.restype = ctypes.POINTER(wasm_memory_t)
_wasm_extern_as_memory.argtypes = [ctypes.POINTER(wasm_extern_t)]
def wasm_extern_as_memory(arg0: Any) -> ctypes._Pointer:
    return _wasm_extern_as_memory(arg0)  # type: ignore

_wasm_func_as_extern_const = dll.wasm_func_as_extern_const
_wasm_func_as_extern_const.restype = ctypes.POINTER(wasm_extern_t)
_wasm_func_as_extern_const.argtypes = [ctypes.POINTER(wasm_func_t)]
def wasm_func_as_extern_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_func_as_extern_const(arg0)  # type: ignore

_wasm_global_as_extern_const = dll.wasm_global_as_extern_const
_wasm_global_as_extern_const.restype = ctypes.POINTER(wasm_extern_t)
_wasm_global_as_extern_const.argtypes = [ctypes.POINTER(wasm_global_t)]
def wasm_global_as_extern_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_global_as_extern_const(arg0)  # type: ignore

_wasm_table_as_extern_const = dll.wasm_table_as_extern_const
_wasm_table_as_extern_const.restype = ctypes.POINTER(wasm_extern_t)
_wasm_table_as_extern_const.argtypes = [ctypes.POINTER(wasm_table_t)]
def wasm_table_as_extern_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_table_as_extern_const(arg0)  # type: ignore

_wasm_memory_as_extern_const = dll.wasm_memory_as_extern_const
_wasm_memory_as_extern_const.restype = ctypes.POINTER(wasm_extern_t)
_wasm_memory_as_extern_const.argtypes = [ctypes.POINTER(wasm_memory_t)]
def wasm_memory_as_extern_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_memory_as_extern_const(arg0)  # type: ignore

_wasm_extern_as_func_const = dll.wasm_extern_as_func_const
_wasm_extern_as_func_const.restype = ctypes.POINTER(wasm_func_t)
_wasm_extern_as_func_const.argtypes = [ctypes.POINTER(wasm_extern_t)]
def wasm_extern_as_func_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_extern_as_func_const(arg0)  # type: ignore

_wasm_extern_as_global_const = dll.wasm_extern_as_global_const
_wasm_extern_as_global_const.restype = ctypes.POINTER(wasm_global_t)
_wasm_extern_as_global_const.argtypes = [ctypes.POINTER(wasm_extern_t)]
def wasm_extern_as_global_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_extern_as_global_const(arg0)  # type: ignore

_wasm_extern_as_table_const = dll.wasm_extern_as_table_const
_wasm_extern_as_table_const.restype = ctypes.POINTER(wasm_table_t)
_wasm_extern_as_table_const.argtypes = [ctypes.POINTER(wasm_extern_t)]
def wasm_extern_as_table_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_extern_as_table_const(arg0)  # type: ignore

_wasm_extern_as_memory_const = dll.wasm_extern_as_memory_const
_wasm_extern_as_memory_const.restype = ctypes.POINTER(wasm_memory_t)
_wasm_extern_as_memory_const.argtypes = [ctypes.POINTER(wasm_extern_t)]
def wasm_extern_as_memory_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_extern_as_memory_const(arg0)  # type: ignore

class wasm_instance_t(ctypes.Structure):
    pass

_wasm_instance_delete = dll.wasm_instance_delete
_wasm_instance_delete.restype = None
_wasm_instance_delete.argtypes = [ctypes.POINTER(wasm_instance_t)]
def wasm_instance_delete(arg0: Any) -> None:
    return _wasm_instance_delete(arg0)  # type: ignore

_wasm_instance_copy = dll.wasm_instance_copy
_wasm_instance_copy.restype = ctypes.POINTER(wasm_instance_t)
_wasm_instance_copy.argtypes = [ctypes.POINTER(wasm_instance_t)]
def wasm_instance_copy(arg0: Any) -> ctypes._Pointer:
    return _wasm_instance_copy(arg0)  # type: ignore

_wasm_instance_same = dll.wasm_instance_same
_wasm_instance_same.restype = ctypes.c_bool
_wasm_instance_same.argtypes = [ctypes.POINTER(wasm_instance_t), ctypes.POINTER(wasm_instance_t)]
def wasm_instance_same(arg0: Any, arg1: Any) -> bool:
    return _wasm_instance_same(arg0, arg1)  # type: ignore

_wasm_instance_get_host_info = dll.wasm_instance_get_host_info
_wasm_instance_get_host_info.restype = ctypes.c_void_p
_wasm_instance_get_host_info.argtypes = [ctypes.POINTER(wasm_instance_t)]
def wasm_instance_get_host_info(arg0: Any) -> ctypes._Pointer:
    return _wasm_instance_get_host_info(arg0)  # type: ignore

_wasm_instance_set_host_info = dll.wasm_instance_set_host_info
_wasm_instance_set_host_info.restype = None
_wasm_instance_set_host_info.argtypes = [ctypes.POINTER(wasm_instance_t), ctypes.c_void_p]
def wasm_instance_set_host_info(arg0: Any, arg1: Any) -> None:
    return _wasm_instance_set_host_info(arg0, arg1)  # type: ignore

_wasm_instance_set_host_info_with_finalizer = dll.wasm_instance_set_host_info_with_finalizer
_wasm_instance_set_host_info_with_finalizer.restype = None
_wasm_instance_set_host_info_with_finalizer.argtypes = [ctypes.POINTER(wasm_instance_t), ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p)]
def wasm_instance_set_host_info_with_finalizer(arg0: Any, arg1: Any, arg2: Any) -> None:
    return _wasm_instance_set_host_info_with_finalizer(arg0, arg1, arg2)  # type: ignore

_wasm_instance_as_ref = dll.wasm_instance_as_ref
_wasm_instance_as_ref.restype = ctypes.POINTER(wasm_ref_t)
_wasm_instance_as_ref.argtypes = [ctypes.POINTER(wasm_instance_t)]
def wasm_instance_as_ref(arg0: Any) -> ctypes._Pointer:
    return _wasm_instance_as_ref(arg0)  # type: ignore

_wasm_ref_as_instance = dll.wasm_ref_as_instance
_wasm_ref_as_instance.restype = ctypes.POINTER(wasm_instance_t)
_wasm_ref_as_instance.argtypes = [ctypes.POINTER(wasm_ref_t)]
def wasm_ref_as_instance(arg0: Any) -> ctypes._Pointer:
    return _wasm_ref_as_instance(arg0)  # type: ignore

_wasm_instance_as_ref_const = dll.wasm_instance_as_ref_const
_wasm_instance_as_ref_const.restype = ctypes.POINTER(wasm_ref_t)
_wasm_instance_as_ref_const.argtypes = [ctypes.POINTER(wasm_instance_t)]
def wasm_instance_as_ref_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_instance_as_ref_const(arg0)  # type: ignore

_wasm_ref_as_instance_const = dll.wasm_ref_as_instance_const
_wasm_ref_as_instance_const.restype = ctypes.POINTER(wasm_instance_t)
_wasm_ref_as_instance_const.argtypes = [ctypes.POINTER(wasm_ref_t)]
def wasm_ref_as_instance_const(arg0: Any) -> ctypes._Pointer:
    return _wasm_ref_as_instance_const(arg0)  # type: ignore

_wasm_instance_new = dll.wasm_instance_new
_wasm_instance_new.restype = ctypes.POINTER(wasm_instance_t)
_wasm_instance_new.argtypes = [ctypes.POINTER(wasm_store_t), ctypes.POINTER(wasm_module_t), ctypes.POINTER(wasm_extern_vec_t), ctypes.POINTER(ctypes.POINTER(wasm_trap_t))]
def wasm_instance_new(arg0: Any, arg1: Any, imports: Any, arg3: Any) -> ctypes._Pointer:
    return _wasm_instance_new(arg0, arg1, imports, arg3)  # type: ignore

_wasm_instance_exports = dll.wasm_instance_exports
_wasm_instance_exports.restype = None
_wasm_instance_exports.argtypes = [ctypes.POINTER(wasm_instance_t), ctypes.POINTER(wasm_extern_vec_t)]
def wasm_instance_exports(arg0: Any, out: Any) -> None:
    return _wasm_instance_exports(arg0, out)  # type: ignore

class wasi_config_t(ctypes.Structure):
    pass

_wasi_config_delete = dll.wasi_config_delete
_wasi_config_delete.restype = None
_wasi_config_delete.argtypes = [ctypes.POINTER(wasi_config_t)]
def wasi_config_delete(arg0: Any) -> None:
    return _wasi_config_delete(arg0)  # type: ignore

_wasi_config_new = dll.wasi_config_new
_wasi_config_new.restype = ctypes.POINTER(wasi_config_t)
_wasi_config_new.argtypes = []
def wasi_config_new() -> ctypes._Pointer:
    return _wasi_config_new()  # type: ignore

_wasi_config_inherit_network = dll.wasi_config_inherit_network
_wasi_config_inherit_network.restype = None
_wasi_config_inherit_network.argtypes = [ctypes.POINTER(wasi_config_t)]
def wasi_config_inherit_network(config: Any) -> None:
    return _wasi_config_inherit_network(config)  # type: ignore

_wasi_config_allow_ip_name_lookup = dll.wasi_config_allow_ip_name_lookup
_wasi_config_allow_ip_name_lookup.restype = None
_wasi_config_allow_ip_name_lookup.argtypes = [ctypes.POINTER(wasi_config_t), ctypes.c_bool]
def wasi_config_allow_ip_name_lookup(config: Any, enable: Any) -> None:
    return _wasi_config_allow_ip_name_lookup(config, enable)  # type: ignore

_wasi_config_set_argv = dll.wasi_config_set_argv
_wasi_config_set_argv.restype = ctypes.c_bool
_wasi_config_set_argv.argtypes = [ctypes.POINTER(wasi_config_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(ctypes.c_char))]
def wasi_config_set_argv(config: Any, argc: Any, argv: Any) -> bool:
    return _wasi_config_set_argv(config, argc, argv)  # type: ignore

_wasi_config_inherit_argv = dll.wasi_config_inherit_argv
_wasi_config_inherit_argv.restype = None
_wasi_config_inherit_argv.argtypes = [ctypes.POINTER(wasi_config_t)]
def wasi_config_inherit_argv(config: Any) -> None:
    return _wasi_config_inherit_argv(config)  # type: ignore

_wasi_config_set_env = dll.wasi_config_set_env
_wasi_config_set_env.restype = ctypes.c_bool
_wasi_config_set_env.argtypes = [ctypes.POINTER(wasi_config_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(ctypes.c_char)), ctypes.POINTER(ctypes.POINTER(ctypes.c_char))]
def wasi_config_set_env(config: Any, envc: Any, names: Any, values: Any) -> bool:
    return _wasi_config_set_env(config, envc, names, values)  # type: ignore

_wasi_config_inherit_env = dll.wasi_config_inherit_env
_wasi_config_inherit_env.restype = None
_wasi_config_inherit_env.argtypes = [ctypes.POINTER(wasi_config_t)]
def wasi_config_inherit_env(config: Any) -> None:
    return _wasi_config_inherit_env(config)  # type: ignore

_wasi_config_set_stdin_file = dll.wasi_config_set_stdin_file
_wasi_config_set_stdin_file.restype = ctypes.c_bool
_wasi_config_set_stdin_file.argtypes = [ctypes.POINTER(wasi_config_t), ctypes.POINTER(ctypes.c_char)]
def wasi_config_set_stdin_file(config: Any, path: Any) -> bool:
    return _wasi_config_set_stdin_file(config, path)  # type: ignore

_wasi_config_set_stdin_bytes = dll.wasi_config_set_stdin_bytes
_wasi_config_set_stdin_bytes.restype = None
_wasi_config_set_stdin_bytes.argtypes = [ctypes.POINTER(wasi_config_t), ctypes.POINTER(wasm_byte_vec_t)]
def wasi_config_set_stdin_bytes(config: Any, binary: Any) -> None:
    return _wasi_config_set_stdin_bytes(config, binary)  # type: ignore

_wasi_config_inherit_stdin = dll.wasi_config_inherit_stdin
_wasi_config_inherit_stdin.restype = None
_wasi_config_inherit_stdin.argtypes = [ctypes.POINTER(wasi_config_t)]
def wasi_config_inherit_stdin(config: Any) -> None:
    return _wasi_config_inherit_stdin(config)  # type: ignore

_wasi_config_set_stdout_file = dll.wasi_config_set_stdout_file
_wasi_config_set_stdout_file.restype = ctypes.c_bool
_wasi_config_set_stdout_file.argtypes = [ctypes.POINTER(wasi_config_t), ctypes.POINTER(ctypes.c_char)]
def wasi_config_set_stdout_file(config: Any, path: Any) -> bool:
    return _wasi_config_set_stdout_file(config, path)  # type: ignore

_wasi_config_inherit_stdout = dll.wasi_config_inherit_stdout
_wasi_config_inherit_stdout.restype = None
_wasi_config_inherit_stdout.argtypes = [ctypes.POINTER(wasi_config_t)]
def wasi_config_inherit_stdout(config: Any) -> None:
    return _wasi_config_inherit_stdout(config)  # type: ignore

_wasi_config_set_stdout_custom = dll.wasi_config_set_stdout_custom
_wasi_config_set_stdout_custom.restype = None
_wasi_config_set_stdout_custom.argtypes = [ctypes.POINTER(wasi_config_t), ctypes.CFUNCTYPE(ctypes.c_ssize_t, ctypes.c_void_p, ctypes.POINTER(ctypes.c_ubyte), ctypes.c_size_t), ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p)]
def wasi_config_set_stdout_custom(config: Any, callback: Any, data: Any, finalizer: Any) -> None:
    return _wasi_config_set_stdout_custom(config, callback, data, finalizer)  # type: ignore

_wasi_config_set_stderr_file = dll.wasi_config_set_stderr_file
_wasi_config_set_stderr_file.restype = ctypes.c_bool
_wasi_config_set_stderr_file.argtypes = [ctypes.POINTER(wasi_config_t), ctypes.POINTER(ctypes.c_char)]
def wasi_config_set_stderr_file(config: Any, path: Any) -> bool:
    return _wasi_config_set_stderr_file(config, path)  # type: ignore

_wasi_config_inherit_stderr = dll.wasi_config_inherit_stderr
_wasi_config_inherit_stderr.restype = None
_wasi_config_inherit_stderr.argtypes = [ctypes.POINTER(wasi_config_t)]
def wasi_config_inherit_stderr(config: Any) -> None:
    return _wasi_config_inherit_stderr(config)  # type: ignore

_wasi_config_set_stderr_custom = dll.wasi_config_set_stderr_custom
_wasi_config_set_stderr_custom.restype = None
_wasi_config_set_stderr_custom.argtypes = [ctypes.POINTER(wasi_config_t), ctypes.CFUNCTYPE(ctypes.c_ssize_t, ctypes.c_void_p, ctypes.POINTER(ctypes.c_ubyte), ctypes.c_size_t), ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p)]
def wasi_config_set_stderr_custom(config: Any, callback: Any, data: Any, finalizer: Any) -> None:
    return _wasi_config_set_stderr_custom(config, callback, data, finalizer)  # type: ignore

wasi_file_perms = ctypes.c_size_t

_wasi_config_preopen_dir = dll.wasi_config_preopen_dir
_wasi_config_preopen_dir.restype = ctypes.c_bool
_wasi_config_preopen_dir.argtypes = [ctypes.POINTER(wasi_config_t), ctypes.POINTER(ctypes.c_char), ctypes.POINTER(ctypes.c_char), ctypes.c_bool]
def wasi_config_preopen_dir(config: Any, host_path: Any, guest_path: Any, fs_mutable: Any) -> bool:
    return _wasi_config_preopen_dir(config, host_path, guest_path, fs_mutable)  # type: ignore

wasmtime_storage_type_kind_t = ctypes.c_uint8

class wasmtime_storage_type(ctypes.Structure):
    _fields_ = [
        ("kind", wasmtime_storage_type_kind_t),
        ("valtype", ctypes.POINTER(wasm_valtype_t)),
    ]
    kind: wasmtime_storage_type_kind_t
    valtype: ctypes._Pointer

wasmtime_storage_type_t = wasmtime_storage_type

_wasmtime_storage_type_clone = dll.wasmtime_storage_type_clone
_wasmtime_storage_type_clone.restype = None
_wasmtime_storage_type_clone.argtypes = [ctypes.POINTER(wasmtime_storage_type_t), ctypes.POINTER(wasmtime_storage_type_t)]
def wasmtime_storage_type_clone(storage: Any, out: Any) -> None:
    return _wasmtime_storage_type_clone(storage, out)  # type: ignore

_wasmtime_storage_type_delete = dll.wasmtime_storage_type_delete
_wasmtime_storage_type_delete.restype = None
_wasmtime_storage_type_delete.argtypes = [ctypes.POINTER(wasmtime_storage_type_t)]
def wasmtime_storage_type_delete(storage: Any) -> None:
    return _wasmtime_storage_type_delete(storage)  # type: ignore

class wasmtime_field_type(ctypes.Structure):
    _fields_ = [
        ("mutable_", ctypes.c_bool),
        ("storage", wasmtime_storage_type_t),
    ]
    mutable_: bool
    storage: wasmtime_storage_type_t

wasmtime_field_type_t = wasmtime_field_type

_wasmtime_field_type_clone = dll.wasmtime_field_type_clone
_wasmtime_field_type_clone.restype = None
_wasmtime_field_type_clone.argtypes = [ctypes.POINTER(wasmtime_field_type_t), ctypes.POINTER(wasmtime_field_type_t)]
def wasmtime_field_type_clone(field: Any, out: Any) -> None:
    return _wasmtime_field_type_clone(field, out)  # type: ignore

_wasmtime_field_type_delete = dll.wasmtime_field_type_delete
_wasmtime_field_type_delete.restype = None
_wasmtime_field_type_delete.argtypes = [ctypes.POINTER(wasmtime_field_type_t)]
def wasmtime_field_type_delete(field: Any) -> None:
    return _wasmtime_field_type_delete(field)  # type: ignore

class wasmtime_struct_type(ctypes.Structure):
    pass

wasmtime_struct_type_t = wasmtime_struct_type

_wasmtime_struct_type_new = dll.wasmtime_struct_type_new
_wasmtime_struct_type_new.restype = ctypes.POINTER(wasmtime_struct_type_t)
_wasmtime_struct_type_new.argtypes = [ctypes.POINTER(wasm_engine_t), ctypes.POINTER(wasmtime_field_type_t), ctypes.c_size_t]
def wasmtime_struct_type_new(engine: Any, fields: Any, nfields: Any) -> ctypes._Pointer:
    return _wasmtime_struct_type_new(engine, fields, nfields)  # type: ignore

_wasmtime_struct_type_copy = dll.wasmtime_struct_type_copy
_wasmtime_struct_type_copy.restype = ctypes.POINTER(wasmtime_struct_type_t)
_wasmtime_struct_type_copy.argtypes = [ctypes.POINTER(wasmtime_struct_type_t)]
def wasmtime_struct_type_copy(ty: Any) -> ctypes._Pointer:
    return _wasmtime_struct_type_copy(ty)  # type: ignore

_wasmtime_struct_type_delete = dll.wasmtime_struct_type_delete
_wasmtime_struct_type_delete.restype = None
_wasmtime_struct_type_delete.argtypes = [ctypes.POINTER(wasmtime_struct_type_t)]
def wasmtime_struct_type_delete(ty: Any) -> None:
    return _wasmtime_struct_type_delete(ty)  # type: ignore

_wasmtime_struct_type_num_fields = dll.wasmtime_struct_type_num_fields
_wasmtime_struct_type_num_fields.restype = ctypes.c_size_t
_wasmtime_struct_type_num_fields.argtypes = [ctypes.POINTER(wasmtime_struct_type_t)]
def wasmtime_struct_type_num_fields(ty: Any) -> int:
    return _wasmtime_struct_type_num_fields(ty)  # type: ignore

_wasmtime_struct_type_field = dll.wasmtime_struct_type_field
_wasmtime_struct_type_field.restype = ctypes.c_bool
_wasmtime_struct_type_field.argtypes = [ctypes.POINTER(wasmtime_struct_type_t), ctypes.c_size_t, ctypes.POINTER(wasmtime_field_type_t)]
def wasmtime_struct_type_field(ty: Any, index: Any, out: Any) -> bool:
    return _wasmtime_struct_type_field(ty, index, out)  # type: ignore

class wasmtime_array_type(ctypes.Structure):
    pass

wasmtime_array_type_t = wasmtime_array_type

_wasmtime_array_type_new = dll.wasmtime_array_type_new
_wasmtime_array_type_new.restype = ctypes.POINTER(wasmtime_array_type_t)
_wasmtime_array_type_new.argtypes = [ctypes.POINTER(wasm_engine_t), ctypes.POINTER(wasmtime_field_type_t)]
def wasmtime_array_type_new(engine: Any, field: Any) -> ctypes._Pointer:
    return _wasmtime_array_type_new(engine, field)  # type: ignore

_wasmtime_array_type_copy = dll.wasmtime_array_type_copy
_wasmtime_array_type_copy.restype = ctypes.POINTER(wasmtime_array_type_t)
_wasmtime_array_type_copy.argtypes = [ctypes.POINTER(wasmtime_array_type_t)]
def wasmtime_array_type_copy(ty: Any) -> ctypes._Pointer:
    return _wasmtime_array_type_copy(ty)  # type: ignore

_wasmtime_array_type_delete = dll.wasmtime_array_type_delete
_wasmtime_array_type_delete.restype = None
_wasmtime_array_type_delete.argtypes = [ctypes.POINTER(wasmtime_array_type_t)]
def wasmtime_array_type_delete(ty: Any) -> None:
    return _wasmtime_array_type_delete(ty)  # type: ignore

_wasmtime_array_type_element = dll.wasmtime_array_type_element
_wasmtime_array_type_element.restype = None
_wasmtime_array_type_element.argtypes = [ctypes.POINTER(wasmtime_array_type_t), ctypes.POINTER(wasmtime_field_type_t)]
def wasmtime_array_type_element(ty: Any, out: Any) -> None:
    return _wasmtime_array_type_element(ty, out)  # type: ignore

class wasmtime_error(ctypes.Structure):
    pass

wasmtime_error_t = wasmtime_error

_wasmtime_error_new = dll.wasmtime_error_new
_wasmtime_error_new.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_error_new.argtypes = [ctypes.POINTER(ctypes.c_char)]
def wasmtime_error_new(arg0: Any) -> ctypes._Pointer:
    return _wasmtime_error_new(arg0)  # type: ignore

_wasmtime_error_delete = dll.wasmtime_error_delete
_wasmtime_error_delete.restype = None
_wasmtime_error_delete.argtypes = [ctypes.POINTER(wasmtime_error_t)]
def wasmtime_error_delete(error: Any) -> None:
    return _wasmtime_error_delete(error)  # type: ignore

_wasmtime_error_message = dll.wasmtime_error_message
_wasmtime_error_message.restype = None
_wasmtime_error_message.argtypes = [ctypes.POINTER(wasmtime_error_t), ctypes.POINTER(wasm_name_t)]
def wasmtime_error_message(error: Any, message: Any) -> None:
    return _wasmtime_error_message(error, message)  # type: ignore

_wasmtime_error_exit_status = dll.wasmtime_error_exit_status
_wasmtime_error_exit_status.restype = ctypes.c_bool
_wasmtime_error_exit_status.argtypes = [ctypes.POINTER(wasmtime_error_t), ctypes.POINTER(ctypes.c_int)]
def wasmtime_error_exit_status(arg0: Any, status: Any) -> bool:
    return _wasmtime_error_exit_status(arg0, status)  # type: ignore

_wasmtime_error_wasm_trace = dll.wasmtime_error_wasm_trace
_wasmtime_error_wasm_trace.restype = None
_wasmtime_error_wasm_trace.argtypes = [ctypes.POINTER(wasmtime_error_t), ctypes.POINTER(wasm_frame_vec_t)]
def wasmtime_error_wasm_trace(arg0: Any, out: Any) -> None:
    return _wasmtime_error_wasm_trace(arg0, out)  # type: ignore

class wasmtime_exn_type(ctypes.Structure):
    pass

wasmtime_exn_type_t = wasmtime_exn_type

_wasmtime_exn_type_new = dll.wasmtime_exn_type_new
_wasmtime_exn_type_new.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_exn_type_new.argtypes = [ctypes.POINTER(wasm_engine_t), ctypes.POINTER(wasm_valtype_vec_t), ctypes.POINTER(ctypes.POINTER(wasmtime_exn_type_t))]
def wasmtime_exn_type_new(engine: Any, params: Any, out: Any) -> ctypes._Pointer:
    return _wasmtime_exn_type_new(engine, params, out)  # type: ignore

_wasmtime_exn_type_delete = dll.wasmtime_exn_type_delete
_wasmtime_exn_type_delete.restype = None
_wasmtime_exn_type_delete.argtypes = [ctypes.POINTER(wasmtime_exn_type_t)]
def wasmtime_exn_type_delete(ty: Any) -> None:
    return _wasmtime_exn_type_delete(ty)  # type: ignore

_wasmtime_exn_type_copy = dll.wasmtime_exn_type_copy
_wasmtime_exn_type_copy.restype = ctypes.POINTER(wasmtime_exn_type_t)
_wasmtime_exn_type_copy.argtypes = [ctypes.POINTER(wasmtime_exn_type_t)]
def wasmtime_exn_type_copy(ty: Any) -> ctypes._Pointer:
    return _wasmtime_exn_type_copy(ty)  # type: ignore

_wasmtime_exn_type_tag_type = dll.wasmtime_exn_type_tag_type
_wasmtime_exn_type_tag_type.restype = ctypes.POINTER(wasm_tagtype_t)
_wasmtime_exn_type_tag_type.argtypes = [ctypes.POINTER(wasmtime_exn_type_t)]
def wasmtime_exn_type_tag_type(ty: Any) -> ctypes._Pointer:
    return _wasmtime_exn_type_tag_type(ty)  # type: ignore

_wasmtime_wasm_valtype_v128 = dll.wasmtime_wasm_valtype_v128
_wasmtime_wasm_valtype_v128.restype = ctypes.POINTER(wasm_valtype_t)
_wasmtime_wasm_valtype_v128.argtypes = []
def wasmtime_wasm_valtype_v128() -> ctypes._Pointer:
    return _wasmtime_wasm_valtype_v128()  # type: ignore

_wasmtime_wasm_valtype_equal = dll.wasmtime_wasm_valtype_equal
_wasmtime_wasm_valtype_equal.restype = ctypes.c_bool
_wasmtime_wasm_valtype_equal.argtypes = [ctypes.POINTER(wasm_valtype_t), ctypes.POINTER(wasm_valtype_t)]
def wasmtime_wasm_valtype_equal(a: Any, b: Any) -> bool:
    return _wasmtime_wasm_valtype_equal(a, b)  # type: ignore

wasmtime_heaptype_kind_t = ctypes.c_uint8

class wasmtime_heaptype_union(ctypes.Union):
    _fields_ = [
        ("concrete_func", ctypes.POINTER(wasm_functype_t)),
        ("concrete_array", ctypes.POINTER(wasmtime_array_type_t)),
        ("concrete_struct", ctypes.POINTER(wasmtime_struct_type_t)),
        ("concrete_exn", ctypes.POINTER(wasmtime_exn_type_t)),
    ]
    concrete_func: ctypes._Pointer
    concrete_array: ctypes._Pointer
    concrete_struct: ctypes._Pointer
    concrete_exn: ctypes._Pointer

wasmtime_heaptype_union_t = wasmtime_heaptype_union

class wasmtime_heaptype(ctypes.Structure):
    _fields_ = [
        ("kind", wasmtime_heaptype_kind_t),
        ("of", wasmtime_heaptype_union_t),
    ]
    kind: wasmtime_heaptype_kind_t
    of: wasmtime_heaptype_union_t

wasmtime_heaptype_t = wasmtime_heaptype

_wasmtime_heaptype_clone = dll.wasmtime_heaptype_clone
_wasmtime_heaptype_clone.restype = None
_wasmtime_heaptype_clone.argtypes = [ctypes.POINTER(wasmtime_heaptype_t), ctypes.POINTER(wasmtime_heaptype_t)]
def wasmtime_heaptype_clone(ty: Any, out: Any) -> None:
    return _wasmtime_heaptype_clone(ty, out)  # type: ignore

_wasmtime_heaptype_delete = dll.wasmtime_heaptype_delete
_wasmtime_heaptype_delete.restype = None
_wasmtime_heaptype_delete.argtypes = [ctypes.POINTER(wasmtime_heaptype_t)]
def wasmtime_heaptype_delete(ty: Any) -> None:
    return _wasmtime_heaptype_delete(ty)  # type: ignore

class wasmtime_reftype(ctypes.Structure):
    _fields_ = [
        ("nullable", ctypes.c_bool),
        ("heaptype", wasmtime_heaptype_t),
    ]
    nullable: bool
    heaptype: wasmtime_heaptype_t

wasmtime_reftype_t = wasmtime_reftype

_wasmtime_reftype_clone = dll.wasmtime_reftype_clone
_wasmtime_reftype_clone.restype = None
_wasmtime_reftype_clone.argtypes = [ctypes.POINTER(wasmtime_reftype_t), ctypes.POINTER(wasmtime_reftype_t)]
def wasmtime_reftype_clone(ty: Any, out: Any) -> None:
    return _wasmtime_reftype_clone(ty, out)  # type: ignore

_wasmtime_reftype_delete = dll.wasmtime_reftype_delete
_wasmtime_reftype_delete.restype = None
_wasmtime_reftype_delete.argtypes = [ctypes.POINTER(wasmtime_reftype_t)]
def wasmtime_reftype_delete(ty: Any) -> None:
    return _wasmtime_reftype_delete(ty)  # type: ignore

wasmtime_valtype_kind_t = ctypes.c_uint8

class wasmtime_valtype(ctypes.Structure):
    _fields_ = [
        ("kind", wasmtime_valtype_kind_t),
        ("reftype", wasmtime_reftype_t),
    ]
    kind: wasmtime_valtype_kind_t
    reftype: wasmtime_reftype_t

wasmtime_valtype_t = wasmtime_valtype

_wasmtime_valtype_new = dll.wasmtime_valtype_new
_wasmtime_valtype_new.restype = None
_wasmtime_valtype_new.argtypes = [ctypes.POINTER(wasm_valtype_t), ctypes.POINTER(wasmtime_valtype_t)]
def wasmtime_valtype_new(ty: Any, out: Any) -> None:
    return _wasmtime_valtype_new(ty, out)  # type: ignore

_wasmtime_valtype_clone = dll.wasmtime_valtype_clone
_wasmtime_valtype_clone.restype = None
_wasmtime_valtype_clone.argtypes = [ctypes.POINTER(wasmtime_valtype_t), ctypes.POINTER(wasmtime_valtype_t)]
def wasmtime_valtype_clone(ty: Any, out: Any) -> None:
    return _wasmtime_valtype_clone(ty, out)  # type: ignore

_wasmtime_valtype_delete = dll.wasmtime_valtype_delete
_wasmtime_valtype_delete.restype = None
_wasmtime_valtype_delete.argtypes = [ctypes.POINTER(wasmtime_valtype_t)]
def wasmtime_valtype_delete(ty: Any) -> None:
    return _wasmtime_valtype_delete(ty)  # type: ignore

_wasmtime_valtype_to_wasm = dll.wasmtime_valtype_to_wasm
_wasmtime_valtype_to_wasm.restype = ctypes.POINTER(wasm_valtype_t)
_wasmtime_valtype_to_wasm.argtypes = [ctypes.POINTER(wasm_engine_t), ctypes.POINTER(wasmtime_valtype_t)]
def wasmtime_valtype_to_wasm(engine: Any, ty: Any) -> ctypes._Pointer:
    return _wasmtime_valtype_to_wasm(engine, ty)  # type: ignore

class wasmtime_module(ctypes.Structure):
    pass

wasmtime_module_t = wasmtime_module

_wasmtime_module_new = dll.wasmtime_module_new
_wasmtime_module_new.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_module_new.argtypes = [ctypes.POINTER(wasm_engine_t), ctypes.POINTER(ctypes.c_uint8), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(wasmtime_module_t))]
def wasmtime_module_new(engine: Any, wasm: Any, wasm_len: Any, ret: Any) -> ctypes._Pointer:
    return _wasmtime_module_new(engine, wasm, wasm_len, ret)  # type: ignore

_wasmtime_module_delete = dll.wasmtime_module_delete
_wasmtime_module_delete.restype = None
_wasmtime_module_delete.argtypes = [ctypes.POINTER(wasmtime_module_t)]
def wasmtime_module_delete(m: Any) -> None:
    return _wasmtime_module_delete(m)  # type: ignore

_wasmtime_module_clone = dll.wasmtime_module_clone
_wasmtime_module_clone.restype = ctypes.POINTER(wasmtime_module_t)
_wasmtime_module_clone.argtypes = [ctypes.POINTER(wasmtime_module_t)]
def wasmtime_module_clone(m: Any) -> ctypes._Pointer:
    return _wasmtime_module_clone(m)  # type: ignore

_wasmtime_module_imports = dll.wasmtime_module_imports
_wasmtime_module_imports.restype = None
_wasmtime_module_imports.argtypes = [ctypes.POINTER(wasmtime_module_t), ctypes.POINTER(wasm_importtype_vec_t)]
def wasmtime_module_imports(module: Any, out: Any) -> None:
    return _wasmtime_module_imports(module, out)  # type: ignore

_wasmtime_module_exports = dll.wasmtime_module_exports
_wasmtime_module_exports.restype = None
_wasmtime_module_exports.argtypes = [ctypes.POINTER(wasmtime_module_t), ctypes.POINTER(wasm_exporttype_vec_t)]
def wasmtime_module_exports(module: Any, out: Any) -> None:
    return _wasmtime_module_exports(module, out)  # type: ignore

_wasmtime_module_validate = dll.wasmtime_module_validate
_wasmtime_module_validate.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_module_validate.argtypes = [ctypes.POINTER(wasm_engine_t), ctypes.POINTER(ctypes.c_uint8), ctypes.c_size_t]
def wasmtime_module_validate(engine: Any, wasm: Any, wasm_len: Any) -> ctypes._Pointer:
    return _wasmtime_module_validate(engine, wasm, wasm_len)  # type: ignore

_wasmtime_module_serialize = dll.wasmtime_module_serialize
_wasmtime_module_serialize.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_module_serialize.argtypes = [ctypes.POINTER(wasmtime_module_t), ctypes.POINTER(wasm_byte_vec_t)]
def wasmtime_module_serialize(module: Any, ret: Any) -> ctypes._Pointer:
    return _wasmtime_module_serialize(module, ret)  # type: ignore

_wasmtime_module_deserialize = dll.wasmtime_module_deserialize
_wasmtime_module_deserialize.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_module_deserialize.argtypes = [ctypes.POINTER(wasm_engine_t), ctypes.POINTER(ctypes.c_uint8), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(wasmtime_module_t))]
def wasmtime_module_deserialize(engine: Any, bytes: Any, bytes_len: Any, ret: Any) -> ctypes._Pointer:
    return _wasmtime_module_deserialize(engine, bytes, bytes_len, ret)  # type: ignore

_wasmtime_module_deserialize_file = dll.wasmtime_module_deserialize_file
_wasmtime_module_deserialize_file.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_module_deserialize_file.argtypes = [ctypes.POINTER(wasm_engine_t), ctypes.POINTER(ctypes.c_char), ctypes.POINTER(ctypes.POINTER(wasmtime_module_t))]
def wasmtime_module_deserialize_file(engine: Any, path: Any, ret: Any) -> ctypes._Pointer:
    return _wasmtime_module_deserialize_file(engine, path, ret)  # type: ignore

_wasmtime_module_image_range = dll.wasmtime_module_image_range
_wasmtime_module_image_range.restype = None
_wasmtime_module_image_range.argtypes = [ctypes.POINTER(wasmtime_module_t), ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(ctypes.c_void_p)]
def wasmtime_module_image_range(module: Any, start: Any, end: Any) -> None:
    return _wasmtime_module_image_range(module, start, end)  # type: ignore

class wasmtime_sharedmemory(ctypes.Structure):
    pass

wasmtime_sharedmemory_t = wasmtime_sharedmemory

_wasmtime_sharedmemory_new = dll.wasmtime_sharedmemory_new
_wasmtime_sharedmemory_new.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_sharedmemory_new.argtypes = [ctypes.POINTER(wasm_engine_t), ctypes.POINTER(wasm_memorytype_t), ctypes.POINTER(ctypes.POINTER(wasmtime_sharedmemory_t))]
def wasmtime_sharedmemory_new(engine: Any, ty: Any, ret: Any) -> ctypes._Pointer:
    return _wasmtime_sharedmemory_new(engine, ty, ret)  # type: ignore

_wasmtime_sharedmemory_delete = dll.wasmtime_sharedmemory_delete
_wasmtime_sharedmemory_delete.restype = None
_wasmtime_sharedmemory_delete.argtypes = [ctypes.POINTER(wasmtime_sharedmemory_t)]
def wasmtime_sharedmemory_delete(memory: Any) -> None:
    return _wasmtime_sharedmemory_delete(memory)  # type: ignore

_wasmtime_sharedmemory_clone = dll.wasmtime_sharedmemory_clone
_wasmtime_sharedmemory_clone.restype = ctypes.POINTER(wasmtime_sharedmemory_t)
_wasmtime_sharedmemory_clone.argtypes = [ctypes.POINTER(wasmtime_sharedmemory_t)]
def wasmtime_sharedmemory_clone(memory: Any) -> ctypes._Pointer:
    return _wasmtime_sharedmemory_clone(memory)  # type: ignore

_wasmtime_sharedmemory_type = dll.wasmtime_sharedmemory_type
_wasmtime_sharedmemory_type.restype = ctypes.POINTER(wasm_memorytype_t)
_wasmtime_sharedmemory_type.argtypes = [ctypes.POINTER(wasmtime_sharedmemory_t)]
def wasmtime_sharedmemory_type(memory: Any) -> ctypes._Pointer:
    return _wasmtime_sharedmemory_type(memory)  # type: ignore

_wasmtime_sharedmemory_data = dll.wasmtime_sharedmemory_data
_wasmtime_sharedmemory_data.restype = ctypes.POINTER(ctypes.c_uint8)
_wasmtime_sharedmemory_data.argtypes = [ctypes.POINTER(wasmtime_sharedmemory_t)]
def wasmtime_sharedmemory_data(memory: Any) -> ctypes._Pointer:
    return _wasmtime_sharedmemory_data(memory)  # type: ignore

_wasmtime_sharedmemory_data_size = dll.wasmtime_sharedmemory_data_size
_wasmtime_sharedmemory_data_size.restype = ctypes.c_size_t
_wasmtime_sharedmemory_data_size.argtypes = [ctypes.POINTER(wasmtime_sharedmemory_t)]
def wasmtime_sharedmemory_data_size(memory: Any) -> int:
    return _wasmtime_sharedmemory_data_size(memory)  # type: ignore

_wasmtime_sharedmemory_size = dll.wasmtime_sharedmemory_size
_wasmtime_sharedmemory_size.restype = ctypes.c_uint64
_wasmtime_sharedmemory_size.argtypes = [ctypes.POINTER(wasmtime_sharedmemory_t)]
def wasmtime_sharedmemory_size(memory: Any) -> int:
    return _wasmtime_sharedmemory_size(memory)  # type: ignore

_wasmtime_sharedmemory_grow = dll.wasmtime_sharedmemory_grow
_wasmtime_sharedmemory_grow.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_sharedmemory_grow.argtypes = [ctypes.POINTER(wasmtime_sharedmemory_t), ctypes.c_uint64, ctypes.POINTER(ctypes.c_uint64)]
def wasmtime_sharedmemory_grow(memory: Any, delta: Any, prev_size: Any) -> ctypes._Pointer:
    return _wasmtime_sharedmemory_grow(memory, delta, prev_size)  # type: ignore

class wasmtime_store(ctypes.Structure):
    pass

wasmtime_store_t = wasmtime_store

class wasmtime_context(ctypes.Structure):
    pass

wasmtime_context_t = wasmtime_context

_wasmtime_store_new = dll.wasmtime_store_new
_wasmtime_store_new.restype = ctypes.POINTER(wasmtime_store_t)
_wasmtime_store_new.argtypes = [ctypes.POINTER(wasm_engine_t), ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p)]
def wasmtime_store_new(engine: Any, data: Any, finalizer: Any) -> ctypes._Pointer:
    return _wasmtime_store_new(engine, data, finalizer)  # type: ignore

_wasmtime_store_context = dll.wasmtime_store_context
_wasmtime_store_context.restype = ctypes.POINTER(wasmtime_context_t)
_wasmtime_store_context.argtypes = [ctypes.POINTER(wasmtime_store_t)]
def wasmtime_store_context(store: Any) -> ctypes._Pointer:
    return _wasmtime_store_context(store)  # type: ignore

_wasmtime_store_limiter = dll.wasmtime_store_limiter
_wasmtime_store_limiter.restype = None
_wasmtime_store_limiter.argtypes = [ctypes.POINTER(wasmtime_store_t), ctypes.c_int64, ctypes.c_int64, ctypes.c_int64, ctypes.c_int64, ctypes.c_int64]
def wasmtime_store_limiter(store: Any, memory_size: Any, table_elements: Any, instances: Any, tables: Any, memories: Any) -> None:
    return _wasmtime_store_limiter(store, memory_size, table_elements, instances, tables, memories)  # type: ignore

_wasmtime_store_delete = dll.wasmtime_store_delete
_wasmtime_store_delete.restype = None
_wasmtime_store_delete.argtypes = [ctypes.POINTER(wasmtime_store_t)]
def wasmtime_store_delete(store: Any) -> None:
    return _wasmtime_store_delete(store)  # type: ignore

_wasmtime_context_get_data = dll.wasmtime_context_get_data
_wasmtime_context_get_data.restype = ctypes.c_void_p
_wasmtime_context_get_data.argtypes = [ctypes.POINTER(wasmtime_context_t)]
def wasmtime_context_get_data(context: Any) -> ctypes._Pointer:
    return _wasmtime_context_get_data(context)  # type: ignore

_wasmtime_context_set_data = dll.wasmtime_context_set_data
_wasmtime_context_set_data.restype = None
_wasmtime_context_set_data.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.c_void_p]
def wasmtime_context_set_data(context: Any, data: Any) -> None:
    return _wasmtime_context_set_data(context, data)  # type: ignore

_wasmtime_context_gc = dll.wasmtime_context_gc
_wasmtime_context_gc.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_context_gc.argtypes = [ctypes.POINTER(wasmtime_context_t)]
def wasmtime_context_gc(context: Any) -> ctypes._Pointer:
    return _wasmtime_context_gc(context)  # type: ignore

_wasmtime_context_set_fuel = dll.wasmtime_context_set_fuel
_wasmtime_context_set_fuel.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_context_set_fuel.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.c_uint64]
def wasmtime_context_set_fuel(store: Any, fuel: Any) -> ctypes._Pointer:
    return _wasmtime_context_set_fuel(store, fuel)  # type: ignore

_wasmtime_context_get_fuel = dll.wasmtime_context_get_fuel
_wasmtime_context_get_fuel.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_context_get_fuel.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(ctypes.c_uint64)]
def wasmtime_context_get_fuel(context: Any, fuel: Any) -> ctypes._Pointer:
    return _wasmtime_context_get_fuel(context, fuel)  # type: ignore

_wasmtime_context_set_wasi = dll.wasmtime_context_set_wasi
_wasmtime_context_set_wasi.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_context_set_wasi.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasi_config_t)]
def wasmtime_context_set_wasi(context: Any, wasi: Any) -> ctypes._Pointer:
    return _wasmtime_context_set_wasi(context, wasi)  # type: ignore

_wasmtime_context_set_wasi_http = dll.wasmtime_context_set_wasi_http
_wasmtime_context_set_wasi_http.restype = None
_wasmtime_context_set_wasi_http.argtypes = [ctypes.POINTER(wasmtime_context_t)]
def wasmtime_context_set_wasi_http(context: Any) -> None:
    return _wasmtime_context_set_wasi_http(context)  # type: ignore

_wasmtime_context_set_epoch_deadline = dll.wasmtime_context_set_epoch_deadline
_wasmtime_context_set_epoch_deadline.restype = None
_wasmtime_context_set_epoch_deadline.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.c_uint64]
def wasmtime_context_set_epoch_deadline(context: Any, ticks_beyond_current: Any) -> None:
    return _wasmtime_context_set_epoch_deadline(context, ticks_beyond_current)  # type: ignore

wasmtime_update_deadline_kind_t = ctypes.c_uint8

_wasmtime_store_epoch_deadline_callback = dll.wasmtime_store_epoch_deadline_callback
_wasmtime_store_epoch_deadline_callback.restype = None
_wasmtime_store_epoch_deadline_callback.argtypes = [ctypes.POINTER(wasmtime_store_t), ctypes.CFUNCTYPE(ctypes.c_size_t, ctypes.POINTER(wasmtime_context_t), ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint64), ctypes.POINTER(wasmtime_update_deadline_kind_t)), ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p)]
def wasmtime_store_epoch_deadline_callback(store: Any, func: Any, data: Any, finalizer: Any) -> None:
    return _wasmtime_store_epoch_deadline_callback(store, func, data, finalizer)  # type: ignore


class wasmtime_tag_anon_0(ctypes.Structure):
    _fields_ = [
        ("store_id", ctypes.c_uint64),
        ("__private1", ctypes.c_uint32),
    ]
    store_id: int
    __private1: int
class wasmtime_tag(ctypes.Structure):
    _fields_ = [
        ("_anon_1", wasmtime_tag_anon_0),
        ("__private2", ctypes.c_uint32),
    ]
    _anon_1: wasmtime_tag_anon_0
    __private2: int

wasmtime_tag_t = wasmtime_tag

_wasmtime_tag_new = dll.wasmtime_tag_new
_wasmtime_tag_new.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_tag_new.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasm_tagtype_t), ctypes.POINTER(wasmtime_tag_t)]
def wasmtime_tag_new(store: Any, tt: Any, ret: Any) -> ctypes._Pointer:
    return _wasmtime_tag_new(store, tt, ret)  # type: ignore

_wasmtime_tag_type = dll.wasmtime_tag_type
_wasmtime_tag_type.restype = ctypes.POINTER(wasm_tagtype_t)
_wasmtime_tag_type.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_tag_t)]
def wasmtime_tag_type(store: Any, tag: Any) -> ctypes._Pointer:
    return _wasmtime_tag_type(store, tag)  # type: ignore

_wasmtime_tag_eq = dll.wasmtime_tag_eq
_wasmtime_tag_eq.restype = ctypes.c_bool
_wasmtime_tag_eq.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_tag_t), ctypes.POINTER(wasmtime_tag_t)]
def wasmtime_tag_eq(store: Any, a: Any, b: Any) -> bool:
    return _wasmtime_tag_eq(store, a, b)  # type: ignore

class wasmtime_func(ctypes.Structure):
    _fields_ = [
        ("store_id", ctypes.c_uint64),
        ("__private", ctypes.c_void_p),
    ]
    store_id: int
    __private: ctypes._Pointer

wasmtime_func_t = wasmtime_func


class wasmtime_table_anon_0(ctypes.Structure):
    _fields_ = [
        ("store_id", ctypes.c_uint64),
        ("__private1", ctypes.c_uint32),
    ]
    store_id: int
    __private1: int
class wasmtime_table(ctypes.Structure):
    _fields_ = [
        ("_anon_1", wasmtime_table_anon_0),
        ("__private2", ctypes.c_uint32),
    ]
    _anon_1: wasmtime_table_anon_0
    __private2: int

wasmtime_table_t = wasmtime_table


class wasmtime_memory_anon_0(ctypes.Structure):
    _fields_ = [
        ("store_id", ctypes.c_uint64),
        ("__private1", ctypes.c_uint32),
    ]
    store_id: int
    __private1: int
class wasmtime_memory(ctypes.Structure):
    _fields_ = [
        ("_anon_1", wasmtime_memory_anon_0),
        ("__private2", ctypes.c_uint32),
    ]
    _anon_1: wasmtime_memory_anon_0
    __private2: int

wasmtime_memory_t = wasmtime_memory

class wasmtime_global(ctypes.Structure):
    _fields_ = [
        ("store_id", ctypes.c_uint64),
        ("__private1", ctypes.c_uint32),
        ("__private2", ctypes.c_uint32),
        ("__private3", ctypes.c_uint32),
    ]
    store_id: int
    __private1: int
    __private2: int
    __private3: int

wasmtime_global_t = wasmtime_global

wasmtime_extern_kind_t = ctypes.c_uint8

class wasmtime_extern_union(ctypes.Union):
    _fields_ = [
        ("func", wasmtime_func_t),
        ("global_", wasmtime_global_t),
        ("table", wasmtime_table_t),
        ("memory", wasmtime_memory_t),
        ("sharedmemory", ctypes.POINTER(wasmtime_sharedmemory)),
        ("tag", wasmtime_tag_t),
    ]
    func: wasmtime_func_t
    global_: wasmtime_global_t
    table: wasmtime_table_t
    memory: wasmtime_memory_t
    sharedmemory: ctypes._Pointer
    tag: wasmtime_tag_t

wasmtime_extern_union_t = wasmtime_extern_union

class wasmtime_extern(ctypes.Structure):
    _fields_ = [
        ("kind", wasmtime_extern_kind_t),
        ("of", wasmtime_extern_union_t),
    ]
    kind: wasmtime_extern_kind_t
    of: wasmtime_extern_union_t

wasmtime_extern_t = wasmtime_extern

_wasmtime_extern_delete = dll.wasmtime_extern_delete
_wasmtime_extern_delete.restype = None
_wasmtime_extern_delete.argtypes = [ctypes.POINTER(wasmtime_extern_t)]
def wasmtime_extern_delete(val: Any) -> None:
    return _wasmtime_extern_delete(val)  # type: ignore

_wasmtime_extern_type = dll.wasmtime_extern_type
_wasmtime_extern_type.restype = ctypes.POINTER(wasm_externtype_t)
_wasmtime_extern_type.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_extern_t)]
def wasmtime_extern_type(context: Any, val: Any) -> ctypes._Pointer:
    return _wasmtime_extern_type(context, val)  # type: ignore

wasmtime_valkind_t = ctypes.c_uint8

wasmtime_v128 = ctypes.c_uint8 * 16

class wasmtime_anyref(ctypes.Structure):
    _fields_ = [
        ("store_id", ctypes.c_uint64),
        ("__private1", ctypes.c_uint32),
        ("__private2", ctypes.c_uint32),
        ("__private3", ctypes.c_void_p),
    ]
    store_id: int
    __private1: int
    __private2: int
    __private3: ctypes._Pointer

wasmtime_anyref_t = wasmtime_anyref

class wasmtime_exnref(ctypes.Structure):
    _fields_ = [
        ("store_id", ctypes.c_uint64),
        ("__private1", ctypes.c_uint32),
        ("__private2", ctypes.c_uint32),
        ("__private3", ctypes.c_void_p),
    ]
    store_id: int
    __private1: int
    __private2: int
    __private3: ctypes._Pointer

wasmtime_exnref_t = wasmtime_exnref

class wasmtime_externref(ctypes.Structure):
    _fields_ = [
        ("store_id", ctypes.c_uint64),
        ("__private1", ctypes.c_uint32),
        ("__private2", ctypes.c_uint32),
        ("__private3", ctypes.c_void_p),
    ]
    store_id: int
    __private1: int
    __private2: int
    __private3: ctypes._Pointer

wasmtime_externref_t = wasmtime_externref

class wasmtime_eqref(ctypes.Structure):
    _fields_ = [
        ("store_id", ctypes.c_uint64),
        ("__private1", ctypes.c_uint32),
        ("__private2", ctypes.c_uint32),
        ("__private3", ctypes.c_void_p),
    ]
    store_id: int
    __private1: int
    __private2: int
    __private3: ctypes._Pointer

wasmtime_eqref_t = wasmtime_eqref

class wasmtime_structref(ctypes.Structure):
    _fields_ = [
        ("store_id", ctypes.c_uint64),
        ("__private1", ctypes.c_uint32),
        ("__private2", ctypes.c_uint32),
        ("__private3", ctypes.c_void_p),
    ]
    store_id: int
    __private1: int
    __private2: int
    __private3: ctypes._Pointer

wasmtime_structref_t = wasmtime_structref

class wasmtime_arrayref(ctypes.Structure):
    _fields_ = [
        ("store_id", ctypes.c_uint64),
        ("__private1", ctypes.c_uint32),
        ("__private2", ctypes.c_uint32),
        ("__private3", ctypes.c_void_p),
    ]
    store_id: int
    __private1: int
    __private2: int
    __private3: ctypes._Pointer

wasmtime_arrayref_t = wasmtime_arrayref

class wasmtime_valunion(ctypes.Union):
    _fields_ = [
        ("i32", ctypes.c_int32),
        ("i64", ctypes.c_int64),
        ("f32", ctypes.c_float),
        ("f64", ctypes.c_double),
        ("anyref", wasmtime_anyref_t),
        ("externref", wasmtime_externref_t),
        ("exnref", wasmtime_exnref_t),
        ("funcref", wasmtime_func_t),
        ("v128", wasmtime_v128),
    ]
    i32: int
    i64: int
    f32: float
    f64: float
    anyref: wasmtime_anyref_t
    externref: wasmtime_externref_t
    exnref: wasmtime_exnref_t
    funcref: wasmtime_func_t
    v128: wasmtime_v128  # type: ignore

wasmtime_valunion_t = wasmtime_valunion

class wasmtime_val_raw(ctypes.Union):
    _fields_ = [
        ("i32", ctypes.c_int32),
        ("i64", ctypes.c_int64),
        ("f32", ctypes.c_float),
        ("f64", ctypes.c_double),
        ("v128", wasmtime_v128),
        ("anyref", ctypes.c_uint32),
        ("externref", ctypes.c_uint32),
        ("exnref", ctypes.c_uint32),
        ("funcref", ctypes.c_void_p),
    ]
    i32: int
    i64: int
    f32: float
    f64: float
    v128: wasmtime_v128  # type: ignore
    anyref: int
    externref: int
    exnref: int
    funcref: ctypes._Pointer

wasmtime_val_raw_t = wasmtime_val_raw

class wasmtime_val(ctypes.Structure):
    _fields_ = [
        ("kind", wasmtime_valkind_t),
        ("of", wasmtime_valunion_t),
    ]
    kind: wasmtime_valkind_t
    of: wasmtime_valunion_t

wasmtime_val_t = wasmtime_val

_wasmtime_val_unroot = dll.wasmtime_val_unroot
_wasmtime_val_unroot.restype = None
_wasmtime_val_unroot.argtypes = [ctypes.POINTER(wasmtime_val_t)]
def wasmtime_val_unroot(val: Any) -> None:
    return _wasmtime_val_unroot(val)  # type: ignore

_wasmtime_val_clone = dll.wasmtime_val_clone
_wasmtime_val_clone.restype = None
_wasmtime_val_clone.argtypes = [ctypes.POINTER(wasmtime_val_t), ctypes.POINTER(wasmtime_val_t)]
def wasmtime_val_clone(src: Any, dst: Any) -> None:
    return _wasmtime_val_clone(src, dst)  # type: ignore

_wasmtime_anyref_clone = dll.wasmtime_anyref_clone
_wasmtime_anyref_clone.restype = None
_wasmtime_anyref_clone.argtypes = [ctypes.POINTER(wasmtime_anyref_t), ctypes.POINTER(wasmtime_anyref_t)]
def wasmtime_anyref_clone(anyref: Any, out: Any) -> None:
    return _wasmtime_anyref_clone(anyref, out)  # type: ignore

_wasmtime_anyref_unroot = dll.wasmtime_anyref_unroot
_wasmtime_anyref_unroot.restype = None
_wasmtime_anyref_unroot.argtypes = [ctypes.POINTER(wasmtime_anyref_t)]
def wasmtime_anyref_unroot(ref: Any) -> None:
    return _wasmtime_anyref_unroot(ref)  # type: ignore

_wasmtime_anyref_from_raw = dll.wasmtime_anyref_from_raw
_wasmtime_anyref_from_raw.restype = None
_wasmtime_anyref_from_raw.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.c_uint32, ctypes.POINTER(wasmtime_anyref_t)]
def wasmtime_anyref_from_raw(context: Any, raw: Any, out: Any) -> None:
    return _wasmtime_anyref_from_raw(context, raw, out)  # type: ignore

_wasmtime_anyref_to_raw = dll.wasmtime_anyref_to_raw
_wasmtime_anyref_to_raw.restype = ctypes.c_uint32
_wasmtime_anyref_to_raw.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_anyref_t)]
def wasmtime_anyref_to_raw(context: Any, ref: Any) -> int:
    return _wasmtime_anyref_to_raw(context, ref)  # type: ignore

_wasmtime_anyref_from_i31 = dll.wasmtime_anyref_from_i31
_wasmtime_anyref_from_i31.restype = None
_wasmtime_anyref_from_i31.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.c_uint32, ctypes.POINTER(wasmtime_anyref_t)]
def wasmtime_anyref_from_i31(context: Any, i31val: Any, out: Any) -> None:
    return _wasmtime_anyref_from_i31(context, i31val, out)  # type: ignore

_wasmtime_anyref_is_i31 = dll.wasmtime_anyref_is_i31
_wasmtime_anyref_is_i31.restype = ctypes.c_bool
_wasmtime_anyref_is_i31.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_anyref_t)]
def wasmtime_anyref_is_i31(context: Any, anyref: Any) -> bool:
    return _wasmtime_anyref_is_i31(context, anyref)  # type: ignore

_wasmtime_anyref_i31_get_u = dll.wasmtime_anyref_i31_get_u
_wasmtime_anyref_i31_get_u.restype = ctypes.c_bool
_wasmtime_anyref_i31_get_u.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_anyref_t), ctypes.POINTER(ctypes.c_uint32)]
def wasmtime_anyref_i31_get_u(context: Any, anyref: Any, dst: Any) -> bool:
    return _wasmtime_anyref_i31_get_u(context, anyref, dst)  # type: ignore

_wasmtime_anyref_i31_get_s = dll.wasmtime_anyref_i31_get_s
_wasmtime_anyref_i31_get_s.restype = ctypes.c_bool
_wasmtime_anyref_i31_get_s.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_anyref_t), ctypes.POINTER(ctypes.c_int32)]
def wasmtime_anyref_i31_get_s(context: Any, anyref: Any, dst: Any) -> bool:
    return _wasmtime_anyref_i31_get_s(context, anyref, dst)  # type: ignore

_wasmtime_anyref_is_eqref = dll.wasmtime_anyref_is_eqref
_wasmtime_anyref_is_eqref.restype = ctypes.c_bool
_wasmtime_anyref_is_eqref.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_anyref_t)]
def wasmtime_anyref_is_eqref(context: Any, anyref: Any) -> bool:
    return _wasmtime_anyref_is_eqref(context, anyref)  # type: ignore

_wasmtime_anyref_as_eqref = dll.wasmtime_anyref_as_eqref
_wasmtime_anyref_as_eqref.restype = ctypes.c_bool
_wasmtime_anyref_as_eqref.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_anyref_t), ctypes.POINTER(wasmtime_eqref_t)]
def wasmtime_anyref_as_eqref(context: Any, anyref: Any, out: Any) -> bool:
    return _wasmtime_anyref_as_eqref(context, anyref, out)  # type: ignore

_wasmtime_anyref_is_struct = dll.wasmtime_anyref_is_struct
_wasmtime_anyref_is_struct.restype = ctypes.c_bool
_wasmtime_anyref_is_struct.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_anyref_t)]
def wasmtime_anyref_is_struct(context: Any, anyref: Any) -> bool:
    return _wasmtime_anyref_is_struct(context, anyref)  # type: ignore

_wasmtime_anyref_as_struct = dll.wasmtime_anyref_as_struct
_wasmtime_anyref_as_struct.restype = ctypes.c_bool
_wasmtime_anyref_as_struct.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_anyref_t), ctypes.POINTER(wasmtime_structref_t)]
def wasmtime_anyref_as_struct(context: Any, anyref: Any, out: Any) -> bool:
    return _wasmtime_anyref_as_struct(context, anyref, out)  # type: ignore

_wasmtime_anyref_is_array = dll.wasmtime_anyref_is_array
_wasmtime_anyref_is_array.restype = ctypes.c_bool
_wasmtime_anyref_is_array.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_anyref_t)]
def wasmtime_anyref_is_array(context: Any, anyref: Any) -> bool:
    return _wasmtime_anyref_is_array(context, anyref)  # type: ignore

_wasmtime_anyref_as_array = dll.wasmtime_anyref_as_array
_wasmtime_anyref_as_array.restype = ctypes.c_bool
_wasmtime_anyref_as_array.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_anyref_t), ctypes.POINTER(wasmtime_arrayref_t)]
def wasmtime_anyref_as_array(context: Any, anyref: Any, out: Any) -> bool:
    return _wasmtime_anyref_as_array(context, anyref, out)  # type: ignore

_wasmtime_anyref_type = dll.wasmtime_anyref_type
_wasmtime_anyref_type.restype = ctypes.c_bool
_wasmtime_anyref_type.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_anyref_t), ctypes.POINTER(wasmtime_heaptype_t)]
def wasmtime_anyref_type(context: Any, anyref: Any, out: Any) -> bool:
    return _wasmtime_anyref_type(context, anyref, out)  # type: ignore

class wasmtime_array_ref_pre(ctypes.Structure):
    pass

wasmtime_array_ref_pre_t = wasmtime_array_ref_pre

_wasmtime_array_ref_pre_new = dll.wasmtime_array_ref_pre_new
_wasmtime_array_ref_pre_new.restype = ctypes.POINTER(wasmtime_array_ref_pre_t)
_wasmtime_array_ref_pre_new.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_array_type_t)]
def wasmtime_array_ref_pre_new(context: Any, ty: Any) -> ctypes._Pointer:
    return _wasmtime_array_ref_pre_new(context, ty)  # type: ignore

_wasmtime_array_ref_pre_delete = dll.wasmtime_array_ref_pre_delete
_wasmtime_array_ref_pre_delete.restype = None
_wasmtime_array_ref_pre_delete.argtypes = [ctypes.POINTER(wasmtime_array_ref_pre_t)]
def wasmtime_array_ref_pre_delete(pre: Any) -> None:
    return _wasmtime_array_ref_pre_delete(pre)  # type: ignore

_wasmtime_arrayref_new = dll.wasmtime_arrayref_new
_wasmtime_arrayref_new.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_arrayref_new.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_array_ref_pre_t), ctypes.POINTER(wasmtime_val_t), ctypes.c_uint32, ctypes.POINTER(wasmtime_arrayref_t)]
def wasmtime_arrayref_new(context: Any, pre: Any, elem: Any, len: Any, out: Any) -> ctypes._Pointer:
    return _wasmtime_arrayref_new(context, pre, elem, len, out)  # type: ignore

_wasmtime_arrayref_clone = dll.wasmtime_arrayref_clone
_wasmtime_arrayref_clone.restype = None
_wasmtime_arrayref_clone.argtypes = [ctypes.POINTER(wasmtime_arrayref_t), ctypes.POINTER(wasmtime_arrayref_t)]
def wasmtime_arrayref_clone(arrayref: Any, out: Any) -> None:
    return _wasmtime_arrayref_clone(arrayref, out)  # type: ignore

_wasmtime_arrayref_unroot = dll.wasmtime_arrayref_unroot
_wasmtime_arrayref_unroot.restype = None
_wasmtime_arrayref_unroot.argtypes = [ctypes.POINTER(wasmtime_arrayref_t)]
def wasmtime_arrayref_unroot(ref: Any) -> None:
    return _wasmtime_arrayref_unroot(ref)  # type: ignore

_wasmtime_arrayref_to_anyref = dll.wasmtime_arrayref_to_anyref
_wasmtime_arrayref_to_anyref.restype = None
_wasmtime_arrayref_to_anyref.argtypes = [ctypes.POINTER(wasmtime_arrayref_t), ctypes.POINTER(wasmtime_anyref_t)]
def wasmtime_arrayref_to_anyref(arrayref: Any, out: Any) -> None:
    return _wasmtime_arrayref_to_anyref(arrayref, out)  # type: ignore

_wasmtime_arrayref_to_eqref = dll.wasmtime_arrayref_to_eqref
_wasmtime_arrayref_to_eqref.restype = None
_wasmtime_arrayref_to_eqref.argtypes = [ctypes.POINTER(wasmtime_arrayref_t), ctypes.POINTER(wasmtime_eqref_t)]
def wasmtime_arrayref_to_eqref(arrayref: Any, out: Any) -> None:
    return _wasmtime_arrayref_to_eqref(arrayref, out)  # type: ignore

_wasmtime_arrayref_len = dll.wasmtime_arrayref_len
_wasmtime_arrayref_len.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_arrayref_len.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_arrayref_t), ctypes.POINTER(ctypes.c_uint32)]
def wasmtime_arrayref_len(context: Any, arrayref: Any, out: Any) -> ctypes._Pointer:
    return _wasmtime_arrayref_len(context, arrayref, out)  # type: ignore

_wasmtime_arrayref_get = dll.wasmtime_arrayref_get
_wasmtime_arrayref_get.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_arrayref_get.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_arrayref_t), ctypes.c_uint32, ctypes.POINTER(wasmtime_val_t)]
def wasmtime_arrayref_get(context: Any, arrayref: Any, index: Any, out: Any) -> ctypes._Pointer:
    return _wasmtime_arrayref_get(context, arrayref, index, out)  # type: ignore

_wasmtime_arrayref_set = dll.wasmtime_arrayref_set
_wasmtime_arrayref_set.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_arrayref_set.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_arrayref_t), ctypes.c_uint32, ctypes.POINTER(wasmtime_val_t)]
def wasmtime_arrayref_set(context: Any, arrayref: Any, index: Any, val: Any) -> ctypes._Pointer:
    return _wasmtime_arrayref_set(context, arrayref, index, val)  # type: ignore

_wasmtime_arrayref_type = dll.wasmtime_arrayref_type
_wasmtime_arrayref_type.restype = ctypes.POINTER(wasmtime_array_type_t)
_wasmtime_arrayref_type.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_arrayref_t)]
def wasmtime_arrayref_type(context: Any, arrayref: Any) -> ctypes._Pointer:
    return _wasmtime_arrayref_type(context, arrayref)  # type: ignore

wasmtime_strategy_t = ctypes.c_uint8

class wasmtime_strategy_enum(Enum):
    WASMTIME_STRATEGY_AUTO = auto()
    WASMTIME_STRATEGY_CRANELIFT = auto()
    WASMTIME_STRATEGY_WINCH = auto()

wasmtime_opt_level_t = ctypes.c_uint8

class wasmtime_opt_level_enum(Enum):
    WASMTIME_OPT_LEVEL_NONE = auto()
    WASMTIME_OPT_LEVEL_SPEED = auto()
    WASMTIME_OPT_LEVEL_SPEED_AND_SIZE = auto()

wasmtime_profiling_strategy_t = ctypes.c_uint8

class wasmtime_profiling_strategy_enum(Enum):
    WASMTIME_PROFILING_STRATEGY_NONE = auto()
    WASMTIME_PROFILING_STRATEGY_JITDUMP = auto()
    WASMTIME_PROFILING_STRATEGY_VTUNE = auto()
    WASMTIME_PROFILING_STRATEGY_PERFMAP = auto()

wasmtime_regalloc_algorithm_t = ctypes.c_uint8

class wasmtime_regalloc_algorithm_enum(Enum):
    WASMTIME_REGALLOC_BACKTRACKING = auto()
    WASMTIME_REGALLOC_SINGLE_PASS = auto()

_wasmtime_config_debug_info_set = dll.wasmtime_config_debug_info_set
_wasmtime_config_debug_info_set.restype = None
_wasmtime_config_debug_info_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_debug_info_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_debug_info_set(arg0, arg1)  # type: ignore

_wasmtime_config_consume_fuel_set = dll.wasmtime_config_consume_fuel_set
_wasmtime_config_consume_fuel_set.restype = None
_wasmtime_config_consume_fuel_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_consume_fuel_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_consume_fuel_set(arg0, arg1)  # type: ignore

_wasmtime_config_epoch_interruption_set = dll.wasmtime_config_epoch_interruption_set
_wasmtime_config_epoch_interruption_set.restype = None
_wasmtime_config_epoch_interruption_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_epoch_interruption_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_epoch_interruption_set(arg0, arg1)  # type: ignore

_wasmtime_config_max_wasm_stack_set = dll.wasmtime_config_max_wasm_stack_set
_wasmtime_config_max_wasm_stack_set.restype = None
_wasmtime_config_max_wasm_stack_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_size_t]
def wasmtime_config_max_wasm_stack_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_max_wasm_stack_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_threads_set = dll.wasmtime_config_wasm_threads_set
_wasmtime_config_wasm_threads_set.restype = None
_wasmtime_config_wasm_threads_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_threads_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_threads_set(arg0, arg1)  # type: ignore

_wasmtime_config_shared_memory_set = dll.wasmtime_config_shared_memory_set
_wasmtime_config_shared_memory_set.restype = None
_wasmtime_config_shared_memory_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_shared_memory_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_shared_memory_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_tail_call_set = dll.wasmtime_config_wasm_tail_call_set
_wasmtime_config_wasm_tail_call_set.restype = None
_wasmtime_config_wasm_tail_call_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_tail_call_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_tail_call_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_reference_types_set = dll.wasmtime_config_wasm_reference_types_set
_wasmtime_config_wasm_reference_types_set.restype = None
_wasmtime_config_wasm_reference_types_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_reference_types_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_reference_types_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_function_references_set = dll.wasmtime_config_wasm_function_references_set
_wasmtime_config_wasm_function_references_set.restype = None
_wasmtime_config_wasm_function_references_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_function_references_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_function_references_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_gc_set = dll.wasmtime_config_wasm_gc_set
_wasmtime_config_wasm_gc_set.restype = None
_wasmtime_config_wasm_gc_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_gc_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_gc_set(arg0, arg1)  # type: ignore

_wasmtime_config_gc_support_set = dll.wasmtime_config_gc_support_set
_wasmtime_config_gc_support_set.restype = None
_wasmtime_config_gc_support_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_gc_support_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_gc_support_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_simd_set = dll.wasmtime_config_wasm_simd_set
_wasmtime_config_wasm_simd_set.restype = None
_wasmtime_config_wasm_simd_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_simd_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_simd_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_relaxed_simd_set = dll.wasmtime_config_wasm_relaxed_simd_set
_wasmtime_config_wasm_relaxed_simd_set.restype = None
_wasmtime_config_wasm_relaxed_simd_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_relaxed_simd_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_relaxed_simd_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_relaxed_simd_deterministic_set = dll.wasmtime_config_wasm_relaxed_simd_deterministic_set
_wasmtime_config_wasm_relaxed_simd_deterministic_set.restype = None
_wasmtime_config_wasm_relaxed_simd_deterministic_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_relaxed_simd_deterministic_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_relaxed_simd_deterministic_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_bulk_memory_set = dll.wasmtime_config_wasm_bulk_memory_set
_wasmtime_config_wasm_bulk_memory_set.restype = None
_wasmtime_config_wasm_bulk_memory_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_bulk_memory_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_bulk_memory_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_multi_value_set = dll.wasmtime_config_wasm_multi_value_set
_wasmtime_config_wasm_multi_value_set.restype = None
_wasmtime_config_wasm_multi_value_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_multi_value_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_multi_value_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_multi_memory_set = dll.wasmtime_config_wasm_multi_memory_set
_wasmtime_config_wasm_multi_memory_set.restype = None
_wasmtime_config_wasm_multi_memory_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_multi_memory_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_multi_memory_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_memory64_set = dll.wasmtime_config_wasm_memory64_set
_wasmtime_config_wasm_memory64_set.restype = None
_wasmtime_config_wasm_memory64_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_memory64_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_memory64_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_wide_arithmetic_set = dll.wasmtime_config_wasm_wide_arithmetic_set
_wasmtime_config_wasm_wide_arithmetic_set.restype = None
_wasmtime_config_wasm_wide_arithmetic_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_wide_arithmetic_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_wide_arithmetic_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_branch_hinting_set = dll.wasmtime_config_wasm_branch_hinting_set
_wasmtime_config_wasm_branch_hinting_set.restype = None
_wasmtime_config_wasm_branch_hinting_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_branch_hinting_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_branch_hinting_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_exceptions_set = dll.wasmtime_config_wasm_exceptions_set
_wasmtime_config_wasm_exceptions_set.restype = None
_wasmtime_config_wasm_exceptions_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_exceptions_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_exceptions_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_custom_page_sizes_set = dll.wasmtime_config_wasm_custom_page_sizes_set
_wasmtime_config_wasm_custom_page_sizes_set.restype = None
_wasmtime_config_wasm_custom_page_sizes_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_custom_page_sizes_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_custom_page_sizes_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_stack_switching_set = dll.wasmtime_config_wasm_stack_switching_set
_wasmtime_config_wasm_stack_switching_set.restype = None
_wasmtime_config_wasm_stack_switching_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_stack_switching_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_stack_switching_set(arg0, arg1)  # type: ignore

_wasmtime_config_strategy_set = dll.wasmtime_config_strategy_set
_wasmtime_config_strategy_set.restype = None
_wasmtime_config_strategy_set.argtypes = [ctypes.POINTER(wasm_config_t), wasmtime_strategy_t]
def wasmtime_config_strategy_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_strategy_set(arg0, arg1)  # type: ignore

_wasmtime_config_parallel_compilation_set = dll.wasmtime_config_parallel_compilation_set
_wasmtime_config_parallel_compilation_set.restype = None
_wasmtime_config_parallel_compilation_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_parallel_compilation_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_parallel_compilation_set(arg0, arg1)  # type: ignore

_wasmtime_config_cranelift_debug_verifier_set = dll.wasmtime_config_cranelift_debug_verifier_set
_wasmtime_config_cranelift_debug_verifier_set.restype = None
_wasmtime_config_cranelift_debug_verifier_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_cranelift_debug_verifier_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_cranelift_debug_verifier_set(arg0, arg1)  # type: ignore

_wasmtime_config_cranelift_nan_canonicalization_set = dll.wasmtime_config_cranelift_nan_canonicalization_set
_wasmtime_config_cranelift_nan_canonicalization_set.restype = None
_wasmtime_config_cranelift_nan_canonicalization_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_cranelift_nan_canonicalization_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_cranelift_nan_canonicalization_set(arg0, arg1)  # type: ignore

_wasmtime_config_cranelift_opt_level_set = dll.wasmtime_config_cranelift_opt_level_set
_wasmtime_config_cranelift_opt_level_set.restype = None
_wasmtime_config_cranelift_opt_level_set.argtypes = [ctypes.POINTER(wasm_config_t), wasmtime_opt_level_t]
def wasmtime_config_cranelift_opt_level_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_cranelift_opt_level_set(arg0, arg1)  # type: ignore

_wasmtime_config_cranelift_regalloc_algorithm_set = dll.wasmtime_config_cranelift_regalloc_algorithm_set
_wasmtime_config_cranelift_regalloc_algorithm_set.restype = None
_wasmtime_config_cranelift_regalloc_algorithm_set.argtypes = [ctypes.POINTER(wasm_config_t), wasmtime_regalloc_algorithm_t]
def wasmtime_config_cranelift_regalloc_algorithm_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_cranelift_regalloc_algorithm_set(arg0, arg1)  # type: ignore

_wasmtime_config_profiler_set = dll.wasmtime_config_profiler_set
_wasmtime_config_profiler_set.restype = None
_wasmtime_config_profiler_set.argtypes = [ctypes.POINTER(wasm_config_t), wasmtime_profiling_strategy_t]
def wasmtime_config_profiler_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_profiler_set(arg0, arg1)  # type: ignore

_wasmtime_config_memory_may_move_set = dll.wasmtime_config_memory_may_move_set
_wasmtime_config_memory_may_move_set.restype = None
_wasmtime_config_memory_may_move_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_memory_may_move_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_memory_may_move_set(arg0, arg1)  # type: ignore

_wasmtime_config_memory_reservation_set = dll.wasmtime_config_memory_reservation_set
_wasmtime_config_memory_reservation_set.restype = None
_wasmtime_config_memory_reservation_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_uint64]
def wasmtime_config_memory_reservation_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_memory_reservation_set(arg0, arg1)  # type: ignore

_wasmtime_config_memory_guard_size_set = dll.wasmtime_config_memory_guard_size_set
_wasmtime_config_memory_guard_size_set.restype = None
_wasmtime_config_memory_guard_size_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_uint64]
def wasmtime_config_memory_guard_size_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_memory_guard_size_set(arg0, arg1)  # type: ignore

_wasmtime_config_memory_reservation_for_growth_set = dll.wasmtime_config_memory_reservation_for_growth_set
_wasmtime_config_memory_reservation_for_growth_set.restype = None
_wasmtime_config_memory_reservation_for_growth_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_uint64]
def wasmtime_config_memory_reservation_for_growth_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_memory_reservation_for_growth_set(arg0, arg1)  # type: ignore

_wasmtime_config_native_unwind_info_set = dll.wasmtime_config_native_unwind_info_set
_wasmtime_config_native_unwind_info_set.restype = None
_wasmtime_config_native_unwind_info_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_native_unwind_info_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_native_unwind_info_set(arg0, arg1)  # type: ignore

_wasmtime_config_cache_config_load = dll.wasmtime_config_cache_config_load
_wasmtime_config_cache_config_load.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_config_cache_config_load.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.POINTER(ctypes.c_char)]
def wasmtime_config_cache_config_load(arg0: Any, arg1: Any) -> ctypes._Pointer:
    return _wasmtime_config_cache_config_load(arg0, arg1)  # type: ignore

_wasmtime_config_target_set = dll.wasmtime_config_target_set
_wasmtime_config_target_set.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_config_target_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.POINTER(ctypes.c_char)]
def wasmtime_config_target_set(arg0: Any, arg1: Any) -> ctypes._Pointer:
    return _wasmtime_config_target_set(arg0, arg1)  # type: ignore

_wasmtime_config_cranelift_flag_enable = dll.wasmtime_config_cranelift_flag_enable
_wasmtime_config_cranelift_flag_enable.restype = None
_wasmtime_config_cranelift_flag_enable.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.POINTER(ctypes.c_char)]
def wasmtime_config_cranelift_flag_enable(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_cranelift_flag_enable(arg0, arg1)  # type: ignore

_wasmtime_config_cranelift_flag_set = dll.wasmtime_config_cranelift_flag_set
_wasmtime_config_cranelift_flag_set.restype = None
_wasmtime_config_cranelift_flag_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.POINTER(ctypes.c_char), ctypes.POINTER(ctypes.c_char)]
def wasmtime_config_cranelift_flag_set(arg0: Any, key: Any, value: Any) -> None:
    return _wasmtime_config_cranelift_flag_set(arg0, key, value)  # type: ignore

_wasmtime_config_macos_use_mach_ports_set = dll.wasmtime_config_macos_use_mach_ports_set
_wasmtime_config_macos_use_mach_ports_set.restype = None
_wasmtime_config_macos_use_mach_ports_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_macos_use_mach_ports_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_macos_use_mach_ports_set(arg0, arg1)  # type: ignore

_wasmtime_config_signals_based_traps_set = dll.wasmtime_config_signals_based_traps_set
_wasmtime_config_signals_based_traps_set.restype = None
_wasmtime_config_signals_based_traps_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_signals_based_traps_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_signals_based_traps_set(arg0, arg1)  # type: ignore

wasmtime_memory_get_callback_t = ctypes.CFUNCTYPE(ctypes.c_size_t, ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(ctypes.c_size_t))

wasmtime_memory_grow_callback_t = ctypes.CFUNCTYPE(ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t)

class wasmtime_linear_memory(ctypes.Structure):
    _fields_ = [
        ("env", ctypes.c_void_p),
        ("get_memory", wasmtime_memory_get_callback_t),
        ("grow_memory", wasmtime_memory_grow_callback_t),
        ("finalizer", ctypes.CFUNCTYPE(None, ctypes.c_void_p)),
    ]
    env: ctypes._Pointer
    get_memory: ctypes._Pointer
    grow_memory: ctypes._Pointer
    finalizer: ctypes._Pointer

wasmtime_linear_memory_t = wasmtime_linear_memory

wasmtime_new_memory_callback_t = ctypes.CFUNCTYPE(ctypes.c_size_t, ctypes.c_void_p, ctypes.POINTER(wasm_memorytype_t), ctypes.c_size_t, ctypes.c_size_t, ctypes.c_size_t, ctypes.c_size_t, ctypes.POINTER(wasmtime_linear_memory_t))

class wasmtime_memory_creator(ctypes.Structure):
    _fields_ = [
        ("env", ctypes.c_void_p),
        ("new_memory", wasmtime_new_memory_callback_t),
        ("finalizer", ctypes.CFUNCTYPE(None, ctypes.c_void_p)),
    ]
    env: ctypes._Pointer
    new_memory: ctypes._Pointer
    finalizer: ctypes._Pointer

wasmtime_memory_creator_t = wasmtime_memory_creator

_wasmtime_config_host_memory_creator_set = dll.wasmtime_config_host_memory_creator_set
_wasmtime_config_host_memory_creator_set.restype = None
_wasmtime_config_host_memory_creator_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.POINTER(wasmtime_memory_creator_t)]
def wasmtime_config_host_memory_creator_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_host_memory_creator_set(arg0, arg1)  # type: ignore

_wasmtime_config_memory_init_cow_set = dll.wasmtime_config_memory_init_cow_set
_wasmtime_config_memory_init_cow_set.restype = None
_wasmtime_config_memory_init_cow_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_memory_init_cow_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_memory_init_cow_set(arg0, arg1)  # type: ignore

class wasmtime_pooling_allocation_config_t(ctypes.Structure):
    pass

_wasmtime_pooling_allocation_config_new = dll.wasmtime_pooling_allocation_config_new
_wasmtime_pooling_allocation_config_new.restype = ctypes.POINTER(wasmtime_pooling_allocation_config_t)
_wasmtime_pooling_allocation_config_new.argtypes = []
def wasmtime_pooling_allocation_config_new() -> ctypes._Pointer:
    return _wasmtime_pooling_allocation_config_new()  # type: ignore

_wasmtime_pooling_allocation_config_delete = dll.wasmtime_pooling_allocation_config_delete
_wasmtime_pooling_allocation_config_delete.restype = None
_wasmtime_pooling_allocation_config_delete.argtypes = [ctypes.POINTER(wasmtime_pooling_allocation_config_t)]
def wasmtime_pooling_allocation_config_delete(arg0: Any) -> None:
    return _wasmtime_pooling_allocation_config_delete(arg0)  # type: ignore

_wasmtime_pooling_allocation_config_max_unused_warm_slots_set = dll.wasmtime_pooling_allocation_config_max_unused_warm_slots_set
_wasmtime_pooling_allocation_config_max_unused_warm_slots_set.restype = None
_wasmtime_pooling_allocation_config_max_unused_warm_slots_set.argtypes = [ctypes.POINTER(wasmtime_pooling_allocation_config_t), ctypes.c_uint32]
def wasmtime_pooling_allocation_config_max_unused_warm_slots_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_pooling_allocation_config_max_unused_warm_slots_set(arg0, arg1)  # type: ignore

_wasmtime_pooling_allocation_config_decommit_batch_size_set = dll.wasmtime_pooling_allocation_config_decommit_batch_size_set
_wasmtime_pooling_allocation_config_decommit_batch_size_set.restype = None
_wasmtime_pooling_allocation_config_decommit_batch_size_set.argtypes = [ctypes.POINTER(wasmtime_pooling_allocation_config_t), ctypes.c_size_t]
def wasmtime_pooling_allocation_config_decommit_batch_size_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_pooling_allocation_config_decommit_batch_size_set(arg0, arg1)  # type: ignore

_wasmtime_pooling_allocation_config_async_stack_keep_resident_set = dll.wasmtime_pooling_allocation_config_async_stack_keep_resident_set
_wasmtime_pooling_allocation_config_async_stack_keep_resident_set.restype = None
_wasmtime_pooling_allocation_config_async_stack_keep_resident_set.argtypes = [ctypes.POINTER(wasmtime_pooling_allocation_config_t), ctypes.c_size_t]
def wasmtime_pooling_allocation_config_async_stack_keep_resident_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_pooling_allocation_config_async_stack_keep_resident_set(arg0, arg1)  # type: ignore

_wasmtime_pooling_allocation_config_linear_memory_keep_resident_set = dll.wasmtime_pooling_allocation_config_linear_memory_keep_resident_set
_wasmtime_pooling_allocation_config_linear_memory_keep_resident_set.restype = None
_wasmtime_pooling_allocation_config_linear_memory_keep_resident_set.argtypes = [ctypes.POINTER(wasmtime_pooling_allocation_config_t), ctypes.c_size_t]
def wasmtime_pooling_allocation_config_linear_memory_keep_resident_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_pooling_allocation_config_linear_memory_keep_resident_set(arg0, arg1)  # type: ignore

_wasmtime_pooling_allocation_config_table_keep_resident_set = dll.wasmtime_pooling_allocation_config_table_keep_resident_set
_wasmtime_pooling_allocation_config_table_keep_resident_set.restype = None
_wasmtime_pooling_allocation_config_table_keep_resident_set.argtypes = [ctypes.POINTER(wasmtime_pooling_allocation_config_t), ctypes.c_size_t]
def wasmtime_pooling_allocation_config_table_keep_resident_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_pooling_allocation_config_table_keep_resident_set(arg0, arg1)  # type: ignore

_wasmtime_pooling_allocation_config_total_component_instances_set = dll.wasmtime_pooling_allocation_config_total_component_instances_set
_wasmtime_pooling_allocation_config_total_component_instances_set.restype = None
_wasmtime_pooling_allocation_config_total_component_instances_set.argtypes = [ctypes.POINTER(wasmtime_pooling_allocation_config_t), ctypes.c_uint32]
def wasmtime_pooling_allocation_config_total_component_instances_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_pooling_allocation_config_total_component_instances_set(arg0, arg1)  # type: ignore

_wasmtime_pooling_allocation_config_max_component_instance_size_set = dll.wasmtime_pooling_allocation_config_max_component_instance_size_set
_wasmtime_pooling_allocation_config_max_component_instance_size_set.restype = None
_wasmtime_pooling_allocation_config_max_component_instance_size_set.argtypes = [ctypes.POINTER(wasmtime_pooling_allocation_config_t), ctypes.c_size_t]
def wasmtime_pooling_allocation_config_max_component_instance_size_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_pooling_allocation_config_max_component_instance_size_set(arg0, arg1)  # type: ignore

_wasmtime_pooling_allocation_config_max_core_instances_per_component_set = dll.wasmtime_pooling_allocation_config_max_core_instances_per_component_set
_wasmtime_pooling_allocation_config_max_core_instances_per_component_set.restype = None
_wasmtime_pooling_allocation_config_max_core_instances_per_component_set.argtypes = [ctypes.POINTER(wasmtime_pooling_allocation_config_t), ctypes.c_uint32]
def wasmtime_pooling_allocation_config_max_core_instances_per_component_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_pooling_allocation_config_max_core_instances_per_component_set(arg0, arg1)  # type: ignore

_wasmtime_pooling_allocation_config_max_memories_per_component_set = dll.wasmtime_pooling_allocation_config_max_memories_per_component_set
_wasmtime_pooling_allocation_config_max_memories_per_component_set.restype = None
_wasmtime_pooling_allocation_config_max_memories_per_component_set.argtypes = [ctypes.POINTER(wasmtime_pooling_allocation_config_t), ctypes.c_uint32]
def wasmtime_pooling_allocation_config_max_memories_per_component_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_pooling_allocation_config_max_memories_per_component_set(arg0, arg1)  # type: ignore

_wasmtime_pooling_allocation_config_max_tables_per_component_set = dll.wasmtime_pooling_allocation_config_max_tables_per_component_set
_wasmtime_pooling_allocation_config_max_tables_per_component_set.restype = None
_wasmtime_pooling_allocation_config_max_tables_per_component_set.argtypes = [ctypes.POINTER(wasmtime_pooling_allocation_config_t), ctypes.c_uint32]
def wasmtime_pooling_allocation_config_max_tables_per_component_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_pooling_allocation_config_max_tables_per_component_set(arg0, arg1)  # type: ignore

_wasmtime_pooling_allocation_config_total_memories_set = dll.wasmtime_pooling_allocation_config_total_memories_set
_wasmtime_pooling_allocation_config_total_memories_set.restype = None
_wasmtime_pooling_allocation_config_total_memories_set.argtypes = [ctypes.POINTER(wasmtime_pooling_allocation_config_t), ctypes.c_uint32]
def wasmtime_pooling_allocation_config_total_memories_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_pooling_allocation_config_total_memories_set(arg0, arg1)  # type: ignore

_wasmtime_pooling_allocation_config_total_tables_set = dll.wasmtime_pooling_allocation_config_total_tables_set
_wasmtime_pooling_allocation_config_total_tables_set.restype = None
_wasmtime_pooling_allocation_config_total_tables_set.argtypes = [ctypes.POINTER(wasmtime_pooling_allocation_config_t), ctypes.c_uint32]
def wasmtime_pooling_allocation_config_total_tables_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_pooling_allocation_config_total_tables_set(arg0, arg1)  # type: ignore

_wasmtime_pooling_allocation_config_total_stacks_set = dll.wasmtime_pooling_allocation_config_total_stacks_set
_wasmtime_pooling_allocation_config_total_stacks_set.restype = None
_wasmtime_pooling_allocation_config_total_stacks_set.argtypes = [ctypes.POINTER(wasmtime_pooling_allocation_config_t), ctypes.c_uint32]
def wasmtime_pooling_allocation_config_total_stacks_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_pooling_allocation_config_total_stacks_set(arg0, arg1)  # type: ignore

_wasmtime_pooling_allocation_config_total_core_instances_set = dll.wasmtime_pooling_allocation_config_total_core_instances_set
_wasmtime_pooling_allocation_config_total_core_instances_set.restype = None
_wasmtime_pooling_allocation_config_total_core_instances_set.argtypes = [ctypes.POINTER(wasmtime_pooling_allocation_config_t), ctypes.c_uint32]
def wasmtime_pooling_allocation_config_total_core_instances_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_pooling_allocation_config_total_core_instances_set(arg0, arg1)  # type: ignore

_wasmtime_pooling_allocation_config_max_core_instance_size_set = dll.wasmtime_pooling_allocation_config_max_core_instance_size_set
_wasmtime_pooling_allocation_config_max_core_instance_size_set.restype = None
_wasmtime_pooling_allocation_config_max_core_instance_size_set.argtypes = [ctypes.POINTER(wasmtime_pooling_allocation_config_t), ctypes.c_size_t]
def wasmtime_pooling_allocation_config_max_core_instance_size_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_pooling_allocation_config_max_core_instance_size_set(arg0, arg1)  # type: ignore

_wasmtime_pooling_allocation_config_max_tables_per_module_set = dll.wasmtime_pooling_allocation_config_max_tables_per_module_set
_wasmtime_pooling_allocation_config_max_tables_per_module_set.restype = None
_wasmtime_pooling_allocation_config_max_tables_per_module_set.argtypes = [ctypes.POINTER(wasmtime_pooling_allocation_config_t), ctypes.c_uint32]
def wasmtime_pooling_allocation_config_max_tables_per_module_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_pooling_allocation_config_max_tables_per_module_set(arg0, arg1)  # type: ignore

_wasmtime_pooling_allocation_config_table_elements_set = dll.wasmtime_pooling_allocation_config_table_elements_set
_wasmtime_pooling_allocation_config_table_elements_set.restype = None
_wasmtime_pooling_allocation_config_table_elements_set.argtypes = [ctypes.POINTER(wasmtime_pooling_allocation_config_t), ctypes.c_size_t]
def wasmtime_pooling_allocation_config_table_elements_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_pooling_allocation_config_table_elements_set(arg0, arg1)  # type: ignore

_wasmtime_pooling_allocation_config_max_memories_per_module_set = dll.wasmtime_pooling_allocation_config_max_memories_per_module_set
_wasmtime_pooling_allocation_config_max_memories_per_module_set.restype = None
_wasmtime_pooling_allocation_config_max_memories_per_module_set.argtypes = [ctypes.POINTER(wasmtime_pooling_allocation_config_t), ctypes.c_uint32]
def wasmtime_pooling_allocation_config_max_memories_per_module_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_pooling_allocation_config_max_memories_per_module_set(arg0, arg1)  # type: ignore

_wasmtime_pooling_allocation_config_max_memory_size_set = dll.wasmtime_pooling_allocation_config_max_memory_size_set
_wasmtime_pooling_allocation_config_max_memory_size_set.restype = None
_wasmtime_pooling_allocation_config_max_memory_size_set.argtypes = [ctypes.POINTER(wasmtime_pooling_allocation_config_t), ctypes.c_size_t]
def wasmtime_pooling_allocation_config_max_memory_size_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_pooling_allocation_config_max_memory_size_set(arg0, arg1)  # type: ignore

_wasmtime_pooling_allocation_config_total_gc_heaps_set = dll.wasmtime_pooling_allocation_config_total_gc_heaps_set
_wasmtime_pooling_allocation_config_total_gc_heaps_set.restype = None
_wasmtime_pooling_allocation_config_total_gc_heaps_set.argtypes = [ctypes.POINTER(wasmtime_pooling_allocation_config_t), ctypes.c_uint32]
def wasmtime_pooling_allocation_config_total_gc_heaps_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_pooling_allocation_config_total_gc_heaps_set(arg0, arg1)  # type: ignore

_wasmtime_pooling_allocation_strategy_set = dll.wasmtime_pooling_allocation_strategy_set
_wasmtime_pooling_allocation_strategy_set.restype = None
_wasmtime_pooling_allocation_strategy_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.POINTER(wasmtime_pooling_allocation_config_t)]
def wasmtime_pooling_allocation_strategy_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_pooling_allocation_strategy_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_component_model_set = dll.wasmtime_config_wasm_component_model_set
_wasmtime_config_wasm_component_model_set.restype = None
_wasmtime_config_wasm_component_model_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_component_model_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_component_model_set(arg0, arg1)  # type: ignore

_wasmtime_config_concurrency_support_set = dll.wasmtime_config_concurrency_support_set
_wasmtime_config_concurrency_support_set.restype = None
_wasmtime_config_concurrency_support_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_concurrency_support_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_concurrency_support_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_component_model_map_set = dll.wasmtime_config_wasm_component_model_map_set
_wasmtime_config_wasm_component_model_map_set.restype = None
_wasmtime_config_wasm_component_model_map_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_component_model_map_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_component_model_map_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_component_model_async_set = dll.wasmtime_config_wasm_component_model_async_set
_wasmtime_config_wasm_component_model_async_set.restype = None
_wasmtime_config_wasm_component_model_async_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_component_model_async_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_component_model_async_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_component_model_more_async_builtins_set = dll.wasmtime_config_wasm_component_model_more_async_builtins_set
_wasmtime_config_wasm_component_model_more_async_builtins_set.restype = None
_wasmtime_config_wasm_component_model_more_async_builtins_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_component_model_more_async_builtins_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_component_model_more_async_builtins_set(arg0, arg1)  # type: ignore

_wasmtime_config_wasm_component_model_async_stackful_set = dll.wasmtime_config_wasm_component_model_async_stackful_set
_wasmtime_config_wasm_component_model_async_stackful_set.restype = None
_wasmtime_config_wasm_component_model_async_stackful_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_bool]
def wasmtime_config_wasm_component_model_async_stackful_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_wasm_component_model_async_stackful_set(arg0, arg1)  # type: ignore

class wasmtime_caller(ctypes.Structure):
    pass

wasmtime_caller_t = wasmtime_caller

wasmtime_func_callback_t = ctypes.CFUNCTYPE(ctypes.c_size_t, ctypes.c_void_p, ctypes.POINTER(wasmtime_caller_t), ctypes.POINTER(wasmtime_val_t), ctypes.c_size_t, ctypes.POINTER(wasmtime_val_t), ctypes.c_size_t)

_wasmtime_func_new = dll.wasmtime_func_new
_wasmtime_func_new.restype = None
_wasmtime_func_new.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasm_functype_t), wasmtime_func_callback_t, ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p), ctypes.POINTER(wasmtime_func_t)]
def wasmtime_func_new(store: Any, type: Any, callback: Any, env: Any, finalizer: Any, ret: Any) -> None:
    return _wasmtime_func_new(store, type, callback, env, finalizer, ret)  # type: ignore

wasmtime_func_unchecked_callback_t = ctypes.CFUNCTYPE(ctypes.c_size_t, ctypes.c_void_p, ctypes.POINTER(wasmtime_caller_t), ctypes.POINTER(wasmtime_val_raw_t), ctypes.c_size_t)

_wasmtime_func_new_unchecked = dll.wasmtime_func_new_unchecked
_wasmtime_func_new_unchecked.restype = None
_wasmtime_func_new_unchecked.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasm_functype_t), wasmtime_func_unchecked_callback_t, ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p), ctypes.POINTER(wasmtime_func_t)]
def wasmtime_func_new_unchecked(store: Any, type: Any, callback: Any, env: Any, finalizer: Any, ret: Any) -> None:
    return _wasmtime_func_new_unchecked(store, type, callback, env, finalizer, ret)  # type: ignore

_wasmtime_func_type = dll.wasmtime_func_type
_wasmtime_func_type.restype = ctypes.POINTER(wasm_functype_t)
_wasmtime_func_type.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_func_t)]
def wasmtime_func_type(store: Any, func: Any) -> ctypes._Pointer:
    return _wasmtime_func_type(store, func)  # type: ignore

_wasmtime_func_call = dll.wasmtime_func_call
_wasmtime_func_call.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_func_call.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_func_t), ctypes.POINTER(wasmtime_val_t), ctypes.c_size_t, ctypes.POINTER(wasmtime_val_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(wasm_trap_t))]
def wasmtime_func_call(store: Any, func: Any, args: Any, nargs: Any, results: Any, nresults: Any, trap: Any) -> ctypes._Pointer:
    return _wasmtime_func_call(store, func, args, nargs, results, nresults, trap)  # type: ignore

_wasmtime_func_call_unchecked = dll.wasmtime_func_call_unchecked
_wasmtime_func_call_unchecked.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_func_call_unchecked.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_func_t), ctypes.POINTER(wasmtime_val_raw_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(wasm_trap_t))]
def wasmtime_func_call_unchecked(store: Any, func: Any, args_and_results: Any, args_and_results_len: Any, trap: Any) -> ctypes._Pointer:
    return _wasmtime_func_call_unchecked(store, func, args_and_results, args_and_results_len, trap)  # type: ignore

_wasmtime_caller_export_get = dll.wasmtime_caller_export_get
_wasmtime_caller_export_get.restype = ctypes.c_bool
_wasmtime_caller_export_get.argtypes = [ctypes.POINTER(wasmtime_caller_t), ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(wasmtime_extern_t)]
def wasmtime_caller_export_get(caller: Any, name: Any, name_len: Any, item: Any) -> bool:
    return _wasmtime_caller_export_get(caller, name, name_len, item)  # type: ignore

_wasmtime_caller_context = dll.wasmtime_caller_context
_wasmtime_caller_context.restype = ctypes.POINTER(wasmtime_context_t)
_wasmtime_caller_context.argtypes = [ctypes.POINTER(wasmtime_caller_t)]
def wasmtime_caller_context(caller: Any) -> ctypes._Pointer:
    return _wasmtime_caller_context(caller)  # type: ignore

_wasmtime_func_from_raw = dll.wasmtime_func_from_raw
_wasmtime_func_from_raw.restype = None
_wasmtime_func_from_raw.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.c_void_p, ctypes.POINTER(wasmtime_func_t)]
def wasmtime_func_from_raw(context: Any, raw: Any, ret: Any) -> None:
    return _wasmtime_func_from_raw(context, raw, ret)  # type: ignore

_wasmtime_func_to_raw = dll.wasmtime_func_to_raw
_wasmtime_func_to_raw.restype = ctypes.c_void_p
_wasmtime_func_to_raw.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_func_t)]
def wasmtime_func_to_raw(context: Any, func: Any) -> ctypes._Pointer:
    return _wasmtime_func_to_raw(context, func)  # type: ignore

class wasmtime_instance(ctypes.Structure):
    _fields_ = [
        ("store_id", ctypes.c_uint64),
        ("__private", ctypes.c_size_t),
    ]
    store_id: int
    __private: int

wasmtime_instance_t = wasmtime_instance

_wasmtime_instance_new = dll.wasmtime_instance_new
_wasmtime_instance_new.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_instance_new.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_module_t), ctypes.POINTER(wasmtime_extern_t), ctypes.c_size_t, ctypes.POINTER(wasmtime_instance_t), ctypes.POINTER(ctypes.POINTER(wasm_trap_t))]
def wasmtime_instance_new(store: Any, module: Any, imports: Any, nimports: Any, instance: Any, trap: Any) -> ctypes._Pointer:
    return _wasmtime_instance_new(store, module, imports, nimports, instance, trap)  # type: ignore

_wasmtime_instance_export_get = dll.wasmtime_instance_export_get
_wasmtime_instance_export_get.restype = ctypes.c_bool
_wasmtime_instance_export_get.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_instance_t), ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(wasmtime_extern_t)]
def wasmtime_instance_export_get(store: Any, instance: Any, name: Any, name_len: Any, item: Any) -> bool:
    return _wasmtime_instance_export_get(store, instance, name, name_len, item)  # type: ignore

_wasmtime_instance_export_nth = dll.wasmtime_instance_export_nth
_wasmtime_instance_export_nth.restype = ctypes.c_bool
_wasmtime_instance_export_nth.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_instance_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(ctypes.c_char)), ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(wasmtime_extern_t)]
def wasmtime_instance_export_nth(store: Any, instance: Any, index: Any, name: Any, name_len: Any, item: Any) -> bool:
    return _wasmtime_instance_export_nth(store, instance, index, name, name_len, item)  # type: ignore

class wasmtime_instance_pre(ctypes.Structure):
    pass

wasmtime_instance_pre_t = wasmtime_instance_pre

_wasmtime_instance_pre_delete = dll.wasmtime_instance_pre_delete
_wasmtime_instance_pre_delete.restype = None
_wasmtime_instance_pre_delete.argtypes = [ctypes.POINTER(wasmtime_instance_pre_t)]
def wasmtime_instance_pre_delete(instance_pre: Any) -> None:
    return _wasmtime_instance_pre_delete(instance_pre)  # type: ignore

_wasmtime_instance_pre_instantiate = dll.wasmtime_instance_pre_instantiate
_wasmtime_instance_pre_instantiate.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_instance_pre_instantiate.argtypes = [ctypes.POINTER(wasmtime_instance_pre_t), ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_instance_t), ctypes.POINTER(ctypes.POINTER(wasm_trap_t))]
def wasmtime_instance_pre_instantiate(instance_pre: Any, store: Any, instance: Any, trap_ptr: Any) -> ctypes._Pointer:
    return _wasmtime_instance_pre_instantiate(instance_pre, store, instance, trap_ptr)  # type: ignore

_wasmtime_instance_pre_module = dll.wasmtime_instance_pre_module
_wasmtime_instance_pre_module.restype = ctypes.POINTER(wasmtime_module_t)
_wasmtime_instance_pre_module.argtypes = [ctypes.POINTER(wasmtime_instance_pre_t)]
def wasmtime_instance_pre_module(instance_pre: Any) -> ctypes._Pointer:
    return _wasmtime_instance_pre_module(instance_pre)  # type: ignore

class wasmtime_linker(ctypes.Structure):
    pass

wasmtime_linker_t = wasmtime_linker

_wasmtime_linker_new = dll.wasmtime_linker_new
_wasmtime_linker_new.restype = ctypes.POINTER(wasmtime_linker_t)
_wasmtime_linker_new.argtypes = [ctypes.POINTER(wasm_engine_t)]
def wasmtime_linker_new(engine: Any) -> ctypes._Pointer:
    return _wasmtime_linker_new(engine)  # type: ignore

_wasmtime_linker_clone = dll.wasmtime_linker_clone
_wasmtime_linker_clone.restype = ctypes.POINTER(wasmtime_linker_t)
_wasmtime_linker_clone.argtypes = [ctypes.POINTER(wasmtime_linker_t)]
def wasmtime_linker_clone(linker: Any) -> ctypes._Pointer:
    return _wasmtime_linker_clone(linker)  # type: ignore

_wasmtime_linker_delete = dll.wasmtime_linker_delete
_wasmtime_linker_delete.restype = None
_wasmtime_linker_delete.argtypes = [ctypes.POINTER(wasmtime_linker_t)]
def wasmtime_linker_delete(linker: Any) -> None:
    return _wasmtime_linker_delete(linker)  # type: ignore

_wasmtime_linker_allow_shadowing = dll.wasmtime_linker_allow_shadowing
_wasmtime_linker_allow_shadowing.restype = None
_wasmtime_linker_allow_shadowing.argtypes = [ctypes.POINTER(wasmtime_linker_t), ctypes.c_bool]
def wasmtime_linker_allow_shadowing(linker: Any, allow_shadowing: Any) -> None:
    return _wasmtime_linker_allow_shadowing(linker, allow_shadowing)  # type: ignore

_wasmtime_linker_define_unknown_imports_as_traps = dll.wasmtime_linker_define_unknown_imports_as_traps
_wasmtime_linker_define_unknown_imports_as_traps.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_linker_define_unknown_imports_as_traps.argtypes = [ctypes.POINTER(wasmtime_linker_t), ctypes.POINTER(wasmtime_module_t)]
def wasmtime_linker_define_unknown_imports_as_traps(linker: Any, module: Any) -> ctypes._Pointer:
    return _wasmtime_linker_define_unknown_imports_as_traps(linker, module)  # type: ignore

_wasmtime_linker_define_unknown_imports_as_default_values = dll.wasmtime_linker_define_unknown_imports_as_default_values
_wasmtime_linker_define_unknown_imports_as_default_values.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_linker_define_unknown_imports_as_default_values.argtypes = [ctypes.POINTER(wasmtime_linker_t), ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_module_t)]
def wasmtime_linker_define_unknown_imports_as_default_values(linker: Any, store: Any, module: Any) -> ctypes._Pointer:
    return _wasmtime_linker_define_unknown_imports_as_default_values(linker, store, module)  # type: ignore

_wasmtime_linker_define = dll.wasmtime_linker_define
_wasmtime_linker_define.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_linker_define.argtypes = [ctypes.POINTER(wasmtime_linker_t), ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(wasmtime_extern_t)]
def wasmtime_linker_define(linker: Any, store: Any, module: Any, module_len: Any, name: Any, name_len: Any, item: Any) -> ctypes._Pointer:
    return _wasmtime_linker_define(linker, store, module, module_len, name, name_len, item)  # type: ignore

_wasmtime_linker_define_func = dll.wasmtime_linker_define_func
_wasmtime_linker_define_func.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_linker_define_func.argtypes = [ctypes.POINTER(wasmtime_linker_t), ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(wasm_functype_t), wasmtime_func_callback_t, ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p)]
def wasmtime_linker_define_func(linker: Any, module: Any, module_len: Any, name: Any, name_len: Any, ty: Any, cb: Any, data: Any, finalizer: Any) -> ctypes._Pointer:
    return _wasmtime_linker_define_func(linker, module, module_len, name, name_len, ty, cb, data, finalizer)  # type: ignore

_wasmtime_linker_define_func_unchecked = dll.wasmtime_linker_define_func_unchecked
_wasmtime_linker_define_func_unchecked.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_linker_define_func_unchecked.argtypes = [ctypes.POINTER(wasmtime_linker_t), ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(wasm_functype_t), wasmtime_func_unchecked_callback_t, ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p)]
def wasmtime_linker_define_func_unchecked(linker: Any, module: Any, module_len: Any, name: Any, name_len: Any, ty: Any, cb: Any, data: Any, finalizer: Any) -> ctypes._Pointer:
    return _wasmtime_linker_define_func_unchecked(linker, module, module_len, name, name_len, ty, cb, data, finalizer)  # type: ignore

_wasmtime_linker_define_wasi = dll.wasmtime_linker_define_wasi
_wasmtime_linker_define_wasi.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_linker_define_wasi.argtypes = [ctypes.POINTER(wasmtime_linker_t)]
def wasmtime_linker_define_wasi(linker: Any) -> ctypes._Pointer:
    return _wasmtime_linker_define_wasi(linker)  # type: ignore

_wasmtime_linker_define_instance = dll.wasmtime_linker_define_instance
_wasmtime_linker_define_instance.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_linker_define_instance.argtypes = [ctypes.POINTER(wasmtime_linker_t), ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(wasmtime_instance_t)]
def wasmtime_linker_define_instance(linker: Any, store: Any, name: Any, name_len: Any, instance: Any) -> ctypes._Pointer:
    return _wasmtime_linker_define_instance(linker, store, name, name_len, instance)  # type: ignore

_wasmtime_linker_instantiate = dll.wasmtime_linker_instantiate
_wasmtime_linker_instantiate.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_linker_instantiate.argtypes = [ctypes.POINTER(wasmtime_linker_t), ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_module_t), ctypes.POINTER(wasmtime_instance_t), ctypes.POINTER(ctypes.POINTER(wasm_trap_t))]
def wasmtime_linker_instantiate(linker: Any, store: Any, module: Any, instance: Any, trap: Any) -> ctypes._Pointer:
    return _wasmtime_linker_instantiate(linker, store, module, instance, trap)  # type: ignore

_wasmtime_linker_module = dll.wasmtime_linker_module
_wasmtime_linker_module.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_linker_module.argtypes = [ctypes.POINTER(wasmtime_linker_t), ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(wasmtime_module_t)]
def wasmtime_linker_module(linker: Any, store: Any, name: Any, name_len: Any, module: Any) -> ctypes._Pointer:
    return _wasmtime_linker_module(linker, store, name, name_len, module)  # type: ignore

_wasmtime_linker_get_default = dll.wasmtime_linker_get_default
_wasmtime_linker_get_default.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_linker_get_default.argtypes = [ctypes.POINTER(wasmtime_linker_t), ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(wasmtime_func_t)]
def wasmtime_linker_get_default(linker: Any, store: Any, name: Any, name_len: Any, func: Any) -> ctypes._Pointer:
    return _wasmtime_linker_get_default(linker, store, name, name_len, func)  # type: ignore

_wasmtime_linker_get = dll.wasmtime_linker_get
_wasmtime_linker_get.restype = ctypes.c_bool
_wasmtime_linker_get.argtypes = [ctypes.POINTER(wasmtime_linker_t), ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(wasmtime_extern_t)]
def wasmtime_linker_get(linker: Any, store: Any, module: Any, module_len: Any, name: Any, name_len: Any, item: Any) -> bool:
    return _wasmtime_linker_get(linker, store, module, module_len, name, name_len, item)  # type: ignore

_wasmtime_linker_instantiate_pre = dll.wasmtime_linker_instantiate_pre
_wasmtime_linker_instantiate_pre.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_linker_instantiate_pre.argtypes = [ctypes.POINTER(wasmtime_linker_t), ctypes.POINTER(wasmtime_module_t), ctypes.POINTER(ctypes.POINTER(wasmtime_instance_pre_t))]
def wasmtime_linker_instantiate_pre(linker: Any, module: Any, instance_pre: Any) -> ctypes._Pointer:
    return _wasmtime_linker_instantiate_pre(linker, module, instance_pre)  # type: ignore

_wasmtime_config_async_stack_size_set = dll.wasmtime_config_async_stack_size_set
_wasmtime_config_async_stack_size_set.restype = None
_wasmtime_config_async_stack_size_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.c_size_t]
def wasmtime_config_async_stack_size_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_async_stack_size_set(arg0, arg1)  # type: ignore

_wasmtime_context_fuel_async_yield_interval = dll.wasmtime_context_fuel_async_yield_interval
_wasmtime_context_fuel_async_yield_interval.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_context_fuel_async_yield_interval.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.c_uint64]
def wasmtime_context_fuel_async_yield_interval(context: Any, interval: Any) -> ctypes._Pointer:
    return _wasmtime_context_fuel_async_yield_interval(context, interval)  # type: ignore

_wasmtime_context_epoch_deadline_async_yield_and_update = dll.wasmtime_context_epoch_deadline_async_yield_and_update
_wasmtime_context_epoch_deadline_async_yield_and_update.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_context_epoch_deadline_async_yield_and_update.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.c_uint64]
def wasmtime_context_epoch_deadline_async_yield_and_update(context: Any, delta: Any) -> ctypes._Pointer:
    return _wasmtime_context_epoch_deadline_async_yield_and_update(context, delta)  # type: ignore

wasmtime_func_async_continuation_callback_t = ctypes.CFUNCTYPE(ctypes.c_bool, ctypes.c_void_p)

class wasmtime_async_continuation_t(ctypes.Structure):
    _fields_ = [
        ("callback", wasmtime_func_async_continuation_callback_t),
        ("env", ctypes.c_void_p),
        ("finalizer", ctypes.CFUNCTYPE(None, ctypes.c_void_p)),
    ]
    callback: ctypes._Pointer
    env: ctypes._Pointer
    finalizer: ctypes._Pointer

wasmtime_func_async_callback_t = ctypes.CFUNCTYPE(None, ctypes.c_void_p, ctypes.POINTER(wasmtime_caller_t), ctypes.POINTER(wasmtime_val_t), ctypes.c_size_t, ctypes.POINTER(wasmtime_val_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(wasm_trap_t)), ctypes.POINTER(wasmtime_async_continuation_t))

class wasmtime_call_future(ctypes.Structure):
    pass

wasmtime_call_future_t = wasmtime_call_future

_wasmtime_call_future_poll = dll.wasmtime_call_future_poll
_wasmtime_call_future_poll.restype = ctypes.c_bool
_wasmtime_call_future_poll.argtypes = [ctypes.POINTER(wasmtime_call_future_t)]
def wasmtime_call_future_poll(future: Any) -> bool:
    return _wasmtime_call_future_poll(future)  # type: ignore

_wasmtime_call_future_delete = dll.wasmtime_call_future_delete
_wasmtime_call_future_delete.restype = None
_wasmtime_call_future_delete.argtypes = [ctypes.POINTER(wasmtime_call_future_t)]
def wasmtime_call_future_delete(future: Any) -> None:
    return _wasmtime_call_future_delete(future)  # type: ignore

_wasmtime_func_call_async = dll.wasmtime_func_call_async
_wasmtime_func_call_async.restype = ctypes.POINTER(wasmtime_call_future_t)
_wasmtime_func_call_async.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_func_t), ctypes.POINTER(wasmtime_val_t), ctypes.c_size_t, ctypes.POINTER(wasmtime_val_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(wasm_trap_t)), ctypes.POINTER(ctypes.POINTER(wasmtime_error_t))]
def wasmtime_func_call_async(context: Any, func: Any, args: Any, nargs: Any, results: Any, nresults: Any, trap_ret: Any, error_ret: Any) -> ctypes._Pointer:
    return _wasmtime_func_call_async(context, func, args, nargs, results, nresults, trap_ret, error_ret)  # type: ignore

_wasmtime_linker_define_async_func = dll.wasmtime_linker_define_async_func
_wasmtime_linker_define_async_func.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_linker_define_async_func.argtypes = [ctypes.POINTER(wasmtime_linker_t), ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(wasm_functype_t), wasmtime_func_async_callback_t, ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p)]
def wasmtime_linker_define_async_func(linker: Any, module: Any, module_len: Any, name: Any, name_len: Any, ty: Any, cb: Any, data: Any, finalizer: Any) -> ctypes._Pointer:
    return _wasmtime_linker_define_async_func(linker, module, module_len, name, name_len, ty, cb, data, finalizer)  # type: ignore

_wasmtime_linker_instantiate_async = dll.wasmtime_linker_instantiate_async
_wasmtime_linker_instantiate_async.restype = ctypes.POINTER(wasmtime_call_future_t)
_wasmtime_linker_instantiate_async.argtypes = [ctypes.POINTER(wasmtime_linker_t), ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_module_t), ctypes.POINTER(wasmtime_instance_t), ctypes.POINTER(ctypes.POINTER(wasm_trap_t)), ctypes.POINTER(ctypes.POINTER(wasmtime_error_t))]
def wasmtime_linker_instantiate_async(linker: Any, store: Any, module: Any, instance: Any, trap_ret: Any, error_ret: Any) -> ctypes._Pointer:
    return _wasmtime_linker_instantiate_async(linker, store, module, instance, trap_ret, error_ret)  # type: ignore

_wasmtime_instance_pre_instantiate_async = dll.wasmtime_instance_pre_instantiate_async
_wasmtime_instance_pre_instantiate_async.restype = ctypes.POINTER(wasmtime_call_future_t)
_wasmtime_instance_pre_instantiate_async.argtypes = [ctypes.POINTER(wasmtime_instance_pre_t), ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_instance_t), ctypes.POINTER(ctypes.POINTER(wasm_trap_t)), ctypes.POINTER(ctypes.POINTER(wasmtime_error_t))]
def wasmtime_instance_pre_instantiate_async(instance_pre: Any, store: Any, instance: Any, trap_ret: Any, error_ret: Any) -> ctypes._Pointer:
    return _wasmtime_instance_pre_instantiate_async(instance_pre, store, instance, trap_ret, error_ret)  # type: ignore

wasmtime_stack_memory_get_callback_t = ctypes.CFUNCTYPE(ctypes.c_size_t, ctypes.c_void_p, ctypes.POINTER(ctypes.c_size_t))

class wasmtime_stack_memory(ctypes.Structure):
    _fields_ = [
        ("env", ctypes.c_void_p),
        ("get_stack_memory", wasmtime_stack_memory_get_callback_t),
        ("finalizer", ctypes.CFUNCTYPE(None, ctypes.c_void_p)),
    ]
    env: ctypes._Pointer
    get_stack_memory: ctypes._Pointer
    finalizer: ctypes._Pointer

wasmtime_stack_memory_t = wasmtime_stack_memory

wasmtime_new_stack_memory_callback_t = ctypes.CFUNCTYPE(ctypes.c_size_t, ctypes.c_void_p, ctypes.c_size_t, ctypes.c_bool, ctypes.POINTER(wasmtime_stack_memory_t))

class wasmtime_stack_creator(ctypes.Structure):
    _fields_ = [
        ("env", ctypes.c_void_p),
        ("new_stack", wasmtime_new_stack_memory_callback_t),
        ("finalizer", ctypes.CFUNCTYPE(None, ctypes.c_void_p)),
    ]
    env: ctypes._Pointer
    new_stack: ctypes._Pointer
    finalizer: ctypes._Pointer

wasmtime_stack_creator_t = wasmtime_stack_creator

_wasmtime_config_host_stack_creator_set = dll.wasmtime_config_host_stack_creator_set
_wasmtime_config_host_stack_creator_set.restype = None
_wasmtime_config_host_stack_creator_set.argtypes = [ctypes.POINTER(wasm_config_t), ctypes.POINTER(wasmtime_stack_creator_t)]
def wasmtime_config_host_stack_creator_set(arg0: Any, arg1: Any) -> None:
    return _wasmtime_config_host_stack_creator_set(arg0, arg1)  # type: ignore

class wasmtime_component_resource_type(ctypes.Structure):
    pass

wasmtime_component_resource_type_t = wasmtime_component_resource_type

_wasmtime_component_resource_type_new_host = dll.wasmtime_component_resource_type_new_host
_wasmtime_component_resource_type_new_host.restype = ctypes.POINTER(wasmtime_component_resource_type_t)
_wasmtime_component_resource_type_new_host.argtypes = [ctypes.c_uint32]
def wasmtime_component_resource_type_new_host(ty: Any) -> ctypes._Pointer:
    return _wasmtime_component_resource_type_new_host(ty)  # type: ignore

_wasmtime_component_resource_type_clone = dll.wasmtime_component_resource_type_clone
_wasmtime_component_resource_type_clone.restype = ctypes.POINTER(wasmtime_component_resource_type_t)
_wasmtime_component_resource_type_clone.argtypes = [ctypes.POINTER(wasmtime_component_resource_type_t)]
def wasmtime_component_resource_type_clone(ty: Any) -> ctypes._Pointer:
    return _wasmtime_component_resource_type_clone(ty)  # type: ignore

_wasmtime_component_resource_type_equal = dll.wasmtime_component_resource_type_equal
_wasmtime_component_resource_type_equal.restype = ctypes.c_bool
_wasmtime_component_resource_type_equal.argtypes = [ctypes.POINTER(wasmtime_component_resource_type_t), ctypes.POINTER(wasmtime_component_resource_type_t)]
def wasmtime_component_resource_type_equal(a: Any, b: Any) -> bool:
    return _wasmtime_component_resource_type_equal(a, b)  # type: ignore

_wasmtime_component_resource_type_delete = dll.wasmtime_component_resource_type_delete
_wasmtime_component_resource_type_delete.restype = None
_wasmtime_component_resource_type_delete.argtypes = [ctypes.POINTER(wasmtime_component_resource_type_t)]
def wasmtime_component_resource_type_delete(resource: Any) -> None:
    return _wasmtime_component_resource_type_delete(resource)  # type: ignore

class wasmtime_component_valtype_t(ctypes.Structure):
    pass

class wasmtime_component_list_type(ctypes.Structure):
    pass

wasmtime_component_list_type_t = wasmtime_component_list_type

_wasmtime_component_list_type_clone = dll.wasmtime_component_list_type_clone
_wasmtime_component_list_type_clone.restype = ctypes.POINTER(wasmtime_component_list_type_t)
_wasmtime_component_list_type_clone.argtypes = [ctypes.POINTER(wasmtime_component_list_type_t)]
def wasmtime_component_list_type_clone(ty: Any) -> ctypes._Pointer:
    return _wasmtime_component_list_type_clone(ty)  # type: ignore

_wasmtime_component_list_type_equal = dll.wasmtime_component_list_type_equal
_wasmtime_component_list_type_equal.restype = ctypes.c_bool
_wasmtime_component_list_type_equal.argtypes = [ctypes.POINTER(wasmtime_component_list_type_t), ctypes.POINTER(wasmtime_component_list_type_t)]
def wasmtime_component_list_type_equal(a: Any, b: Any) -> bool:
    return _wasmtime_component_list_type_equal(a, b)  # type: ignore

_wasmtime_component_list_type_delete = dll.wasmtime_component_list_type_delete
_wasmtime_component_list_type_delete.restype = None
_wasmtime_component_list_type_delete.argtypes = [ctypes.POINTER(wasmtime_component_list_type_t)]
def wasmtime_component_list_type_delete(ptr: Any) -> None:
    return _wasmtime_component_list_type_delete(ptr)  # type: ignore

_wasmtime_component_list_type_element = dll.wasmtime_component_list_type_element
_wasmtime_component_list_type_element.restype = None
_wasmtime_component_list_type_element.argtypes = [ctypes.POINTER(wasmtime_component_list_type_t), ctypes.POINTER(wasmtime_component_valtype_t)]
def wasmtime_component_list_type_element(ty: Any, type_ret: Any) -> None:
    return _wasmtime_component_list_type_element(ty, type_ret)  # type: ignore

class wasmtime_component_record_type(ctypes.Structure):
    pass

wasmtime_component_record_type_t = wasmtime_component_record_type

_wasmtime_component_record_type_clone = dll.wasmtime_component_record_type_clone
_wasmtime_component_record_type_clone.restype = ctypes.POINTER(wasmtime_component_record_type_t)
_wasmtime_component_record_type_clone.argtypes = [ctypes.POINTER(wasmtime_component_record_type_t)]
def wasmtime_component_record_type_clone(ty: Any) -> ctypes._Pointer:
    return _wasmtime_component_record_type_clone(ty)  # type: ignore

_wasmtime_component_record_type_equal = dll.wasmtime_component_record_type_equal
_wasmtime_component_record_type_equal.restype = ctypes.c_bool
_wasmtime_component_record_type_equal.argtypes = [ctypes.POINTER(wasmtime_component_record_type_t), ctypes.POINTER(wasmtime_component_record_type_t)]
def wasmtime_component_record_type_equal(a: Any, b: Any) -> bool:
    return _wasmtime_component_record_type_equal(a, b)  # type: ignore

_wasmtime_component_record_type_delete = dll.wasmtime_component_record_type_delete
_wasmtime_component_record_type_delete.restype = None
_wasmtime_component_record_type_delete.argtypes = [ctypes.POINTER(wasmtime_component_record_type_t)]
def wasmtime_component_record_type_delete(ptr: Any) -> None:
    return _wasmtime_component_record_type_delete(ptr)  # type: ignore

_wasmtime_component_record_type_field_count = dll.wasmtime_component_record_type_field_count
_wasmtime_component_record_type_field_count.restype = ctypes.c_size_t
_wasmtime_component_record_type_field_count.argtypes = [ctypes.POINTER(wasmtime_component_record_type_t)]
def wasmtime_component_record_type_field_count(ty: Any) -> int:
    return _wasmtime_component_record_type_field_count(ty)  # type: ignore

_wasmtime_component_record_type_field_nth = dll.wasmtime_component_record_type_field_nth
_wasmtime_component_record_type_field_nth.restype = ctypes.c_bool
_wasmtime_component_record_type_field_nth.argtypes = [ctypes.POINTER(wasmtime_component_record_type_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(ctypes.c_char)), ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(wasmtime_component_valtype_t)]
def wasmtime_component_record_type_field_nth(ty: Any, nth: Any, name_ret: Any, name_len_ret: Any, type_ret: Any) -> bool:
    return _wasmtime_component_record_type_field_nth(ty, nth, name_ret, name_len_ret, type_ret)  # type: ignore

class wasmtime_component_tuple_type(ctypes.Structure):
    pass

wasmtime_component_tuple_type_t = wasmtime_component_tuple_type

_wasmtime_component_tuple_type_clone = dll.wasmtime_component_tuple_type_clone
_wasmtime_component_tuple_type_clone.restype = ctypes.POINTER(wasmtime_component_tuple_type_t)
_wasmtime_component_tuple_type_clone.argtypes = [ctypes.POINTER(wasmtime_component_tuple_type_t)]
def wasmtime_component_tuple_type_clone(ty: Any) -> ctypes._Pointer:
    return _wasmtime_component_tuple_type_clone(ty)  # type: ignore

_wasmtime_component_tuple_type_equal = dll.wasmtime_component_tuple_type_equal
_wasmtime_component_tuple_type_equal.restype = ctypes.c_bool
_wasmtime_component_tuple_type_equal.argtypes = [ctypes.POINTER(wasmtime_component_tuple_type_t), ctypes.POINTER(wasmtime_component_tuple_type_t)]
def wasmtime_component_tuple_type_equal(a: Any, b: Any) -> bool:
    return _wasmtime_component_tuple_type_equal(a, b)  # type: ignore

_wasmtime_component_tuple_type_delete = dll.wasmtime_component_tuple_type_delete
_wasmtime_component_tuple_type_delete.restype = None
_wasmtime_component_tuple_type_delete.argtypes = [ctypes.POINTER(wasmtime_component_tuple_type_t)]
def wasmtime_component_tuple_type_delete(ptr: Any) -> None:
    return _wasmtime_component_tuple_type_delete(ptr)  # type: ignore

_wasmtime_component_tuple_type_types_count = dll.wasmtime_component_tuple_type_types_count
_wasmtime_component_tuple_type_types_count.restype = ctypes.c_size_t
_wasmtime_component_tuple_type_types_count.argtypes = [ctypes.POINTER(wasmtime_component_tuple_type_t)]
def wasmtime_component_tuple_type_types_count(ty: Any) -> int:
    return _wasmtime_component_tuple_type_types_count(ty)  # type: ignore

_wasmtime_component_tuple_type_types_nth = dll.wasmtime_component_tuple_type_types_nth
_wasmtime_component_tuple_type_types_nth.restype = ctypes.c_bool
_wasmtime_component_tuple_type_types_nth.argtypes = [ctypes.POINTER(wasmtime_component_tuple_type_t), ctypes.c_size_t, ctypes.POINTER(wasmtime_component_valtype_t)]
def wasmtime_component_tuple_type_types_nth(ty: Any, nth: Any, type_ret: Any) -> bool:
    return _wasmtime_component_tuple_type_types_nth(ty, nth, type_ret)  # type: ignore

class wasmtime_component_variant_type(ctypes.Structure):
    pass

wasmtime_component_variant_type_t = wasmtime_component_variant_type

_wasmtime_component_variant_type_clone = dll.wasmtime_component_variant_type_clone
_wasmtime_component_variant_type_clone.restype = ctypes.POINTER(wasmtime_component_variant_type_t)
_wasmtime_component_variant_type_clone.argtypes = [ctypes.POINTER(wasmtime_component_variant_type_t)]
def wasmtime_component_variant_type_clone(ty: Any) -> ctypes._Pointer:
    return _wasmtime_component_variant_type_clone(ty)  # type: ignore

_wasmtime_component_variant_type_equal = dll.wasmtime_component_variant_type_equal
_wasmtime_component_variant_type_equal.restype = ctypes.c_bool
_wasmtime_component_variant_type_equal.argtypes = [ctypes.POINTER(wasmtime_component_variant_type_t), ctypes.POINTER(wasmtime_component_variant_type_t)]
def wasmtime_component_variant_type_equal(a: Any, b: Any) -> bool:
    return _wasmtime_component_variant_type_equal(a, b)  # type: ignore

_wasmtime_component_variant_type_delete = dll.wasmtime_component_variant_type_delete
_wasmtime_component_variant_type_delete.restype = None
_wasmtime_component_variant_type_delete.argtypes = [ctypes.POINTER(wasmtime_component_variant_type_t)]
def wasmtime_component_variant_type_delete(ptr: Any) -> None:
    return _wasmtime_component_variant_type_delete(ptr)  # type: ignore

_wasmtime_component_variant_type_case_count = dll.wasmtime_component_variant_type_case_count
_wasmtime_component_variant_type_case_count.restype = ctypes.c_size_t
_wasmtime_component_variant_type_case_count.argtypes = [ctypes.POINTER(wasmtime_component_variant_type_t)]
def wasmtime_component_variant_type_case_count(ty: Any) -> int:
    return _wasmtime_component_variant_type_case_count(ty)  # type: ignore

_wasmtime_component_variant_type_case_nth = dll.wasmtime_component_variant_type_case_nth
_wasmtime_component_variant_type_case_nth.restype = ctypes.c_bool
_wasmtime_component_variant_type_case_nth.argtypes = [ctypes.POINTER(wasmtime_component_variant_type_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(ctypes.c_char)), ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(ctypes.c_bool), ctypes.POINTER(wasmtime_component_valtype_t)]
def wasmtime_component_variant_type_case_nth(ty: Any, nth: Any, name_ret: Any, name_len_ret: Any, has_payload_ret: Any, payload_ret: Any) -> bool:
    return _wasmtime_component_variant_type_case_nth(ty, nth, name_ret, name_len_ret, has_payload_ret, payload_ret)  # type: ignore

class wasmtime_component_enum_type(ctypes.Structure):
    pass

wasmtime_component_enum_type_t = wasmtime_component_enum_type

_wasmtime_component_enum_type_clone = dll.wasmtime_component_enum_type_clone
_wasmtime_component_enum_type_clone.restype = ctypes.POINTER(wasmtime_component_enum_type_t)
_wasmtime_component_enum_type_clone.argtypes = [ctypes.POINTER(wasmtime_component_enum_type_t)]
def wasmtime_component_enum_type_clone(ty: Any) -> ctypes._Pointer:
    return _wasmtime_component_enum_type_clone(ty)  # type: ignore

_wasmtime_component_enum_type_equal = dll.wasmtime_component_enum_type_equal
_wasmtime_component_enum_type_equal.restype = ctypes.c_bool
_wasmtime_component_enum_type_equal.argtypes = [ctypes.POINTER(wasmtime_component_enum_type_t), ctypes.POINTER(wasmtime_component_enum_type_t)]
def wasmtime_component_enum_type_equal(a: Any, b: Any) -> bool:
    return _wasmtime_component_enum_type_equal(a, b)  # type: ignore

_wasmtime_component_enum_type_delete = dll.wasmtime_component_enum_type_delete
_wasmtime_component_enum_type_delete.restype = None
_wasmtime_component_enum_type_delete.argtypes = [ctypes.POINTER(wasmtime_component_enum_type_t)]
def wasmtime_component_enum_type_delete(ptr: Any) -> None:
    return _wasmtime_component_enum_type_delete(ptr)  # type: ignore

_wasmtime_component_enum_type_names_count = dll.wasmtime_component_enum_type_names_count
_wasmtime_component_enum_type_names_count.restype = ctypes.c_size_t
_wasmtime_component_enum_type_names_count.argtypes = [ctypes.POINTER(wasmtime_component_enum_type_t)]
def wasmtime_component_enum_type_names_count(ty: Any) -> int:
    return _wasmtime_component_enum_type_names_count(ty)  # type: ignore

_wasmtime_component_enum_type_names_nth = dll.wasmtime_component_enum_type_names_nth
_wasmtime_component_enum_type_names_nth.restype = ctypes.c_bool
_wasmtime_component_enum_type_names_nth.argtypes = [ctypes.POINTER(wasmtime_component_enum_type_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(ctypes.c_char)), ctypes.POINTER(ctypes.c_size_t)]
def wasmtime_component_enum_type_names_nth(ty: Any, nth: Any, name_ret: Any, name_len_ret: Any) -> bool:
    return _wasmtime_component_enum_type_names_nth(ty, nth, name_ret, name_len_ret)  # type: ignore

class wasmtime_component_option_type(ctypes.Structure):
    pass

wasmtime_component_option_type_t = wasmtime_component_option_type

_wasmtime_component_option_type_clone = dll.wasmtime_component_option_type_clone
_wasmtime_component_option_type_clone.restype = ctypes.POINTER(wasmtime_component_option_type_t)
_wasmtime_component_option_type_clone.argtypes = [ctypes.POINTER(wasmtime_component_option_type_t)]
def wasmtime_component_option_type_clone(ty: Any) -> ctypes._Pointer:
    return _wasmtime_component_option_type_clone(ty)  # type: ignore

_wasmtime_component_option_type_equal = dll.wasmtime_component_option_type_equal
_wasmtime_component_option_type_equal.restype = ctypes.c_bool
_wasmtime_component_option_type_equal.argtypes = [ctypes.POINTER(wasmtime_component_option_type_t), ctypes.POINTER(wasmtime_component_option_type_t)]
def wasmtime_component_option_type_equal(a: Any, b: Any) -> bool:
    return _wasmtime_component_option_type_equal(a, b)  # type: ignore

_wasmtime_component_option_type_delete = dll.wasmtime_component_option_type_delete
_wasmtime_component_option_type_delete.restype = None
_wasmtime_component_option_type_delete.argtypes = [ctypes.POINTER(wasmtime_component_option_type_t)]
def wasmtime_component_option_type_delete(ptr: Any) -> None:
    return _wasmtime_component_option_type_delete(ptr)  # type: ignore

_wasmtime_component_option_type_ty = dll.wasmtime_component_option_type_ty
_wasmtime_component_option_type_ty.restype = None
_wasmtime_component_option_type_ty.argtypes = [ctypes.POINTER(wasmtime_component_option_type_t), ctypes.POINTER(wasmtime_component_valtype_t)]
def wasmtime_component_option_type_ty(ty: Any, type_ret: Any) -> None:
    return _wasmtime_component_option_type_ty(ty, type_ret)  # type: ignore

class wasmtime_component_result_type(ctypes.Structure):
    pass

wasmtime_component_result_type_t = wasmtime_component_result_type

_wasmtime_component_result_type_clone = dll.wasmtime_component_result_type_clone
_wasmtime_component_result_type_clone.restype = ctypes.POINTER(wasmtime_component_result_type_t)
_wasmtime_component_result_type_clone.argtypes = [ctypes.POINTER(wasmtime_component_result_type_t)]
def wasmtime_component_result_type_clone(ty: Any) -> ctypes._Pointer:
    return _wasmtime_component_result_type_clone(ty)  # type: ignore

_wasmtime_component_result_type_equal = dll.wasmtime_component_result_type_equal
_wasmtime_component_result_type_equal.restype = ctypes.c_bool
_wasmtime_component_result_type_equal.argtypes = [ctypes.POINTER(wasmtime_component_result_type_t), ctypes.POINTER(wasmtime_component_result_type_t)]
def wasmtime_component_result_type_equal(a: Any, b: Any) -> bool:
    return _wasmtime_component_result_type_equal(a, b)  # type: ignore

_wasmtime_component_result_type_delete = dll.wasmtime_component_result_type_delete
_wasmtime_component_result_type_delete.restype = None
_wasmtime_component_result_type_delete.argtypes = [ctypes.POINTER(wasmtime_component_result_type_t)]
def wasmtime_component_result_type_delete(ptr: Any) -> None:
    return _wasmtime_component_result_type_delete(ptr)  # type: ignore

_wasmtime_component_result_type_ok = dll.wasmtime_component_result_type_ok
_wasmtime_component_result_type_ok.restype = ctypes.c_bool
_wasmtime_component_result_type_ok.argtypes = [ctypes.POINTER(wasmtime_component_result_type_t), ctypes.POINTER(wasmtime_component_valtype_t)]
def wasmtime_component_result_type_ok(ty: Any, type_ret: Any) -> bool:
    return _wasmtime_component_result_type_ok(ty, type_ret)  # type: ignore

_wasmtime_component_result_type_err = dll.wasmtime_component_result_type_err
_wasmtime_component_result_type_err.restype = ctypes.c_bool
_wasmtime_component_result_type_err.argtypes = [ctypes.POINTER(wasmtime_component_result_type_t), ctypes.POINTER(wasmtime_component_valtype_t)]
def wasmtime_component_result_type_err(ty: Any, type_ret: Any) -> bool:
    return _wasmtime_component_result_type_err(ty, type_ret)  # type: ignore

class wasmtime_component_flags_type(ctypes.Structure):
    pass

wasmtime_component_flags_type_t = wasmtime_component_flags_type

_wasmtime_component_flags_type_clone = dll.wasmtime_component_flags_type_clone
_wasmtime_component_flags_type_clone.restype = ctypes.POINTER(wasmtime_component_flags_type_t)
_wasmtime_component_flags_type_clone.argtypes = [ctypes.POINTER(wasmtime_component_flags_type_t)]
def wasmtime_component_flags_type_clone(ty: Any) -> ctypes._Pointer:
    return _wasmtime_component_flags_type_clone(ty)  # type: ignore

_wasmtime_component_flags_type_equal = dll.wasmtime_component_flags_type_equal
_wasmtime_component_flags_type_equal.restype = ctypes.c_bool
_wasmtime_component_flags_type_equal.argtypes = [ctypes.POINTER(wasmtime_component_flags_type_t), ctypes.POINTER(wasmtime_component_flags_type_t)]
def wasmtime_component_flags_type_equal(a: Any, b: Any) -> bool:
    return _wasmtime_component_flags_type_equal(a, b)  # type: ignore

_wasmtime_component_flags_type_delete = dll.wasmtime_component_flags_type_delete
_wasmtime_component_flags_type_delete.restype = None
_wasmtime_component_flags_type_delete.argtypes = [ctypes.POINTER(wasmtime_component_flags_type_t)]
def wasmtime_component_flags_type_delete(ptr: Any) -> None:
    return _wasmtime_component_flags_type_delete(ptr)  # type: ignore

_wasmtime_component_flags_type_names_count = dll.wasmtime_component_flags_type_names_count
_wasmtime_component_flags_type_names_count.restype = ctypes.c_size_t
_wasmtime_component_flags_type_names_count.argtypes = [ctypes.POINTER(wasmtime_component_flags_type_t)]
def wasmtime_component_flags_type_names_count(ty: Any) -> int:
    return _wasmtime_component_flags_type_names_count(ty)  # type: ignore

_wasmtime_component_flags_type_names_nth = dll.wasmtime_component_flags_type_names_nth
_wasmtime_component_flags_type_names_nth.restype = ctypes.c_bool
_wasmtime_component_flags_type_names_nth.argtypes = [ctypes.POINTER(wasmtime_component_flags_type_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(ctypes.c_char)), ctypes.POINTER(ctypes.c_size_t)]
def wasmtime_component_flags_type_names_nth(ty: Any, nth: Any, name_ret: Any, name_len_ret: Any) -> bool:
    return _wasmtime_component_flags_type_names_nth(ty, nth, name_ret, name_len_ret)  # type: ignore

class wasmtime_component_future_type(ctypes.Structure):
    pass

wasmtime_component_future_type_t = wasmtime_component_future_type

_wasmtime_component_future_type_clone = dll.wasmtime_component_future_type_clone
_wasmtime_component_future_type_clone.restype = ctypes.POINTER(wasmtime_component_future_type_t)
_wasmtime_component_future_type_clone.argtypes = [ctypes.POINTER(wasmtime_component_future_type_t)]
def wasmtime_component_future_type_clone(ty: Any) -> ctypes._Pointer:
    return _wasmtime_component_future_type_clone(ty)  # type: ignore

_wasmtime_component_future_type_equal = dll.wasmtime_component_future_type_equal
_wasmtime_component_future_type_equal.restype = ctypes.c_bool
_wasmtime_component_future_type_equal.argtypes = [ctypes.POINTER(wasmtime_component_future_type_t), ctypes.POINTER(wasmtime_component_future_type_t)]
def wasmtime_component_future_type_equal(a: Any, b: Any) -> bool:
    return _wasmtime_component_future_type_equal(a, b)  # type: ignore

_wasmtime_component_future_type_delete = dll.wasmtime_component_future_type_delete
_wasmtime_component_future_type_delete.restype = None
_wasmtime_component_future_type_delete.argtypes = [ctypes.POINTER(wasmtime_component_future_type_t)]
def wasmtime_component_future_type_delete(ptr: Any) -> None:
    return _wasmtime_component_future_type_delete(ptr)  # type: ignore

_wasmtime_component_future_type_ty = dll.wasmtime_component_future_type_ty
_wasmtime_component_future_type_ty.restype = ctypes.c_bool
_wasmtime_component_future_type_ty.argtypes = [ctypes.POINTER(wasmtime_component_future_type_t), ctypes.POINTER(wasmtime_component_valtype_t)]
def wasmtime_component_future_type_ty(ty: Any, type_ret: Any) -> bool:
    return _wasmtime_component_future_type_ty(ty, type_ret)  # type: ignore

class wasmtime_component_stream_type(ctypes.Structure):
    pass

wasmtime_component_stream_type_t = wasmtime_component_stream_type

_wasmtime_component_stream_type_clone = dll.wasmtime_component_stream_type_clone
_wasmtime_component_stream_type_clone.restype = ctypes.POINTER(wasmtime_component_stream_type_t)
_wasmtime_component_stream_type_clone.argtypes = [ctypes.POINTER(wasmtime_component_stream_type_t)]
def wasmtime_component_stream_type_clone(ty: Any) -> ctypes._Pointer:
    return _wasmtime_component_stream_type_clone(ty)  # type: ignore

_wasmtime_component_stream_type_equal = dll.wasmtime_component_stream_type_equal
_wasmtime_component_stream_type_equal.restype = ctypes.c_bool
_wasmtime_component_stream_type_equal.argtypes = [ctypes.POINTER(wasmtime_component_stream_type_t), ctypes.POINTER(wasmtime_component_stream_type_t)]
def wasmtime_component_stream_type_equal(a: Any, b: Any) -> bool:
    return _wasmtime_component_stream_type_equal(a, b)  # type: ignore

_wasmtime_component_stream_type_delete = dll.wasmtime_component_stream_type_delete
_wasmtime_component_stream_type_delete.restype = None
_wasmtime_component_stream_type_delete.argtypes = [ctypes.POINTER(wasmtime_component_stream_type_t)]
def wasmtime_component_stream_type_delete(ptr: Any) -> None:
    return _wasmtime_component_stream_type_delete(ptr)  # type: ignore

_wasmtime_component_stream_type_ty = dll.wasmtime_component_stream_type_ty
_wasmtime_component_stream_type_ty.restype = ctypes.c_bool
_wasmtime_component_stream_type_ty.argtypes = [ctypes.POINTER(wasmtime_component_stream_type_t), ctypes.POINTER(wasmtime_component_valtype_t)]
def wasmtime_component_stream_type_ty(ty: Any, type_ret: Any) -> bool:
    return _wasmtime_component_stream_type_ty(ty, type_ret)  # type: ignore

class wasmtime_component_map_type(ctypes.Structure):
    pass

wasmtime_component_map_type_t = wasmtime_component_map_type

_wasmtime_component_map_type_clone = dll.wasmtime_component_map_type_clone
_wasmtime_component_map_type_clone.restype = ctypes.POINTER(wasmtime_component_map_type_t)
_wasmtime_component_map_type_clone.argtypes = [ctypes.POINTER(wasmtime_component_map_type_t)]
def wasmtime_component_map_type_clone(ty: Any) -> ctypes._Pointer:
    return _wasmtime_component_map_type_clone(ty)  # type: ignore

_wasmtime_component_map_type_equal = dll.wasmtime_component_map_type_equal
_wasmtime_component_map_type_equal.restype = ctypes.c_bool
_wasmtime_component_map_type_equal.argtypes = [ctypes.POINTER(wasmtime_component_map_type_t), ctypes.POINTER(wasmtime_component_map_type_t)]
def wasmtime_component_map_type_equal(a: Any, b: Any) -> bool:
    return _wasmtime_component_map_type_equal(a, b)  # type: ignore

_wasmtime_component_map_type_delete = dll.wasmtime_component_map_type_delete
_wasmtime_component_map_type_delete.restype = None
_wasmtime_component_map_type_delete.argtypes = [ctypes.POINTER(wasmtime_component_map_type_t)]
def wasmtime_component_map_type_delete(ptr: Any) -> None:
    return _wasmtime_component_map_type_delete(ptr)  # type: ignore

_wasmtime_component_map_type_key = dll.wasmtime_component_map_type_key
_wasmtime_component_map_type_key.restype = None
_wasmtime_component_map_type_key.argtypes = [ctypes.POINTER(wasmtime_component_map_type_t), ctypes.POINTER(wasmtime_component_valtype_t)]
def wasmtime_component_map_type_key(ty: Any, type_ret: Any) -> None:
    return _wasmtime_component_map_type_key(ty, type_ret)  # type: ignore

_wasmtime_component_map_type_value = dll.wasmtime_component_map_type_value
_wasmtime_component_map_type_value.restype = None
_wasmtime_component_map_type_value.argtypes = [ctypes.POINTER(wasmtime_component_map_type_t), ctypes.POINTER(wasmtime_component_valtype_t)]
def wasmtime_component_map_type_value(ty: Any, type_ret: Any) -> None:
    return _wasmtime_component_map_type_value(ty, type_ret)  # type: ignore

wasmtime_component_valtype_kind_t = ctypes.c_uint8

class wasmtime_component_valtype_union(ctypes.Union):
    _fields_ = [
        ("list", ctypes.POINTER(wasmtime_component_list_type_t)),
        ("record", ctypes.POINTER(wasmtime_component_record_type_t)),
        ("tuple", ctypes.POINTER(wasmtime_component_tuple_type_t)),
        ("variant", ctypes.POINTER(wasmtime_component_variant_type_t)),
        ("enum_", ctypes.POINTER(wasmtime_component_enum_type_t)),
        ("option", ctypes.POINTER(wasmtime_component_option_type_t)),
        ("result", ctypes.POINTER(wasmtime_component_result_type_t)),
        ("flags", ctypes.POINTER(wasmtime_component_flags_type_t)),
        ("own", ctypes.POINTER(wasmtime_component_resource_type_t)),
        ("borrow", ctypes.POINTER(wasmtime_component_resource_type_t)),
        ("future", ctypes.POINTER(wasmtime_component_future_type_t)),
        ("stream", ctypes.POINTER(wasmtime_component_stream_type_t)),
        ("map", ctypes.POINTER(wasmtime_component_map_type_t)),
    ]
    list: ctypes._Pointer
    record: ctypes._Pointer
    tuple: ctypes._Pointer
    variant: ctypes._Pointer
    enum_: ctypes._Pointer
    option: ctypes._Pointer
    result: ctypes._Pointer
    flags: ctypes._Pointer
    own: ctypes._Pointer
    borrow: ctypes._Pointer
    future: ctypes._Pointer
    stream: ctypes._Pointer
    map: ctypes._Pointer

wasmtime_component_valtype_union_t = wasmtime_component_valtype_union

wasmtime_component_valtype_t._fields_ = [
        ("kind", wasmtime_component_valtype_kind_t),
        ("of", wasmtime_component_valtype_union_t),
    ]

_wasmtime_component_valtype_clone = dll.wasmtime_component_valtype_clone
_wasmtime_component_valtype_clone.restype = None
_wasmtime_component_valtype_clone.argtypes = [ctypes.POINTER(wasmtime_component_valtype_t), ctypes.POINTER(wasmtime_component_valtype_t)]
def wasmtime_component_valtype_clone(ty: Any, out: Any) -> None:
    return _wasmtime_component_valtype_clone(ty, out)  # type: ignore

_wasmtime_component_valtype_equal = dll.wasmtime_component_valtype_equal
_wasmtime_component_valtype_equal.restype = ctypes.c_bool
_wasmtime_component_valtype_equal.argtypes = [ctypes.POINTER(wasmtime_component_valtype_t), ctypes.POINTER(wasmtime_component_valtype_t)]
def wasmtime_component_valtype_equal(a: Any, b: Any) -> bool:
    return _wasmtime_component_valtype_equal(a, b)  # type: ignore

_wasmtime_component_valtype_delete = dll.wasmtime_component_valtype_delete
_wasmtime_component_valtype_delete.restype = None
_wasmtime_component_valtype_delete.argtypes = [ctypes.POINTER(wasmtime_component_valtype_t)]
def wasmtime_component_valtype_delete(ptr: Any) -> None:
    return _wasmtime_component_valtype_delete(ptr)  # type: ignore

class wasmtime_component_func_type_t(ctypes.Structure):
    pass

_wasmtime_component_func_type_clone = dll.wasmtime_component_func_type_clone
_wasmtime_component_func_type_clone.restype = ctypes.POINTER(wasmtime_component_func_type_t)
_wasmtime_component_func_type_clone.argtypes = [ctypes.POINTER(wasmtime_component_func_type_t)]
def wasmtime_component_func_type_clone(ty: Any) -> ctypes._Pointer:
    return _wasmtime_component_func_type_clone(ty)  # type: ignore

_wasmtime_component_func_type_delete = dll.wasmtime_component_func_type_delete
_wasmtime_component_func_type_delete.restype = None
_wasmtime_component_func_type_delete.argtypes = [ctypes.POINTER(wasmtime_component_func_type_t)]
def wasmtime_component_func_type_delete(ty: Any) -> None:
    return _wasmtime_component_func_type_delete(ty)  # type: ignore

_wasmtime_component_func_type_async = dll.wasmtime_component_func_type_async
_wasmtime_component_func_type_async.restype = ctypes.c_bool
_wasmtime_component_func_type_async.argtypes = [ctypes.POINTER(wasmtime_component_func_type_t)]
def wasmtime_component_func_type_async(ty: Any) -> bool:
    return _wasmtime_component_func_type_async(ty)  # type: ignore

_wasmtime_component_func_type_param_count = dll.wasmtime_component_func_type_param_count
_wasmtime_component_func_type_param_count.restype = ctypes.c_size_t
_wasmtime_component_func_type_param_count.argtypes = [ctypes.POINTER(wasmtime_component_func_type_t)]
def wasmtime_component_func_type_param_count(ty: Any) -> int:
    return _wasmtime_component_func_type_param_count(ty)  # type: ignore

_wasmtime_component_func_type_param_nth = dll.wasmtime_component_func_type_param_nth
_wasmtime_component_func_type_param_nth.restype = ctypes.c_bool
_wasmtime_component_func_type_param_nth.argtypes = [ctypes.POINTER(wasmtime_component_func_type_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(ctypes.c_char)), ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(wasmtime_component_valtype_t)]
def wasmtime_component_func_type_param_nth(ty: Any, nth: Any, name_ret: Any, name_len_ret: Any, type_ret: Any) -> bool:
    return _wasmtime_component_func_type_param_nth(ty, nth, name_ret, name_len_ret, type_ret)  # type: ignore

_wasmtime_component_func_type_result = dll.wasmtime_component_func_type_result
_wasmtime_component_func_type_result.restype = ctypes.c_bool
_wasmtime_component_func_type_result.argtypes = [ctypes.POINTER(wasmtime_component_func_type_t), ctypes.POINTER(wasmtime_component_valtype_t)]
def wasmtime_component_func_type_result(ty: Any, type_ret: Any) -> bool:
    return _wasmtime_component_func_type_result(ty, type_ret)  # type: ignore

class wasmtime_component_item_t(ctypes.Structure):
    pass

class wasmtime_component_instance_type(ctypes.Structure):
    pass

wasmtime_component_instance_type_t = wasmtime_component_instance_type

_wasmtime_component_instance_type_clone = dll.wasmtime_component_instance_type_clone
_wasmtime_component_instance_type_clone.restype = ctypes.POINTER(wasmtime_component_instance_type_t)
_wasmtime_component_instance_type_clone.argtypes = [ctypes.POINTER(wasmtime_component_instance_type_t)]
def wasmtime_component_instance_type_clone(ty: Any) -> ctypes._Pointer:
    return _wasmtime_component_instance_type_clone(ty)  # type: ignore

_wasmtime_component_instance_type_delete = dll.wasmtime_component_instance_type_delete
_wasmtime_component_instance_type_delete.restype = None
_wasmtime_component_instance_type_delete.argtypes = [ctypes.POINTER(wasmtime_component_instance_type_t)]
def wasmtime_component_instance_type_delete(ty: Any) -> None:
    return _wasmtime_component_instance_type_delete(ty)  # type: ignore

_wasmtime_component_instance_type_export_count = dll.wasmtime_component_instance_type_export_count
_wasmtime_component_instance_type_export_count.restype = ctypes.c_size_t
_wasmtime_component_instance_type_export_count.argtypes = [ctypes.POINTER(wasmtime_component_instance_type_t), ctypes.POINTER(wasm_engine_t)]
def wasmtime_component_instance_type_export_count(ty: Any, engine: Any) -> int:
    return _wasmtime_component_instance_type_export_count(ty, engine)  # type: ignore

_wasmtime_component_instance_type_export_get = dll.wasmtime_component_instance_type_export_get
_wasmtime_component_instance_type_export_get.restype = ctypes.c_bool
_wasmtime_component_instance_type_export_get.argtypes = [ctypes.POINTER(wasmtime_component_instance_type_t), ctypes.POINTER(wasm_engine_t), ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(wasmtime_component_item_t)]
def wasmtime_component_instance_type_export_get(ty: Any, engine: Any, name: Any, name_len: Any, ret: Any) -> bool:
    return _wasmtime_component_instance_type_export_get(ty, engine, name, name_len, ret)  # type: ignore

_wasmtime_component_instance_type_export_nth = dll.wasmtime_component_instance_type_export_nth
_wasmtime_component_instance_type_export_nth.restype = ctypes.c_bool
_wasmtime_component_instance_type_export_nth.argtypes = [ctypes.POINTER(wasmtime_component_instance_type_t), ctypes.POINTER(wasm_engine_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(ctypes.c_char)), ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(wasmtime_component_item_t)]
def wasmtime_component_instance_type_export_nth(ty: Any, engine: Any, nth: Any, name_ret: Any, name_len_ret: Any, type_ret: Any) -> bool:
    return _wasmtime_component_instance_type_export_nth(ty, engine, nth, name_ret, name_len_ret, type_ret)  # type: ignore

class wasmtime_module_type(ctypes.Structure):
    pass

wasmtime_module_type_t = wasmtime_module_type

_wasmtime_module_type_clone = dll.wasmtime_module_type_clone
_wasmtime_module_type_clone.restype = ctypes.POINTER(wasmtime_module_type_t)
_wasmtime_module_type_clone.argtypes = [ctypes.POINTER(wasmtime_module_type_t)]
def wasmtime_module_type_clone(ty: Any) -> ctypes._Pointer:
    return _wasmtime_module_type_clone(ty)  # type: ignore

_wasmtime_module_type_delete = dll.wasmtime_module_type_delete
_wasmtime_module_type_delete.restype = None
_wasmtime_module_type_delete.argtypes = [ctypes.POINTER(wasmtime_module_type_t)]
def wasmtime_module_type_delete(ty: Any) -> None:
    return _wasmtime_module_type_delete(ty)  # type: ignore

_wasmtime_module_type_import_count = dll.wasmtime_module_type_import_count
_wasmtime_module_type_import_count.restype = ctypes.c_size_t
_wasmtime_module_type_import_count.argtypes = [ctypes.POINTER(wasmtime_module_type_t), ctypes.POINTER(wasm_engine_t)]
def wasmtime_module_type_import_count(ty: Any, engine: Any) -> int:
    return _wasmtime_module_type_import_count(ty, engine)  # type: ignore

_wasmtime_module_type_import_nth = dll.wasmtime_module_type_import_nth
_wasmtime_module_type_import_nth.restype = ctypes.POINTER(wasm_importtype_t)
_wasmtime_module_type_import_nth.argtypes = [ctypes.POINTER(wasmtime_module_type_t), ctypes.POINTER(wasm_engine_t), ctypes.c_size_t]
def wasmtime_module_type_import_nth(ty: Any, engine: Any, nth: Any) -> ctypes._Pointer:
    return _wasmtime_module_type_import_nth(ty, engine, nth)  # type: ignore

_wasmtime_module_type_export_count = dll.wasmtime_module_type_export_count
_wasmtime_module_type_export_count.restype = ctypes.c_size_t
_wasmtime_module_type_export_count.argtypes = [ctypes.POINTER(wasmtime_module_type_t), ctypes.POINTER(wasm_engine_t)]
def wasmtime_module_type_export_count(ty: Any, engine: Any) -> int:
    return _wasmtime_module_type_export_count(ty, engine)  # type: ignore

_wasmtime_module_type_export_nth = dll.wasmtime_module_type_export_nth
_wasmtime_module_type_export_nth.restype = ctypes.POINTER(wasm_exporttype_t)
_wasmtime_module_type_export_nth.argtypes = [ctypes.POINTER(wasmtime_module_type_t), ctypes.POINTER(wasm_engine_t), ctypes.c_size_t]
def wasmtime_module_type_export_nth(ty: Any, engine: Any, nth: Any) -> ctypes._Pointer:
    return _wasmtime_module_type_export_nth(ty, engine, nth)  # type: ignore

class wasmtime_component_type_t(ctypes.Structure):
    pass

_wasmtime_component_type_clone = dll.wasmtime_component_type_clone
_wasmtime_component_type_clone.restype = ctypes.POINTER(wasmtime_component_type_t)
_wasmtime_component_type_clone.argtypes = [ctypes.POINTER(wasmtime_component_type_t)]
def wasmtime_component_type_clone(ty: Any) -> ctypes._Pointer:
    return _wasmtime_component_type_clone(ty)  # type: ignore

_wasmtime_component_type_delete = dll.wasmtime_component_type_delete
_wasmtime_component_type_delete.restype = None
_wasmtime_component_type_delete.argtypes = [ctypes.POINTER(wasmtime_component_type_t)]
def wasmtime_component_type_delete(ty: Any) -> None:
    return _wasmtime_component_type_delete(ty)  # type: ignore

_wasmtime_component_type_import_count = dll.wasmtime_component_type_import_count
_wasmtime_component_type_import_count.restype = ctypes.c_size_t
_wasmtime_component_type_import_count.argtypes = [ctypes.POINTER(wasmtime_component_type_t), ctypes.POINTER(wasm_engine_t)]
def wasmtime_component_type_import_count(ty: Any, engine: Any) -> int:
    return _wasmtime_component_type_import_count(ty, engine)  # type: ignore

_wasmtime_component_type_import_get = dll.wasmtime_component_type_import_get
_wasmtime_component_type_import_get.restype = ctypes.c_bool
_wasmtime_component_type_import_get.argtypes = [ctypes.POINTER(wasmtime_component_type_t), ctypes.POINTER(wasm_engine_t), ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(wasmtime_component_item_t)]
def wasmtime_component_type_import_get(ty: Any, engine: Any, name: Any, name_len: Any, ret: Any) -> bool:
    return _wasmtime_component_type_import_get(ty, engine, name, name_len, ret)  # type: ignore

_wasmtime_component_type_import_nth = dll.wasmtime_component_type_import_nth
_wasmtime_component_type_import_nth.restype = ctypes.c_bool
_wasmtime_component_type_import_nth.argtypes = [ctypes.POINTER(wasmtime_component_type_t), ctypes.POINTER(wasm_engine_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(ctypes.c_char)), ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(wasmtime_component_item_t)]
def wasmtime_component_type_import_nth(ty: Any, engine: Any, nth: Any, name_ret: Any, name_len_ret: Any, type_ret: Any) -> bool:
    return _wasmtime_component_type_import_nth(ty, engine, nth, name_ret, name_len_ret, type_ret)  # type: ignore

_wasmtime_component_type_export_count = dll.wasmtime_component_type_export_count
_wasmtime_component_type_export_count.restype = ctypes.c_size_t
_wasmtime_component_type_export_count.argtypes = [ctypes.POINTER(wasmtime_component_type_t), ctypes.POINTER(wasm_engine_t)]
def wasmtime_component_type_export_count(ty: Any, engine: Any) -> int:
    return _wasmtime_component_type_export_count(ty, engine)  # type: ignore

_wasmtime_component_type_export_get = dll.wasmtime_component_type_export_get
_wasmtime_component_type_export_get.restype = ctypes.c_bool
_wasmtime_component_type_export_get.argtypes = [ctypes.POINTER(wasmtime_component_type_t), ctypes.POINTER(wasm_engine_t), ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(wasmtime_component_item_t)]
def wasmtime_component_type_export_get(ty: Any, engine: Any, name: Any, name_len: Any, ret: Any) -> bool:
    return _wasmtime_component_type_export_get(ty, engine, name, name_len, ret)  # type: ignore

_wasmtime_component_type_export_nth = dll.wasmtime_component_type_export_nth
_wasmtime_component_type_export_nth.restype = ctypes.c_bool
_wasmtime_component_type_export_nth.argtypes = [ctypes.POINTER(wasmtime_component_type_t), ctypes.POINTER(wasm_engine_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(ctypes.c_char)), ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(wasmtime_component_item_t)]
def wasmtime_component_type_export_nth(ty: Any, engine: Any, nth: Any, name_ret: Any, name_len_ret: Any, type_ret: Any) -> bool:
    return _wasmtime_component_type_export_nth(ty, engine, nth, name_ret, name_len_ret, type_ret)  # type: ignore

wasmtime_component_item_kind_t = ctypes.c_uint8

class wasmtime_component_item_union(ctypes.Union):
    _fields_ = [
        ("component", ctypes.POINTER(wasmtime_component_type_t)),
        ("component_instance", ctypes.POINTER(wasmtime_component_instance_type_t)),
        ("module", ctypes.POINTER(wasmtime_module_type_t)),
        ("component_func", ctypes.POINTER(wasmtime_component_func_type_t)),
        ("resource", ctypes.POINTER(wasmtime_component_resource_type_t)),
        ("core_func", ctypes.POINTER(wasm_functype_t)),
        ("type", wasmtime_component_valtype_t),
    ]
    component: ctypes._Pointer
    component_instance: ctypes._Pointer
    module: ctypes._Pointer
    component_func: ctypes._Pointer
    resource: ctypes._Pointer
    core_func: ctypes._Pointer
    type: wasmtime_component_valtype_t

wasmtime_component_item_union_t = wasmtime_component_item_union

wasmtime_component_item_t._fields_ = [
        ("kind", wasmtime_component_item_kind_t),
        ("of", wasmtime_component_item_union_t),
    ]

_wasmtime_component_item_clone = dll.wasmtime_component_item_clone
_wasmtime_component_item_clone.restype = None
_wasmtime_component_item_clone.argtypes = [ctypes.POINTER(wasmtime_component_item_t), ctypes.POINTER(wasmtime_component_item_t)]
def wasmtime_component_item_clone(item: Any, out: Any) -> None:
    return _wasmtime_component_item_clone(item, out)  # type: ignore

_wasmtime_component_item_delete = dll.wasmtime_component_item_delete
_wasmtime_component_item_delete.restype = None
_wasmtime_component_item_delete.argtypes = [ctypes.POINTER(wasmtime_component_item_t)]
def wasmtime_component_item_delete(ptr: Any) -> None:
    return _wasmtime_component_item_delete(ptr)  # type: ignore

class wasmtime_component_t(ctypes.Structure):
    pass

_wasmtime_component_new = dll.wasmtime_component_new
_wasmtime_component_new.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_component_new.argtypes = [ctypes.POINTER(wasm_engine_t), ctypes.POINTER(ctypes.c_uint8), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(wasmtime_component_t))]
def wasmtime_component_new(engine: Any, buf: Any, len: Any, component_out: Any) -> ctypes._Pointer:
    return _wasmtime_component_new(engine, buf, len, component_out)  # type: ignore

_wasmtime_component_serialize = dll.wasmtime_component_serialize
_wasmtime_component_serialize.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_component_serialize.argtypes = [ctypes.POINTER(wasmtime_component_t), ctypes.POINTER(wasm_byte_vec_t)]
def wasmtime_component_serialize(component: Any, ret: Any) -> ctypes._Pointer:
    return _wasmtime_component_serialize(component, ret)  # type: ignore

_wasmtime_component_deserialize = dll.wasmtime_component_deserialize
_wasmtime_component_deserialize.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_component_deserialize.argtypes = [ctypes.POINTER(wasm_engine_t), ctypes.POINTER(ctypes.c_uint8), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(wasmtime_component_t))]
def wasmtime_component_deserialize(engine: Any, buf: Any, len: Any, component_out: Any) -> ctypes._Pointer:
    return _wasmtime_component_deserialize(engine, buf, len, component_out)  # type: ignore

_wasmtime_component_deserialize_file = dll.wasmtime_component_deserialize_file
_wasmtime_component_deserialize_file.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_component_deserialize_file.argtypes = [ctypes.POINTER(wasm_engine_t), ctypes.POINTER(ctypes.c_char), ctypes.POINTER(ctypes.POINTER(wasmtime_component_t))]
def wasmtime_component_deserialize_file(engine: Any, path: Any, component_out: Any) -> ctypes._Pointer:
    return _wasmtime_component_deserialize_file(engine, path, component_out)  # type: ignore

_wasmtime_component_clone = dll.wasmtime_component_clone
_wasmtime_component_clone.restype = ctypes.POINTER(wasmtime_component_t)
_wasmtime_component_clone.argtypes = [ctypes.POINTER(wasmtime_component_t)]
def wasmtime_component_clone(component: Any) -> ctypes._Pointer:
    return _wasmtime_component_clone(component)  # type: ignore

_wasmtime_component_type = dll.wasmtime_component_type
_wasmtime_component_type.restype = ctypes.POINTER(wasmtime_component_type_t)
_wasmtime_component_type.argtypes = [ctypes.POINTER(wasmtime_component_t)]
def wasmtime_component_type(component: Any) -> ctypes._Pointer:
    return _wasmtime_component_type(component)  # type: ignore

_wasmtime_component_delete = dll.wasmtime_component_delete
_wasmtime_component_delete.restype = None
_wasmtime_component_delete.argtypes = [ctypes.POINTER(wasmtime_component_t)]
def wasmtime_component_delete(component: Any) -> None:
    return _wasmtime_component_delete(component)  # type: ignore

class wasmtime_component_export_index_t(ctypes.Structure):
    pass

_wasmtime_component_get_export_index = dll.wasmtime_component_get_export_index
_wasmtime_component_get_export_index.restype = ctypes.POINTER(wasmtime_component_export_index_t)
_wasmtime_component_get_export_index.argtypes = [ctypes.POINTER(wasmtime_component_t), ctypes.POINTER(wasmtime_component_export_index_t), ctypes.POINTER(ctypes.c_char), ctypes.c_size_t]
def wasmtime_component_get_export_index(component: Any, instance_export_index: Any, name: Any, name_len: Any) -> ctypes._Pointer:
    return _wasmtime_component_get_export_index(component, instance_export_index, name, name_len)  # type: ignore

_wasmtime_component_export_index_clone = dll.wasmtime_component_export_index_clone
_wasmtime_component_export_index_clone.restype = ctypes.POINTER(wasmtime_component_export_index_t)
_wasmtime_component_export_index_clone.argtypes = [ctypes.POINTER(wasmtime_component_export_index_t)]
def wasmtime_component_export_index_clone(index: Any) -> ctypes._Pointer:
    return _wasmtime_component_export_index_clone(index)  # type: ignore

_wasmtime_component_export_index_delete = dll.wasmtime_component_export_index_delete
_wasmtime_component_export_index_delete.restype = None
_wasmtime_component_export_index_delete.argtypes = [ctypes.POINTER(wasmtime_component_export_index_t)]
def wasmtime_component_export_index_delete(export_index: Any) -> None:
    return _wasmtime_component_export_index_delete(export_index)  # type: ignore

class wasmtime_component_resource_any(ctypes.Structure):
    pass

wasmtime_component_resource_any_t = wasmtime_component_resource_any

_wasmtime_component_resource_any_type = dll.wasmtime_component_resource_any_type
_wasmtime_component_resource_any_type.restype = ctypes.POINTER(wasmtime_component_resource_type_t)
_wasmtime_component_resource_any_type.argtypes = [ctypes.POINTER(wasmtime_component_resource_any_t)]
def wasmtime_component_resource_any_type(resource: Any) -> ctypes._Pointer:
    return _wasmtime_component_resource_any_type(resource)  # type: ignore

_wasmtime_component_resource_any_clone = dll.wasmtime_component_resource_any_clone
_wasmtime_component_resource_any_clone.restype = ctypes.POINTER(wasmtime_component_resource_any_t)
_wasmtime_component_resource_any_clone.argtypes = [ctypes.POINTER(wasmtime_component_resource_any_t)]
def wasmtime_component_resource_any_clone(resource: Any) -> ctypes._Pointer:
    return _wasmtime_component_resource_any_clone(resource)  # type: ignore

_wasmtime_component_resource_any_owned = dll.wasmtime_component_resource_any_owned
_wasmtime_component_resource_any_owned.restype = ctypes.c_bool
_wasmtime_component_resource_any_owned.argtypes = [ctypes.POINTER(wasmtime_component_resource_any_t)]
def wasmtime_component_resource_any_owned(resource: Any) -> bool:
    return _wasmtime_component_resource_any_owned(resource)  # type: ignore

_wasmtime_component_resource_any_drop = dll.wasmtime_component_resource_any_drop
_wasmtime_component_resource_any_drop.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_component_resource_any_drop.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_component_resource_any_t)]
def wasmtime_component_resource_any_drop(ctx: Any, resource: Any) -> ctypes._Pointer:
    return _wasmtime_component_resource_any_drop(ctx, resource)  # type: ignore

_wasmtime_component_resource_any_delete = dll.wasmtime_component_resource_any_delete
_wasmtime_component_resource_any_delete.restype = None
_wasmtime_component_resource_any_delete.argtypes = [ctypes.POINTER(wasmtime_component_resource_any_t)]
def wasmtime_component_resource_any_delete(resource: Any) -> None:
    return _wasmtime_component_resource_any_delete(resource)  # type: ignore

class wasmtime_component_resource_host(ctypes.Structure):
    pass

wasmtime_component_resource_host_t = wasmtime_component_resource_host

_wasmtime_component_resource_host_new = dll.wasmtime_component_resource_host_new
_wasmtime_component_resource_host_new.restype = ctypes.POINTER(wasmtime_component_resource_host_t)
_wasmtime_component_resource_host_new.argtypes = [ctypes.c_bool, ctypes.c_uint32, ctypes.c_uint32]
def wasmtime_component_resource_host_new(owned: Any, rep: Any, ty: Any) -> ctypes._Pointer:
    return _wasmtime_component_resource_host_new(owned, rep, ty)  # type: ignore

_wasmtime_component_resource_host_clone = dll.wasmtime_component_resource_host_clone
_wasmtime_component_resource_host_clone.restype = ctypes.POINTER(wasmtime_component_resource_host_t)
_wasmtime_component_resource_host_clone.argtypes = [ctypes.POINTER(wasmtime_component_resource_host_t)]
def wasmtime_component_resource_host_clone(resource: Any) -> ctypes._Pointer:
    return _wasmtime_component_resource_host_clone(resource)  # type: ignore

_wasmtime_component_resource_host_rep = dll.wasmtime_component_resource_host_rep
_wasmtime_component_resource_host_rep.restype = ctypes.c_uint32
_wasmtime_component_resource_host_rep.argtypes = [ctypes.POINTER(wasmtime_component_resource_host_t)]
def wasmtime_component_resource_host_rep(resource: Any) -> int:
    return _wasmtime_component_resource_host_rep(resource)  # type: ignore

_wasmtime_component_resource_host_type = dll.wasmtime_component_resource_host_type
_wasmtime_component_resource_host_type.restype = ctypes.c_uint32
_wasmtime_component_resource_host_type.argtypes = [ctypes.POINTER(wasmtime_component_resource_host_t)]
def wasmtime_component_resource_host_type(resource: Any) -> int:
    return _wasmtime_component_resource_host_type(resource)  # type: ignore

_wasmtime_component_resource_host_owned = dll.wasmtime_component_resource_host_owned
_wasmtime_component_resource_host_owned.restype = ctypes.c_bool
_wasmtime_component_resource_host_owned.argtypes = [ctypes.POINTER(wasmtime_component_resource_host_t)]
def wasmtime_component_resource_host_owned(resource: Any) -> bool:
    return _wasmtime_component_resource_host_owned(resource)  # type: ignore

_wasmtime_component_resource_host_delete = dll.wasmtime_component_resource_host_delete
_wasmtime_component_resource_host_delete.restype = None
_wasmtime_component_resource_host_delete.argtypes = [ctypes.POINTER(wasmtime_component_resource_host_t)]
def wasmtime_component_resource_host_delete(resource: Any) -> None:
    return _wasmtime_component_resource_host_delete(resource)  # type: ignore

_wasmtime_component_resource_any_to_host = dll.wasmtime_component_resource_any_to_host
_wasmtime_component_resource_any_to_host.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_component_resource_any_to_host.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_component_resource_any_t), ctypes.POINTER(ctypes.POINTER(wasmtime_component_resource_host_t))]
def wasmtime_component_resource_any_to_host(ctx: Any, resource: Any, ret: Any) -> ctypes._Pointer:
    return _wasmtime_component_resource_any_to_host(ctx, resource, ret)  # type: ignore

_wasmtime_component_resource_host_to_any = dll.wasmtime_component_resource_host_to_any
_wasmtime_component_resource_host_to_any.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_component_resource_host_to_any.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_component_resource_host_t), ctypes.POINTER(ctypes.POINTER(wasmtime_component_resource_any_t))]
def wasmtime_component_resource_host_to_any(ctx: Any, resource: Any, ret: Any) -> ctypes._Pointer:
    return _wasmtime_component_resource_host_to_any(ctx, resource, ret)  # type: ignore

wasmtime_component_valkind_t = ctypes.c_uint8

class wasmtime_component_val(ctypes.Structure):
    pass

class wasmtime_component_valrecord_entry(ctypes.Structure):
    pass

class wasmtime_component_valmap_entry(ctypes.Structure):
    pass

class wasmtime_component_vallist(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_size_t),
        ("data", ctypes.POINTER(wasmtime_component_val)),
    ]
    size: int
    data: ctypes._Pointer

wasmtime_component_vallist_t = wasmtime_component_vallist

_wasmtime_component_vallist_new = dll.wasmtime_component_vallist_new
_wasmtime_component_vallist_new.restype = None
_wasmtime_component_vallist_new.argtypes = [ctypes.POINTER(wasmtime_component_vallist_t), ctypes.c_size_t, ctypes.POINTER(wasmtime_component_val)]
def wasmtime_component_vallist_new(out: Any, size: Any, ptr: Any) -> None:
    return _wasmtime_component_vallist_new(out, size, ptr)  # type: ignore

_wasmtime_component_vallist_new_empty = dll.wasmtime_component_vallist_new_empty
_wasmtime_component_vallist_new_empty.restype = None
_wasmtime_component_vallist_new_empty.argtypes = [ctypes.POINTER(wasmtime_component_vallist_t)]
def wasmtime_component_vallist_new_empty(out: Any) -> None:
    return _wasmtime_component_vallist_new_empty(out)  # type: ignore

_wasmtime_component_vallist_new_uninit = dll.wasmtime_component_vallist_new_uninit
_wasmtime_component_vallist_new_uninit.restype = None
_wasmtime_component_vallist_new_uninit.argtypes = [ctypes.POINTER(wasmtime_component_vallist_t), ctypes.c_size_t]
def wasmtime_component_vallist_new_uninit(out: Any, size: Any) -> None:
    return _wasmtime_component_vallist_new_uninit(out, size)  # type: ignore

_wasmtime_component_vallist_copy = dll.wasmtime_component_vallist_copy
_wasmtime_component_vallist_copy.restype = None
_wasmtime_component_vallist_copy.argtypes = [ctypes.POINTER(wasmtime_component_vallist_t), ctypes.POINTER(wasmtime_component_vallist_t)]
def wasmtime_component_vallist_copy(dst: Any, src: Any) -> None:
    return _wasmtime_component_vallist_copy(dst, src)  # type: ignore

_wasmtime_component_vallist_delete = dll.wasmtime_component_vallist_delete
_wasmtime_component_vallist_delete.restype = None
_wasmtime_component_vallist_delete.argtypes = [ctypes.POINTER(wasmtime_component_vallist_t)]
def wasmtime_component_vallist_delete(value: Any) -> None:
    return _wasmtime_component_vallist_delete(value)  # type: ignore

class wasmtime_component_valrecord(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_size_t),
        ("data", ctypes.POINTER(wasmtime_component_valrecord_entry)),
    ]
    size: int
    data: ctypes._Pointer

wasmtime_component_valrecord_t = wasmtime_component_valrecord

_wasmtime_component_valrecord_new = dll.wasmtime_component_valrecord_new
_wasmtime_component_valrecord_new.restype = None
_wasmtime_component_valrecord_new.argtypes = [ctypes.POINTER(wasmtime_component_valrecord_t), ctypes.c_size_t, ctypes.POINTER(wasmtime_component_valrecord_entry)]
def wasmtime_component_valrecord_new(out: Any, size: Any, ptr: Any) -> None:
    return _wasmtime_component_valrecord_new(out, size, ptr)  # type: ignore

_wasmtime_component_valrecord_new_empty = dll.wasmtime_component_valrecord_new_empty
_wasmtime_component_valrecord_new_empty.restype = None
_wasmtime_component_valrecord_new_empty.argtypes = [ctypes.POINTER(wasmtime_component_valrecord_t)]
def wasmtime_component_valrecord_new_empty(out: Any) -> None:
    return _wasmtime_component_valrecord_new_empty(out)  # type: ignore

_wasmtime_component_valrecord_new_uninit = dll.wasmtime_component_valrecord_new_uninit
_wasmtime_component_valrecord_new_uninit.restype = None
_wasmtime_component_valrecord_new_uninit.argtypes = [ctypes.POINTER(wasmtime_component_valrecord_t), ctypes.c_size_t]
def wasmtime_component_valrecord_new_uninit(out: Any, size: Any) -> None:
    return _wasmtime_component_valrecord_new_uninit(out, size)  # type: ignore

_wasmtime_component_valrecord_copy = dll.wasmtime_component_valrecord_copy
_wasmtime_component_valrecord_copy.restype = None
_wasmtime_component_valrecord_copy.argtypes = [ctypes.POINTER(wasmtime_component_valrecord_t), ctypes.POINTER(wasmtime_component_valrecord_t)]
def wasmtime_component_valrecord_copy(dst: Any, src: Any) -> None:
    return _wasmtime_component_valrecord_copy(dst, src)  # type: ignore

_wasmtime_component_valrecord_delete = dll.wasmtime_component_valrecord_delete
_wasmtime_component_valrecord_delete.restype = None
_wasmtime_component_valrecord_delete.argtypes = [ctypes.POINTER(wasmtime_component_valrecord_t)]
def wasmtime_component_valrecord_delete(value: Any) -> None:
    return _wasmtime_component_valrecord_delete(value)  # type: ignore

class wasmtime_component_valtuple(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_size_t),
        ("data", ctypes.POINTER(wasmtime_component_val)),
    ]
    size: int
    data: ctypes._Pointer

wasmtime_component_valtuple_t = wasmtime_component_valtuple

_wasmtime_component_valtuple_new = dll.wasmtime_component_valtuple_new
_wasmtime_component_valtuple_new.restype = None
_wasmtime_component_valtuple_new.argtypes = [ctypes.POINTER(wasmtime_component_valtuple_t), ctypes.c_size_t, ctypes.POINTER(wasmtime_component_val)]
def wasmtime_component_valtuple_new(out: Any, size: Any, ptr: Any) -> None:
    return _wasmtime_component_valtuple_new(out, size, ptr)  # type: ignore

_wasmtime_component_valtuple_new_empty = dll.wasmtime_component_valtuple_new_empty
_wasmtime_component_valtuple_new_empty.restype = None
_wasmtime_component_valtuple_new_empty.argtypes = [ctypes.POINTER(wasmtime_component_valtuple_t)]
def wasmtime_component_valtuple_new_empty(out: Any) -> None:
    return _wasmtime_component_valtuple_new_empty(out)  # type: ignore

_wasmtime_component_valtuple_new_uninit = dll.wasmtime_component_valtuple_new_uninit
_wasmtime_component_valtuple_new_uninit.restype = None
_wasmtime_component_valtuple_new_uninit.argtypes = [ctypes.POINTER(wasmtime_component_valtuple_t), ctypes.c_size_t]
def wasmtime_component_valtuple_new_uninit(out: Any, size: Any) -> None:
    return _wasmtime_component_valtuple_new_uninit(out, size)  # type: ignore

_wasmtime_component_valtuple_copy = dll.wasmtime_component_valtuple_copy
_wasmtime_component_valtuple_copy.restype = None
_wasmtime_component_valtuple_copy.argtypes = [ctypes.POINTER(wasmtime_component_valtuple_t), ctypes.POINTER(wasmtime_component_valtuple_t)]
def wasmtime_component_valtuple_copy(dst: Any, src: Any) -> None:
    return _wasmtime_component_valtuple_copy(dst, src)  # type: ignore

_wasmtime_component_valtuple_delete = dll.wasmtime_component_valtuple_delete
_wasmtime_component_valtuple_delete.restype = None
_wasmtime_component_valtuple_delete.argtypes = [ctypes.POINTER(wasmtime_component_valtuple_t)]
def wasmtime_component_valtuple_delete(value: Any) -> None:
    return _wasmtime_component_valtuple_delete(value)  # type: ignore

class wasmtime_component_valflags(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_size_t),
        ("data", ctypes.POINTER(wasm_name_t)),
    ]
    size: int
    data: ctypes._Pointer

wasmtime_component_valflags_t = wasmtime_component_valflags

_wasmtime_component_valflags_new = dll.wasmtime_component_valflags_new
_wasmtime_component_valflags_new.restype = None
_wasmtime_component_valflags_new.argtypes = [ctypes.POINTER(wasmtime_component_valflags_t), ctypes.c_size_t, ctypes.POINTER(wasm_name_t)]
def wasmtime_component_valflags_new(out: Any, size: Any, ptr: Any) -> None:
    return _wasmtime_component_valflags_new(out, size, ptr)  # type: ignore

_wasmtime_component_valflags_new_empty = dll.wasmtime_component_valflags_new_empty
_wasmtime_component_valflags_new_empty.restype = None
_wasmtime_component_valflags_new_empty.argtypes = [ctypes.POINTER(wasmtime_component_valflags_t)]
def wasmtime_component_valflags_new_empty(out: Any) -> None:
    return _wasmtime_component_valflags_new_empty(out)  # type: ignore

_wasmtime_component_valflags_new_uninit = dll.wasmtime_component_valflags_new_uninit
_wasmtime_component_valflags_new_uninit.restype = None
_wasmtime_component_valflags_new_uninit.argtypes = [ctypes.POINTER(wasmtime_component_valflags_t), ctypes.c_size_t]
def wasmtime_component_valflags_new_uninit(out: Any, size: Any) -> None:
    return _wasmtime_component_valflags_new_uninit(out, size)  # type: ignore

_wasmtime_component_valflags_copy = dll.wasmtime_component_valflags_copy
_wasmtime_component_valflags_copy.restype = None
_wasmtime_component_valflags_copy.argtypes = [ctypes.POINTER(wasmtime_component_valflags_t), ctypes.POINTER(wasmtime_component_valflags_t)]
def wasmtime_component_valflags_copy(dst: Any, src: Any) -> None:
    return _wasmtime_component_valflags_copy(dst, src)  # type: ignore

_wasmtime_component_valflags_delete = dll.wasmtime_component_valflags_delete
_wasmtime_component_valflags_delete.restype = None
_wasmtime_component_valflags_delete.argtypes = [ctypes.POINTER(wasmtime_component_valflags_t)]
def wasmtime_component_valflags_delete(value: Any) -> None:
    return _wasmtime_component_valflags_delete(value)  # type: ignore

class wasmtime_component_valmap(ctypes.Structure):
    _fields_ = [
        ("size", ctypes.c_size_t),
        ("data", ctypes.POINTER(wasmtime_component_valmap_entry)),
    ]
    size: int
    data: ctypes._Pointer

wasmtime_component_valmap_t = wasmtime_component_valmap

_wasmtime_component_valmap_new = dll.wasmtime_component_valmap_new
_wasmtime_component_valmap_new.restype = None
_wasmtime_component_valmap_new.argtypes = [ctypes.POINTER(wasmtime_component_valmap_t), ctypes.c_size_t, ctypes.POINTER(wasmtime_component_valmap_entry)]
def wasmtime_component_valmap_new(out: Any, size: Any, ptr: Any) -> None:
    return _wasmtime_component_valmap_new(out, size, ptr)  # type: ignore

_wasmtime_component_valmap_new_empty = dll.wasmtime_component_valmap_new_empty
_wasmtime_component_valmap_new_empty.restype = None
_wasmtime_component_valmap_new_empty.argtypes = [ctypes.POINTER(wasmtime_component_valmap_t)]
def wasmtime_component_valmap_new_empty(out: Any) -> None:
    return _wasmtime_component_valmap_new_empty(out)  # type: ignore

_wasmtime_component_valmap_new_uninit = dll.wasmtime_component_valmap_new_uninit
_wasmtime_component_valmap_new_uninit.restype = None
_wasmtime_component_valmap_new_uninit.argtypes = [ctypes.POINTER(wasmtime_component_valmap_t), ctypes.c_size_t]
def wasmtime_component_valmap_new_uninit(out: Any, size: Any) -> None:
    return _wasmtime_component_valmap_new_uninit(out, size)  # type: ignore

_wasmtime_component_valmap_copy = dll.wasmtime_component_valmap_copy
_wasmtime_component_valmap_copy.restype = None
_wasmtime_component_valmap_copy.argtypes = [ctypes.POINTER(wasmtime_component_valmap_t), ctypes.POINTER(wasmtime_component_valmap_t)]
def wasmtime_component_valmap_copy(dst: Any, src: Any) -> None:
    return _wasmtime_component_valmap_copy(dst, src)  # type: ignore

_wasmtime_component_valmap_delete = dll.wasmtime_component_valmap_delete
_wasmtime_component_valmap_delete.restype = None
_wasmtime_component_valmap_delete.argtypes = [ctypes.POINTER(wasmtime_component_valmap_t)]
def wasmtime_component_valmap_delete(value: Any) -> None:
    return _wasmtime_component_valmap_delete(value)  # type: ignore

class wasmtime_component_valvariant(ctypes.Structure):
    _fields_ = [
        ("discriminant", wasm_name_t),
        ("val", ctypes.POINTER(wasmtime_component_val)),
    ]
    discriminant: wasm_name_t
    val: ctypes._Pointer

wasmtime_component_valvariant_t = wasmtime_component_valvariant

class wasmtime_component_valresult(ctypes.Structure):
    _fields_ = [
        ("is_ok", ctypes.c_bool),
        ("val", ctypes.POINTER(wasmtime_component_val)),
    ]
    is_ok: bool
    val: ctypes._Pointer

wasmtime_component_valresult_t = wasmtime_component_valresult

class wasmtime_component_valunion(ctypes.Union):
    _fields_ = [
        ("boolean", ctypes.c_bool),
        ("s8", ctypes.c_int8),
        ("u8", ctypes.c_uint8),
        ("s16", ctypes.c_int16),
        ("u16", ctypes.c_uint16),
        ("s32", ctypes.c_int32),
        ("u32", ctypes.c_uint32),
        ("s64", ctypes.c_int64),
        ("u64", ctypes.c_uint64),
        ("f32", ctypes.c_float),
        ("f64", ctypes.c_double),
        ("character", ctypes.c_uint32),
        ("string", wasm_name_t),
        ("list", wasmtime_component_vallist_t),
        ("record", wasmtime_component_valrecord_t),
        ("tuple", wasmtime_component_valtuple_t),
        ("variant", wasmtime_component_valvariant_t),
        ("enumeration", wasm_name_t),
        ("option", ctypes.POINTER(wasmtime_component_val)),
        ("result", wasmtime_component_valresult_t),
        ("flags", wasmtime_component_valflags_t),
        ("map", wasmtime_component_valmap_t),
        ("resource", ctypes.POINTER(wasmtime_component_resource_any_t)),
    ]
    boolean: bool
    s8: ctypes.c_int8
    u8: ctypes.c_uint8
    s16: ctypes.c_int16
    u16: ctypes.c_uint16
    s32: int
    u32: int
    s64: int
    u64: int
    f32: float
    f64: float
    character: int
    string: wasm_name_t
    list: wasmtime_component_vallist_t
    record: wasmtime_component_valrecord_t
    tuple: wasmtime_component_valtuple_t
    variant: wasmtime_component_valvariant_t
    enumeration: wasm_name_t
    option: ctypes._Pointer
    result: wasmtime_component_valresult_t
    flags: wasmtime_component_valflags_t
    map: wasmtime_component_valmap_t
    resource: ctypes._Pointer

wasmtime_component_valunion_t = wasmtime_component_valunion

wasmtime_component_val._fields_ = [
        ("kind", wasmtime_component_valkind_t),
        ("of", wasmtime_component_valunion_t),
    ]

wasmtime_component_val_t = wasmtime_component_val

wasmtime_component_valrecord_entry._fields_ = [
        ("name", wasm_name_t),
        ("val", wasmtime_component_val_t),
    ]

wasmtime_component_valrecord_entry_t = wasmtime_component_valrecord_entry

wasmtime_component_valmap_entry._fields_ = [
        ("key", wasmtime_component_val_t),
        ("value", wasmtime_component_val_t),
    ]

wasmtime_component_valmap_entry_t = wasmtime_component_valmap_entry

_wasmtime_component_val_new = dll.wasmtime_component_val_new
_wasmtime_component_val_new.restype = ctypes.POINTER(wasmtime_component_val_t)
_wasmtime_component_val_new.argtypes = [ctypes.POINTER(wasmtime_component_val_t)]
def wasmtime_component_val_new(val: Any) -> ctypes._Pointer:
    return _wasmtime_component_val_new(val)  # type: ignore

_wasmtime_component_val_free = dll.wasmtime_component_val_free
_wasmtime_component_val_free.restype = None
_wasmtime_component_val_free.argtypes = [ctypes.POINTER(wasmtime_component_val_t)]
def wasmtime_component_val_free(ptr: Any) -> None:
    return _wasmtime_component_val_free(ptr)  # type: ignore

_wasmtime_component_val_clone = dll.wasmtime_component_val_clone
_wasmtime_component_val_clone.restype = None
_wasmtime_component_val_clone.argtypes = [ctypes.POINTER(wasmtime_component_val_t), ctypes.POINTER(wasmtime_component_val_t)]
def wasmtime_component_val_clone(src: Any, dst: Any) -> None:
    return _wasmtime_component_val_clone(src, dst)  # type: ignore

_wasmtime_component_val_delete = dll.wasmtime_component_val_delete
_wasmtime_component_val_delete.restype = None
_wasmtime_component_val_delete.argtypes = [ctypes.POINTER(wasmtime_component_val_t)]
def wasmtime_component_val_delete(value: Any) -> None:
    return _wasmtime_component_val_delete(value)  # type: ignore


class wasmtime_component_func_anon_0(ctypes.Structure):
    _fields_ = [
        ("store_id", ctypes.c_uint64),
        ("__private1", ctypes.c_uint32),
    ]
    store_id: int
    __private1: int
class wasmtime_component_func(ctypes.Structure):
    _fields_ = [
        ("_anon_1", wasmtime_component_func_anon_0),
        ("__private2", ctypes.c_uint32),
    ]
    _anon_1: wasmtime_component_func_anon_0
    __private2: int

wasmtime_component_func_t = wasmtime_component_func

_wasmtime_component_func_type = dll.wasmtime_component_func_type
_wasmtime_component_func_type.restype = ctypes.POINTER(wasmtime_component_func_type_t)
_wasmtime_component_func_type.argtypes = [ctypes.POINTER(wasmtime_component_func_t), ctypes.POINTER(wasmtime_context_t)]
def wasmtime_component_func_type(func: Any, context: Any) -> ctypes._Pointer:
    return _wasmtime_component_func_type(func, context)  # type: ignore

_wasmtime_component_func_call = dll.wasmtime_component_func_call
_wasmtime_component_func_call.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_component_func_call.argtypes = [ctypes.POINTER(wasmtime_component_func_t), ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_component_val_t), ctypes.c_size_t, ctypes.POINTER(wasmtime_component_val_t), ctypes.c_size_t]
def wasmtime_component_func_call(func: Any, context: Any, args: Any, args_size: Any, results: Any, results_size: Any) -> ctypes._Pointer:
    return _wasmtime_component_func_call(func, context, args, args_size, results, results_size)  # type: ignore

_wasmtime_component_func_post_return = dll.wasmtime_component_func_post_return
_wasmtime_component_func_post_return.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_component_func_post_return.argtypes = [ctypes.POINTER(wasmtime_component_func_t), ctypes.POINTER(wasmtime_context_t)]
def wasmtime_component_func_post_return(func: Any, context: Any) -> ctypes._Pointer:
    return _wasmtime_component_func_post_return(func, context)  # type: ignore

_wasmtime_component_func_call_async = dll.wasmtime_component_func_call_async
_wasmtime_component_func_call_async.restype = ctypes.POINTER(wasmtime_call_future_t)
_wasmtime_component_func_call_async.argtypes = [ctypes.POINTER(wasmtime_component_func_t), ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_component_val_t), ctypes.c_size_t, ctypes.POINTER(wasmtime_component_val_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(wasmtime_error_t))]
def wasmtime_component_func_call_async(func: Any, context: Any, args: Any, args_size: Any, results: Any, results_size: Any, error_ret: Any) -> ctypes._Pointer:
    return _wasmtime_component_func_call_async(func, context, args, args_size, results, results_size, error_ret)  # type: ignore

class wasmtime_component_instance(ctypes.Structure):
    _fields_ = [
        ("store_id", ctypes.c_uint64),
        ("__private", ctypes.c_uint32),
    ]
    store_id: int
    __private: int

wasmtime_component_instance_t = wasmtime_component_instance

_wasmtime_component_instance_get_export_index = dll.wasmtime_component_instance_get_export_index
_wasmtime_component_instance_get_export_index.restype = ctypes.POINTER(wasmtime_component_export_index_t)
_wasmtime_component_instance_get_export_index.argtypes = [ctypes.POINTER(wasmtime_component_instance_t), ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_component_export_index_t), ctypes.POINTER(ctypes.c_char), ctypes.c_size_t]
def wasmtime_component_instance_get_export_index(instance: Any, context: Any, instance_export_index: Any, name: Any, name_len: Any) -> ctypes._Pointer:
    return _wasmtime_component_instance_get_export_index(instance, context, instance_export_index, name, name_len)  # type: ignore

_wasmtime_component_instance_get_func = dll.wasmtime_component_instance_get_func
_wasmtime_component_instance_get_func.restype = ctypes.c_bool
_wasmtime_component_instance_get_func.argtypes = [ctypes.POINTER(wasmtime_component_instance_t), ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_component_export_index_t), ctypes.POINTER(wasmtime_component_func_t)]
def wasmtime_component_instance_get_func(instance: Any, context: Any, export_index: Any, func_out: Any) -> bool:
    return _wasmtime_component_instance_get_func(instance, context, export_index, func_out)  # type: ignore

class wasmtime_component_linker_t(ctypes.Structure):
    pass

class wasmtime_component_linker_instance_t(ctypes.Structure):
    pass

_wasmtime_component_linker_new = dll.wasmtime_component_linker_new
_wasmtime_component_linker_new.restype = ctypes.POINTER(wasmtime_component_linker_t)
_wasmtime_component_linker_new.argtypes = [ctypes.POINTER(wasm_engine_t)]
def wasmtime_component_linker_new(engine: Any) -> ctypes._Pointer:
    return _wasmtime_component_linker_new(engine)  # type: ignore

_wasmtime_component_linker_allow_shadowing = dll.wasmtime_component_linker_allow_shadowing
_wasmtime_component_linker_allow_shadowing.restype = None
_wasmtime_component_linker_allow_shadowing.argtypes = [ctypes.POINTER(wasmtime_component_linker_t), ctypes.c_bool]
def wasmtime_component_linker_allow_shadowing(linker: Any, allow: Any) -> None:
    return _wasmtime_component_linker_allow_shadowing(linker, allow)  # type: ignore

_wasmtime_component_linker_root = dll.wasmtime_component_linker_root
_wasmtime_component_linker_root.restype = ctypes.POINTER(wasmtime_component_linker_instance_t)
_wasmtime_component_linker_root.argtypes = [ctypes.POINTER(wasmtime_component_linker_t)]
def wasmtime_component_linker_root(linker: Any) -> ctypes._Pointer:
    return _wasmtime_component_linker_root(linker)  # type: ignore

_wasmtime_component_linker_instantiate = dll.wasmtime_component_linker_instantiate
_wasmtime_component_linker_instantiate.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_component_linker_instantiate.argtypes = [ctypes.POINTER(wasmtime_component_linker_t), ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_component_t), ctypes.POINTER(wasmtime_component_instance_t)]
def wasmtime_component_linker_instantiate(linker: Any, context: Any, component: Any, instance_out: Any) -> ctypes._Pointer:
    return _wasmtime_component_linker_instantiate(linker, context, component, instance_out)  # type: ignore

_wasmtime_component_linker_define_unknown_imports_as_traps = dll.wasmtime_component_linker_define_unknown_imports_as_traps
_wasmtime_component_linker_define_unknown_imports_as_traps.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_component_linker_define_unknown_imports_as_traps.argtypes = [ctypes.POINTER(wasmtime_component_linker_t), ctypes.POINTER(wasmtime_component_t)]
def wasmtime_component_linker_define_unknown_imports_as_traps(linker: Any, component: Any) -> ctypes._Pointer:
    return _wasmtime_component_linker_define_unknown_imports_as_traps(linker, component)  # type: ignore

_wasmtime_component_linker_delete = dll.wasmtime_component_linker_delete
_wasmtime_component_linker_delete.restype = None
_wasmtime_component_linker_delete.argtypes = [ctypes.POINTER(wasmtime_component_linker_t)]
def wasmtime_component_linker_delete(linker: Any) -> None:
    return _wasmtime_component_linker_delete(linker)  # type: ignore

_wasmtime_component_linker_instance_add_instance = dll.wasmtime_component_linker_instance_add_instance
_wasmtime_component_linker_instance_add_instance.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_component_linker_instance_add_instance.argtypes = [ctypes.POINTER(wasmtime_component_linker_instance_t), ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(wasmtime_component_linker_instance_t))]
def wasmtime_component_linker_instance_add_instance(linker_instance: Any, name: Any, name_len: Any, linker_instance_out: Any) -> ctypes._Pointer:
    return _wasmtime_component_linker_instance_add_instance(linker_instance, name, name_len, linker_instance_out)  # type: ignore

_wasmtime_component_linker_instance_add_module = dll.wasmtime_component_linker_instance_add_module
_wasmtime_component_linker_instance_add_module.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_component_linker_instance_add_module.argtypes = [ctypes.POINTER(wasmtime_component_linker_instance_t), ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(wasmtime_module_t)]
def wasmtime_component_linker_instance_add_module(linker_instance: Any, name: Any, name_len: Any, module: Any) -> ctypes._Pointer:
    return _wasmtime_component_linker_instance_add_module(linker_instance, name, name_len, module)  # type: ignore

wasmtime_component_func_callback_t = ctypes.CFUNCTYPE(ctypes.c_size_t, ctypes.c_void_p, ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_component_func_type_t), ctypes.POINTER(wasmtime_component_val_t), ctypes.c_size_t, ctypes.POINTER(wasmtime_component_val_t), ctypes.c_size_t)

_wasmtime_component_linker_instance_add_func = dll.wasmtime_component_linker_instance_add_func
_wasmtime_component_linker_instance_add_func.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_component_linker_instance_add_func.argtypes = [ctypes.POINTER(wasmtime_component_linker_instance_t), ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, wasmtime_component_func_callback_t, ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p)]
def wasmtime_component_linker_instance_add_func(linker_instance: Any, name: Any, name_len: Any, callback: Any, data: Any, finalizer: Any) -> ctypes._Pointer:
    return _wasmtime_component_linker_instance_add_func(linker_instance, name, name_len, callback, data, finalizer)  # type: ignore

_wasmtime_component_linker_add_wasip2 = dll.wasmtime_component_linker_add_wasip2
_wasmtime_component_linker_add_wasip2.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_component_linker_add_wasip2.argtypes = [ctypes.POINTER(wasmtime_component_linker_t)]
def wasmtime_component_linker_add_wasip2(linker: Any) -> ctypes._Pointer:
    return _wasmtime_component_linker_add_wasip2(linker)  # type: ignore

_wasmtime_component_linker_add_wasi_http = dll.wasmtime_component_linker_add_wasi_http
_wasmtime_component_linker_add_wasi_http.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_component_linker_add_wasi_http.argtypes = [ctypes.POINTER(wasmtime_component_linker_t)]
def wasmtime_component_linker_add_wasi_http(linker: Any) -> ctypes._Pointer:
    return _wasmtime_component_linker_add_wasi_http(linker)  # type: ignore

wasmtime_component_resource_destructor_t = ctypes.CFUNCTYPE(ctypes.c_size_t, ctypes.c_void_p, ctypes.POINTER(wasmtime_context_t), ctypes.c_uint32)

_wasmtime_component_linker_instance_add_resource = dll.wasmtime_component_linker_instance_add_resource
_wasmtime_component_linker_instance_add_resource.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_component_linker_instance_add_resource.argtypes = [ctypes.POINTER(wasmtime_component_linker_instance_t), ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(wasmtime_component_resource_type_t), wasmtime_component_resource_destructor_t, ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p)]
def wasmtime_component_linker_instance_add_resource(linker_instance: Any, name: Any, name_len: Any, resource: Any, destructor: Any, data: Any, finalizer: Any) -> ctypes._Pointer:
    return _wasmtime_component_linker_instance_add_resource(linker_instance, name, name_len, resource, destructor, data, finalizer)  # type: ignore

_wasmtime_component_linker_instance_delete = dll.wasmtime_component_linker_instance_delete
_wasmtime_component_linker_instance_delete.restype = None
_wasmtime_component_linker_instance_delete.argtypes = [ctypes.POINTER(wasmtime_component_linker_instance_t)]
def wasmtime_component_linker_instance_delete(linker_instance: Any) -> None:
    return _wasmtime_component_linker_instance_delete(linker_instance)  # type: ignore

_wasmtime_component_linker_instantiate_async = dll.wasmtime_component_linker_instantiate_async
_wasmtime_component_linker_instantiate_async.restype = ctypes.POINTER(wasmtime_call_future_t)
_wasmtime_component_linker_instantiate_async.argtypes = [ctypes.POINTER(wasmtime_component_linker_t), ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_component_t), ctypes.POINTER(wasmtime_component_instance_t), ctypes.POINTER(ctypes.POINTER(wasmtime_error_t))]
def wasmtime_component_linker_instantiate_async(linker: Any, context: Any, component: Any, instance_out: Any, error_ret: Any) -> ctypes._Pointer:
    return _wasmtime_component_linker_instantiate_async(linker, context, component, instance_out, error_ret)  # type: ignore

wasmtime_component_func_async_callback_t = ctypes.CFUNCTYPE(None, ctypes.c_void_p, ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_component_func_type_t), ctypes.POINTER(wasmtime_component_val_t), ctypes.c_size_t, ctypes.POINTER(wasmtime_component_val_t), ctypes.c_size_t, ctypes.POINTER(ctypes.POINTER(wasmtime_error_t)), ctypes.POINTER(wasmtime_async_continuation_t))

_wasmtime_component_linker_instance_add_func_async = dll.wasmtime_component_linker_instance_add_func_async
_wasmtime_component_linker_instance_add_func_async.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_component_linker_instance_add_func_async.argtypes = [ctypes.POINTER(wasmtime_component_linker_instance_t), ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, wasmtime_component_func_async_callback_t, ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p)]
def wasmtime_component_linker_instance_add_func_async(linker_instance: Any, name: Any, name_len: Any, callback: Any, data: Any, finalizer: Any) -> ctypes._Pointer:
    return _wasmtime_component_linker_instance_add_func_async(linker_instance, name, name_len, callback, data, finalizer)  # type: ignore

_wasmtime_component_linker_add_wasip2_async = dll.wasmtime_component_linker_add_wasip2_async
_wasmtime_component_linker_add_wasip2_async.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_component_linker_add_wasip2_async.argtypes = [ctypes.POINTER(wasmtime_component_linker_t)]
def wasmtime_component_linker_add_wasip2_async(linker: Any) -> ctypes._Pointer:
    return _wasmtime_component_linker_add_wasip2_async(linker)  # type: ignore

_wasmtime_component_linker_add_wasi_http_async = dll.wasmtime_component_linker_add_wasi_http_async
_wasmtime_component_linker_add_wasi_http_async.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_component_linker_add_wasi_http_async.argtypes = [ctypes.POINTER(wasmtime_component_linker_t)]
def wasmtime_component_linker_add_wasi_http_async(linker: Any) -> ctypes._Pointer:
    return _wasmtime_component_linker_add_wasi_http_async(linker)  # type: ignore

_wasmtime_engine_clone = dll.wasmtime_engine_clone
_wasmtime_engine_clone.restype = ctypes.POINTER(wasm_engine_t)
_wasmtime_engine_clone.argtypes = [ctypes.POINTER(wasm_engine_t)]
def wasmtime_engine_clone(engine: Any) -> ctypes._Pointer:
    return _wasmtime_engine_clone(engine)  # type: ignore

_wasmtime_engine_increment_epoch = dll.wasmtime_engine_increment_epoch
_wasmtime_engine_increment_epoch.restype = None
_wasmtime_engine_increment_epoch.argtypes = [ctypes.POINTER(wasm_engine_t)]
def wasmtime_engine_increment_epoch(engine: Any) -> None:
    return _wasmtime_engine_increment_epoch(engine)  # type: ignore

_wasmtime_engine_is_pulley = dll.wasmtime_engine_is_pulley
_wasmtime_engine_is_pulley.restype = ctypes.c_bool
_wasmtime_engine_is_pulley.argtypes = [ctypes.POINTER(wasm_engine_t)]
def wasmtime_engine_is_pulley(engine: Any) -> bool:
    return _wasmtime_engine_is_pulley(engine)  # type: ignore

_wasmtime_eqref_clone = dll.wasmtime_eqref_clone
_wasmtime_eqref_clone.restype = None
_wasmtime_eqref_clone.argtypes = [ctypes.POINTER(wasmtime_eqref_t), ctypes.POINTER(wasmtime_eqref_t)]
def wasmtime_eqref_clone(eqref: Any, out: Any) -> None:
    return _wasmtime_eqref_clone(eqref, out)  # type: ignore

_wasmtime_eqref_unroot = dll.wasmtime_eqref_unroot
_wasmtime_eqref_unroot.restype = None
_wasmtime_eqref_unroot.argtypes = [ctypes.POINTER(wasmtime_eqref_t)]
def wasmtime_eqref_unroot(ref: Any) -> None:
    return _wasmtime_eqref_unroot(ref)  # type: ignore

_wasmtime_eqref_to_anyref = dll.wasmtime_eqref_to_anyref
_wasmtime_eqref_to_anyref.restype = None
_wasmtime_eqref_to_anyref.argtypes = [ctypes.POINTER(wasmtime_eqref_t), ctypes.POINTER(wasmtime_anyref_t)]
def wasmtime_eqref_to_anyref(eqref: Any, out: Any) -> None:
    return _wasmtime_eqref_to_anyref(eqref, out)  # type: ignore

_wasmtime_eqref_from_i31 = dll.wasmtime_eqref_from_i31
_wasmtime_eqref_from_i31.restype = None
_wasmtime_eqref_from_i31.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.c_uint32, ctypes.POINTER(wasmtime_eqref_t)]
def wasmtime_eqref_from_i31(context: Any, i31val: Any, out: Any) -> None:
    return _wasmtime_eqref_from_i31(context, i31val, out)  # type: ignore

_wasmtime_eqref_is_i31 = dll.wasmtime_eqref_is_i31
_wasmtime_eqref_is_i31.restype = ctypes.c_bool
_wasmtime_eqref_is_i31.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_eqref_t)]
def wasmtime_eqref_is_i31(context: Any, eqref: Any) -> bool:
    return _wasmtime_eqref_is_i31(context, eqref)  # type: ignore

_wasmtime_eqref_i31_get_u = dll.wasmtime_eqref_i31_get_u
_wasmtime_eqref_i31_get_u.restype = ctypes.c_bool
_wasmtime_eqref_i31_get_u.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_eqref_t), ctypes.POINTER(ctypes.c_uint32)]
def wasmtime_eqref_i31_get_u(context: Any, eqref: Any, dst: Any) -> bool:
    return _wasmtime_eqref_i31_get_u(context, eqref, dst)  # type: ignore

_wasmtime_eqref_i31_get_s = dll.wasmtime_eqref_i31_get_s
_wasmtime_eqref_i31_get_s.restype = ctypes.c_bool
_wasmtime_eqref_i31_get_s.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_eqref_t), ctypes.POINTER(ctypes.c_int32)]
def wasmtime_eqref_i31_get_s(context: Any, eqref: Any, dst: Any) -> bool:
    return _wasmtime_eqref_i31_get_s(context, eqref, dst)  # type: ignore

_wasmtime_eqref_is_array = dll.wasmtime_eqref_is_array
_wasmtime_eqref_is_array.restype = ctypes.c_bool
_wasmtime_eqref_is_array.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_eqref_t)]
def wasmtime_eqref_is_array(context: Any, eqref: Any) -> bool:
    return _wasmtime_eqref_is_array(context, eqref)  # type: ignore

_wasmtime_eqref_as_array = dll.wasmtime_eqref_as_array
_wasmtime_eqref_as_array.restype = ctypes.c_bool
_wasmtime_eqref_as_array.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_eqref_t), ctypes.POINTER(wasmtime_arrayref_t)]
def wasmtime_eqref_as_array(context: Any, eqref: Any, out: Any) -> bool:
    return _wasmtime_eqref_as_array(context, eqref, out)  # type: ignore

_wasmtime_eqref_is_struct = dll.wasmtime_eqref_is_struct
_wasmtime_eqref_is_struct.restype = ctypes.c_bool
_wasmtime_eqref_is_struct.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_eqref_t)]
def wasmtime_eqref_is_struct(context: Any, eqref: Any) -> bool:
    return _wasmtime_eqref_is_struct(context, eqref)  # type: ignore

_wasmtime_eqref_as_struct = dll.wasmtime_eqref_as_struct
_wasmtime_eqref_as_struct.restype = ctypes.c_bool
_wasmtime_eqref_as_struct.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_eqref_t), ctypes.POINTER(wasmtime_structref_t)]
def wasmtime_eqref_as_struct(context: Any, eqref: Any, out: Any) -> bool:
    return _wasmtime_eqref_as_struct(context, eqref, out)  # type: ignore

_wasmtime_eqref_type = dll.wasmtime_eqref_type
_wasmtime_eqref_type.restype = ctypes.c_bool
_wasmtime_eqref_type.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_eqref_t), ctypes.POINTER(wasmtime_heaptype_t)]
def wasmtime_eqref_type(context: Any, eqref: Any, out: Any) -> bool:
    return _wasmtime_eqref_type(context, eqref, out)  # type: ignore

_wasmtime_exnref_new = dll.wasmtime_exnref_new
_wasmtime_exnref_new.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_exnref_new.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_tag_t), ctypes.POINTER(wasmtime_val_t), ctypes.c_size_t, ctypes.POINTER(wasmtime_exnref_t)]
def wasmtime_exnref_new(store: Any, tag: Any, fields: Any, nfields: Any, exn_ret: Any) -> ctypes._Pointer:
    return _wasmtime_exnref_new(store, tag, fields, nfields, exn_ret)  # type: ignore

_wasmtime_exnref_clone = dll.wasmtime_exnref_clone
_wasmtime_exnref_clone.restype = None
_wasmtime_exnref_clone.argtypes = [ctypes.POINTER(wasmtime_exnref_t), ctypes.POINTER(wasmtime_exnref_t)]
def wasmtime_exnref_clone(ref: Any, out: Any) -> None:
    return _wasmtime_exnref_clone(ref, out)  # type: ignore

_wasmtime_exnref_unroot = dll.wasmtime_exnref_unroot
_wasmtime_exnref_unroot.restype = None
_wasmtime_exnref_unroot.argtypes = [ctypes.POINTER(wasmtime_exnref_t)]
def wasmtime_exnref_unroot(ref: Any) -> None:
    return _wasmtime_exnref_unroot(ref)  # type: ignore

_wasmtime_exnref_from_raw = dll.wasmtime_exnref_from_raw
_wasmtime_exnref_from_raw.restype = None
_wasmtime_exnref_from_raw.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.c_uint32, ctypes.POINTER(wasmtime_exnref_t)]
def wasmtime_exnref_from_raw(context: Any, raw: Any, out: Any) -> None:
    return _wasmtime_exnref_from_raw(context, raw, out)  # type: ignore

_wasmtime_exnref_to_raw = dll.wasmtime_exnref_to_raw
_wasmtime_exnref_to_raw.restype = ctypes.c_uint32
_wasmtime_exnref_to_raw.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_exnref_t)]
def wasmtime_exnref_to_raw(context: Any, ref: Any) -> int:
    return _wasmtime_exnref_to_raw(context, ref)  # type: ignore

_wasmtime_exnref_tag = dll.wasmtime_exnref_tag
_wasmtime_exnref_tag.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_exnref_tag.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_exnref_t), ctypes.POINTER(wasmtime_tag_t)]
def wasmtime_exnref_tag(store: Any, exn: Any, tag_ret: Any) -> ctypes._Pointer:
    return _wasmtime_exnref_tag(store, exn, tag_ret)  # type: ignore

_wasmtime_exnref_field_count = dll.wasmtime_exnref_field_count
_wasmtime_exnref_field_count.restype = ctypes.c_size_t
_wasmtime_exnref_field_count.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_exnref_t)]
def wasmtime_exnref_field_count(store: Any, exn: Any) -> int:
    return _wasmtime_exnref_field_count(store, exn)  # type: ignore

_wasmtime_exnref_field = dll.wasmtime_exnref_field
_wasmtime_exnref_field.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_exnref_field.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_exnref_t), ctypes.c_size_t, ctypes.POINTER(wasmtime_val_t)]
def wasmtime_exnref_field(store: Any, exn: Any, index: Any, val_ret: Any) -> ctypes._Pointer:
    return _wasmtime_exnref_field(store, exn, index, val_ret)  # type: ignore

_wasmtime_context_set_exception = dll.wasmtime_context_set_exception
_wasmtime_context_set_exception.restype = ctypes.POINTER(wasm_trap_t)
_wasmtime_context_set_exception.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_exnref_t)]
def wasmtime_context_set_exception(store: Any, exn: Any) -> ctypes._Pointer:
    return _wasmtime_context_set_exception(store, exn)  # type: ignore

_wasmtime_context_take_exception = dll.wasmtime_context_take_exception
_wasmtime_context_take_exception.restype = ctypes.c_bool
_wasmtime_context_take_exception.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_exnref_t)]
def wasmtime_context_take_exception(store: Any, exn_ret: Any) -> bool:
    return _wasmtime_context_take_exception(store, exn_ret)  # type: ignore

_wasmtime_context_has_exception = dll.wasmtime_context_has_exception
_wasmtime_context_has_exception.restype = ctypes.c_bool
_wasmtime_context_has_exception.argtypes = [ctypes.POINTER(wasmtime_context_t)]
def wasmtime_context_has_exception(store: Any) -> bool:
    return _wasmtime_context_has_exception(store)  # type: ignore

_wasmtime_exnref_type = dll.wasmtime_exnref_type
_wasmtime_exnref_type.restype = ctypes.POINTER(wasmtime_exn_type_t)
_wasmtime_exnref_type.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_exnref_t)]
def wasmtime_exnref_type(context: Any, exnref: Any) -> ctypes._Pointer:
    return _wasmtime_exnref_type(context, exnref)  # type: ignore

_wasmtime_externref_new = dll.wasmtime_externref_new
_wasmtime_externref_new.restype = ctypes.c_bool
_wasmtime_externref_new.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.c_void_p, ctypes.CFUNCTYPE(None, ctypes.c_void_p), ctypes.POINTER(wasmtime_externref_t)]
def wasmtime_externref_new(context: Any, data: Any, finalizer: Any, out: Any) -> bool:
    return _wasmtime_externref_new(context, data, finalizer, out)  # type: ignore

_wasmtime_externref_data = dll.wasmtime_externref_data
_wasmtime_externref_data.restype = ctypes.c_void_p
_wasmtime_externref_data.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_externref_t)]
def wasmtime_externref_data(context: Any, data: Any) -> ctypes._Pointer:
    return _wasmtime_externref_data(context, data)  # type: ignore

_wasmtime_externref_clone = dll.wasmtime_externref_clone
_wasmtime_externref_clone.restype = None
_wasmtime_externref_clone.argtypes = [ctypes.POINTER(wasmtime_externref_t), ctypes.POINTER(wasmtime_externref_t)]
def wasmtime_externref_clone(ref: Any, out: Any) -> None:
    return _wasmtime_externref_clone(ref, out)  # type: ignore

_wasmtime_externref_unroot = dll.wasmtime_externref_unroot
_wasmtime_externref_unroot.restype = None
_wasmtime_externref_unroot.argtypes = [ctypes.POINTER(wasmtime_externref_t)]
def wasmtime_externref_unroot(ref: Any) -> None:
    return _wasmtime_externref_unroot(ref)  # type: ignore

_wasmtime_externref_from_raw = dll.wasmtime_externref_from_raw
_wasmtime_externref_from_raw.restype = None
_wasmtime_externref_from_raw.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.c_uint32, ctypes.POINTER(wasmtime_externref_t)]
def wasmtime_externref_from_raw(context: Any, raw: Any, out: Any) -> None:
    return _wasmtime_externref_from_raw(context, raw, out)  # type: ignore

_wasmtime_externref_to_raw = dll.wasmtime_externref_to_raw
_wasmtime_externref_to_raw.restype = ctypes.c_uint32
_wasmtime_externref_to_raw.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_externref_t)]
def wasmtime_externref_to_raw(context: Any, ref: Any) -> int:
    return _wasmtime_externref_to_raw(context, ref)  # type: ignore

_wasmtime_global_new = dll.wasmtime_global_new
_wasmtime_global_new.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_global_new.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasm_globaltype_t), ctypes.POINTER(wasmtime_val_t), ctypes.POINTER(wasmtime_global_t)]
def wasmtime_global_new(store: Any, type: Any, val: Any, ret: Any) -> ctypes._Pointer:
    return _wasmtime_global_new(store, type, val, ret)  # type: ignore

_wasmtime_global_type = dll.wasmtime_global_type
_wasmtime_global_type.restype = ctypes.POINTER(wasm_globaltype_t)
_wasmtime_global_type.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_global_t)]
def wasmtime_global_type(store: Any, arg1: Any) -> ctypes._Pointer:
    return _wasmtime_global_type(store, arg1)  # type: ignore

_wasmtime_global_get = dll.wasmtime_global_get
_wasmtime_global_get.restype = None
_wasmtime_global_get.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_global_t), ctypes.POINTER(wasmtime_val_t)]
def wasmtime_global_get(store: Any, arg1: Any, out: Any) -> None:
    return _wasmtime_global_get(store, arg1, out)  # type: ignore

_wasmtime_global_set = dll.wasmtime_global_set
_wasmtime_global_set.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_global_set.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_global_t), ctypes.POINTER(wasmtime_val_t)]
def wasmtime_global_set(store: Any, arg1: Any, val: Any) -> ctypes._Pointer:
    return _wasmtime_global_set(store, arg1, val)  # type: ignore

_wasmtime_memorytype_new = dll.wasmtime_memorytype_new
_wasmtime_memorytype_new.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_memorytype_new.argtypes = [ctypes.c_uint64, ctypes.c_bool, ctypes.c_uint64, ctypes.c_bool, ctypes.c_bool, ctypes.c_uint8, ctypes.POINTER(ctypes.POINTER(wasm_memorytype_t))]
def wasmtime_memorytype_new(min: Any, max_present: Any, max: Any, is_64: Any, shared: Any, page_size_log2: Any, ret: Any) -> ctypes._Pointer:
    return _wasmtime_memorytype_new(min, max_present, max, is_64, shared, page_size_log2, ret)  # type: ignore

_wasmtime_memorytype_minimum = dll.wasmtime_memorytype_minimum
_wasmtime_memorytype_minimum.restype = ctypes.c_uint64
_wasmtime_memorytype_minimum.argtypes = [ctypes.POINTER(wasm_memorytype_t)]
def wasmtime_memorytype_minimum(ty: Any) -> int:
    return _wasmtime_memorytype_minimum(ty)  # type: ignore

_wasmtime_memorytype_maximum = dll.wasmtime_memorytype_maximum
_wasmtime_memorytype_maximum.restype = ctypes.c_bool
_wasmtime_memorytype_maximum.argtypes = [ctypes.POINTER(wasm_memorytype_t), ctypes.POINTER(ctypes.c_uint64)]
def wasmtime_memorytype_maximum(ty: Any, max: Any) -> bool:
    return _wasmtime_memorytype_maximum(ty, max)  # type: ignore

_wasmtime_memorytype_is64 = dll.wasmtime_memorytype_is64
_wasmtime_memorytype_is64.restype = ctypes.c_bool
_wasmtime_memorytype_is64.argtypes = [ctypes.POINTER(wasm_memorytype_t)]
def wasmtime_memorytype_is64(ty: Any) -> bool:
    return _wasmtime_memorytype_is64(ty)  # type: ignore

_wasmtime_memorytype_isshared = dll.wasmtime_memorytype_isshared
_wasmtime_memorytype_isshared.restype = ctypes.c_bool
_wasmtime_memorytype_isshared.argtypes = [ctypes.POINTER(wasm_memorytype_t)]
def wasmtime_memorytype_isshared(ty: Any) -> bool:
    return _wasmtime_memorytype_isshared(ty)  # type: ignore

_wasmtime_memorytype_page_size = dll.wasmtime_memorytype_page_size
_wasmtime_memorytype_page_size.restype = ctypes.c_uint64
_wasmtime_memorytype_page_size.argtypes = [ctypes.POINTER(wasm_memorytype_t)]
def wasmtime_memorytype_page_size(ty: Any) -> int:
    return _wasmtime_memorytype_page_size(ty)  # type: ignore

_wasmtime_memorytype_page_size_log2 = dll.wasmtime_memorytype_page_size_log2
_wasmtime_memorytype_page_size_log2.restype = ctypes.c_uint8
_wasmtime_memorytype_page_size_log2.argtypes = [ctypes.POINTER(wasm_memorytype_t)]
def wasmtime_memorytype_page_size_log2(ty: Any) -> ctypes.c_uint8:
    return _wasmtime_memorytype_page_size_log2(ty)  # type: ignore

_wasmtime_memory_new = dll.wasmtime_memory_new
_wasmtime_memory_new.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_memory_new.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasm_memorytype_t), ctypes.POINTER(wasmtime_memory_t)]
def wasmtime_memory_new(store: Any, ty: Any, ret: Any) -> ctypes._Pointer:
    return _wasmtime_memory_new(store, ty, ret)  # type: ignore

_wasmtime_memory_type = dll.wasmtime_memory_type
_wasmtime_memory_type.restype = ctypes.POINTER(wasm_memorytype_t)
_wasmtime_memory_type.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_memory_t)]
def wasmtime_memory_type(store: Any, memory: Any) -> ctypes._Pointer:
    return _wasmtime_memory_type(store, memory)  # type: ignore

_wasmtime_memory_data = dll.wasmtime_memory_data
_wasmtime_memory_data.restype = ctypes.POINTER(ctypes.c_uint8)
_wasmtime_memory_data.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_memory_t)]
def wasmtime_memory_data(store: Any, memory: Any) -> ctypes._Pointer:
    return _wasmtime_memory_data(store, memory)  # type: ignore

_wasmtime_memory_data_size = dll.wasmtime_memory_data_size
_wasmtime_memory_data_size.restype = ctypes.c_size_t
_wasmtime_memory_data_size.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_memory_t)]
def wasmtime_memory_data_size(store: Any, memory: Any) -> int:
    return _wasmtime_memory_data_size(store, memory)  # type: ignore

_wasmtime_memory_size = dll.wasmtime_memory_size
_wasmtime_memory_size.restype = ctypes.c_uint64
_wasmtime_memory_size.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_memory_t)]
def wasmtime_memory_size(store: Any, memory: Any) -> int:
    return _wasmtime_memory_size(store, memory)  # type: ignore

_wasmtime_memory_grow = dll.wasmtime_memory_grow
_wasmtime_memory_grow.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_memory_grow.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_memory_t), ctypes.c_uint64, ctypes.POINTER(ctypes.c_uint64)]
def wasmtime_memory_grow(store: Any, memory: Any, delta: Any, prev_size: Any) -> ctypes._Pointer:
    return _wasmtime_memory_grow(store, memory, delta, prev_size)  # type: ignore

_wasmtime_memory_page_size = dll.wasmtime_memory_page_size
_wasmtime_memory_page_size.restype = ctypes.c_uint64
_wasmtime_memory_page_size.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_memory_t)]
def wasmtime_memory_page_size(store: Any, memory: Any) -> int:
    return _wasmtime_memory_page_size(store, memory)  # type: ignore

_wasmtime_memory_page_size_log2 = dll.wasmtime_memory_page_size_log2
_wasmtime_memory_page_size_log2.restype = ctypes.c_uint8
_wasmtime_memory_page_size_log2.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_memory_t)]
def wasmtime_memory_page_size_log2(store: Any, memory: Any) -> ctypes.c_uint8:
    return _wasmtime_memory_page_size_log2(store, memory)  # type: ignore

class wasmtime_guestprofiler(ctypes.Structure):
    pass

wasmtime_guestprofiler_t = wasmtime_guestprofiler

_wasmtime_guestprofiler_delete = dll.wasmtime_guestprofiler_delete
_wasmtime_guestprofiler_delete.restype = None
_wasmtime_guestprofiler_delete.argtypes = [ctypes.POINTER(wasmtime_guestprofiler_t)]
def wasmtime_guestprofiler_delete(guestprofiler: Any) -> None:
    return _wasmtime_guestprofiler_delete(guestprofiler)  # type: ignore

class wasmtime_guestprofiler_modules(ctypes.Structure):
    _fields_ = [
        ("name", ctypes.POINTER(wasm_name_t)),
        ("mod", ctypes.POINTER(wasmtime_module_t)),
    ]
    name: ctypes._Pointer
    mod: ctypes._Pointer

wasmtime_guestprofiler_modules_t = wasmtime_guestprofiler_modules

_wasmtime_guestprofiler_new = dll.wasmtime_guestprofiler_new
_wasmtime_guestprofiler_new.restype = ctypes.POINTER(wasmtime_guestprofiler_t)
_wasmtime_guestprofiler_new.argtypes = [ctypes.POINTER(wasm_engine_t), ctypes.POINTER(wasm_name_t), ctypes.c_uint64, ctypes.POINTER(wasmtime_guestprofiler_modules_t), ctypes.c_size_t]
def wasmtime_guestprofiler_new(engine: Any, module_name: Any, interval_nanos: Any, modules: Any, modules_len: Any) -> ctypes._Pointer:
    return _wasmtime_guestprofiler_new(engine, module_name, interval_nanos, modules, modules_len)  # type: ignore

_wasmtime_guestprofiler_sample = dll.wasmtime_guestprofiler_sample
_wasmtime_guestprofiler_sample.restype = None
_wasmtime_guestprofiler_sample.argtypes = [ctypes.POINTER(wasmtime_guestprofiler_t), ctypes.POINTER(wasmtime_store_t), ctypes.c_uint64]
def wasmtime_guestprofiler_sample(guestprofiler: Any, store: Any, delta_nanos: Any) -> None:
    return _wasmtime_guestprofiler_sample(guestprofiler, store, delta_nanos)  # type: ignore

_wasmtime_guestprofiler_finish = dll.wasmtime_guestprofiler_finish
_wasmtime_guestprofiler_finish.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_guestprofiler_finish.argtypes = [ctypes.POINTER(wasmtime_guestprofiler_t), ctypes.POINTER(wasm_byte_vec_t)]
def wasmtime_guestprofiler_finish(guestprofiler: Any, out: Any) -> ctypes._Pointer:
    return _wasmtime_guestprofiler_finish(guestprofiler, out)  # type: ignore

class wasmtime_struct_ref_pre(ctypes.Structure):
    pass

wasmtime_struct_ref_pre_t = wasmtime_struct_ref_pre

_wasmtime_struct_ref_pre_new = dll.wasmtime_struct_ref_pre_new
_wasmtime_struct_ref_pre_new.restype = ctypes.POINTER(wasmtime_struct_ref_pre_t)
_wasmtime_struct_ref_pre_new.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_struct_type_t)]
def wasmtime_struct_ref_pre_new(context: Any, ty: Any) -> ctypes._Pointer:
    return _wasmtime_struct_ref_pre_new(context, ty)  # type: ignore

_wasmtime_struct_ref_pre_delete = dll.wasmtime_struct_ref_pre_delete
_wasmtime_struct_ref_pre_delete.restype = None
_wasmtime_struct_ref_pre_delete.argtypes = [ctypes.POINTER(wasmtime_struct_ref_pre_t)]
def wasmtime_struct_ref_pre_delete(pre: Any) -> None:
    return _wasmtime_struct_ref_pre_delete(pre)  # type: ignore

_wasmtime_structref_new = dll.wasmtime_structref_new
_wasmtime_structref_new.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_structref_new.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_struct_ref_pre_t), ctypes.POINTER(wasmtime_val_t), ctypes.c_size_t, ctypes.POINTER(wasmtime_structref_t)]
def wasmtime_structref_new(context: Any, pre: Any, fields: Any, nfields: Any, out: Any) -> ctypes._Pointer:
    return _wasmtime_structref_new(context, pre, fields, nfields, out)  # type: ignore

_wasmtime_structref_clone = dll.wasmtime_structref_clone
_wasmtime_structref_clone.restype = None
_wasmtime_structref_clone.argtypes = [ctypes.POINTER(wasmtime_structref_t), ctypes.POINTER(wasmtime_structref_t)]
def wasmtime_structref_clone(structref: Any, out: Any) -> None:
    return _wasmtime_structref_clone(structref, out)  # type: ignore

_wasmtime_structref_unroot = dll.wasmtime_structref_unroot
_wasmtime_structref_unroot.restype = None
_wasmtime_structref_unroot.argtypes = [ctypes.POINTER(wasmtime_structref_t)]
def wasmtime_structref_unroot(ref: Any) -> None:
    return _wasmtime_structref_unroot(ref)  # type: ignore

_wasmtime_structref_to_anyref = dll.wasmtime_structref_to_anyref
_wasmtime_structref_to_anyref.restype = None
_wasmtime_structref_to_anyref.argtypes = [ctypes.POINTER(wasmtime_structref_t), ctypes.POINTER(wasmtime_anyref_t)]
def wasmtime_structref_to_anyref(structref: Any, out: Any) -> None:
    return _wasmtime_structref_to_anyref(structref, out)  # type: ignore

_wasmtime_structref_to_eqref = dll.wasmtime_structref_to_eqref
_wasmtime_structref_to_eqref.restype = None
_wasmtime_structref_to_eqref.argtypes = [ctypes.POINTER(wasmtime_structref_t), ctypes.POINTER(wasmtime_eqref_t)]
def wasmtime_structref_to_eqref(structref: Any, out: Any) -> None:
    return _wasmtime_structref_to_eqref(structref, out)  # type: ignore

_wasmtime_structref_field = dll.wasmtime_structref_field
_wasmtime_structref_field.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_structref_field.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_structref_t), ctypes.c_size_t, ctypes.POINTER(wasmtime_val_t)]
def wasmtime_structref_field(context: Any, structref: Any, index: Any, out: Any) -> ctypes._Pointer:
    return _wasmtime_structref_field(context, structref, index, out)  # type: ignore

_wasmtime_structref_set_field = dll.wasmtime_structref_set_field
_wasmtime_structref_set_field.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_structref_set_field.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_structref_t), ctypes.c_size_t, ctypes.POINTER(wasmtime_val_t)]
def wasmtime_structref_set_field(context: Any, structref: Any, index: Any, val: Any) -> ctypes._Pointer:
    return _wasmtime_structref_set_field(context, structref, index, val)  # type: ignore

_wasmtime_structref_type = dll.wasmtime_structref_type
_wasmtime_structref_type.restype = ctypes.POINTER(wasmtime_struct_type_t)
_wasmtime_structref_type.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_structref_t)]
def wasmtime_structref_type(context: Any, structref: Any) -> ctypes._Pointer:
    return _wasmtime_structref_type(context, structref)  # type: ignore

_wasmtime_table_new = dll.wasmtime_table_new
_wasmtime_table_new.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_table_new.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasm_tabletype_t), ctypes.POINTER(wasmtime_val_t), ctypes.POINTER(wasmtime_table_t)]
def wasmtime_table_new(store: Any, ty: Any, init: Any, table: Any) -> ctypes._Pointer:
    return _wasmtime_table_new(store, ty, init, table)  # type: ignore

_wasmtime_table_type = dll.wasmtime_table_type
_wasmtime_table_type.restype = ctypes.POINTER(wasm_tabletype_t)
_wasmtime_table_type.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_table_t)]
def wasmtime_table_type(store: Any, table: Any) -> ctypes._Pointer:
    return _wasmtime_table_type(store, table)  # type: ignore

_wasmtime_table_get = dll.wasmtime_table_get
_wasmtime_table_get.restype = ctypes.c_bool
_wasmtime_table_get.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_table_t), ctypes.c_uint64, ctypes.POINTER(wasmtime_val_t)]
def wasmtime_table_get(store: Any, table: Any, index: Any, val: Any) -> bool:
    return _wasmtime_table_get(store, table, index, val)  # type: ignore

_wasmtime_table_set = dll.wasmtime_table_set
_wasmtime_table_set.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_table_set.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_table_t), ctypes.c_uint64, ctypes.POINTER(wasmtime_val_t)]
def wasmtime_table_set(store: Any, table: Any, index: Any, value: Any) -> ctypes._Pointer:
    return _wasmtime_table_set(store, table, index, value)  # type: ignore

_wasmtime_table_size = dll.wasmtime_table_size
_wasmtime_table_size.restype = ctypes.c_uint64
_wasmtime_table_size.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_table_t)]
def wasmtime_table_size(store: Any, table: Any) -> int:
    return _wasmtime_table_size(store, table)  # type: ignore

_wasmtime_table_grow = dll.wasmtime_table_grow
_wasmtime_table_grow.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_table_grow.argtypes = [ctypes.POINTER(wasmtime_context_t), ctypes.POINTER(wasmtime_table_t), ctypes.c_uint64, ctypes.POINTER(wasmtime_val_t), ctypes.POINTER(ctypes.c_uint64)]
def wasmtime_table_grow(store: Any, table: Any, delta: Any, init: Any, prev_size: Any) -> ctypes._Pointer:
    return _wasmtime_table_grow(store, table, delta, init, prev_size)  # type: ignore

wasmtime_trap_code_t = ctypes.c_uint8

class wasmtime_trap_code_enum(Enum):
    WASMTIME_TRAP_CODE_STACK_OVERFLOW = 0
    WASMTIME_TRAP_CODE_MEMORY_OUT_OF_BOUNDS = 1
    WASMTIME_TRAP_CODE_HEAP_MISALIGNED = 2
    WASMTIME_TRAP_CODE_TABLE_OUT_OF_BOUNDS = 3
    WASMTIME_TRAP_CODE_INDIRECT_CALL_TO_NULL = 4
    WASMTIME_TRAP_CODE_BAD_SIGNATURE = 5
    WASMTIME_TRAP_CODE_INTEGER_OVERFLOW = 6
    WASMTIME_TRAP_CODE_INTEGER_DIVISION_BY_ZERO = 7
    WASMTIME_TRAP_CODE_BAD_CONVERSION_TO_INTEGER = 8
    WASMTIME_TRAP_CODE_UNREACHABLE_CODE_REACHED = 9
    WASMTIME_TRAP_CODE_INTERRUPT = 10
    WASMTIME_TRAP_CODE_OUT_OF_FUEL = 11
    WASMTIME_TRAP_CODE_ATOMIC_WAIT_NON_SHARED_MEMORY = 12
    WASMTIME_TRAP_CODE_NULL_REFERENCE = 13
    WASMTIME_TRAP_CODE_ARRAY_OUT_OF_BOUNDS = 14
    WASMTIME_TRAP_CODE_ALLOCATION_TOO_LARGE = 15
    WASMTIME_TRAP_CODE_CAST_FAILURE = 16
    WASMTIME_TRAP_CODE_CANNOT_ENTER_COMPONENT = 17
    WASMTIME_TRAP_CODE_NO_ASYNC_RESULT = 18
    WASMTIME_TRAP_CODE_UNHANDLED_TAG = 19
    WASMTIME_TRAP_CODE_CONTINUATION_ALREADY_CONSUMED = 20
    WASMTIME_TRAP_CODE_DISABLED_OPCODE = 21
    WASMTIME_TRAP_CODE_ASYNC_DEADLOCK = 22
    WASMTIME_TRAP_CODE_CANNOT_LEAVE_COMPONENT = 23
    WASMTIME_TRAP_CODE_CANNOT_BLOCK_SYNC_TASK = 24
    WASMTIME_TRAP_CODE_INVALID_CHAR = 25
    WASMTIME_TRAP_CODE_DEBUG_ASSERT_STRING_ENCODING_FINISHED = 26
    WASMTIME_TRAP_CODE_DEBUG_ASSERT_EQUAL_CODE_UNITS = 27
    WASMTIME_TRAP_CODE_DEBUG_ASSERT_POINTER_ALIGNED = 28
    WASMTIME_TRAP_CODE_DEBUG_ASSERT_UPPER_BITS_UNSET = 29
    WASMTIME_TRAP_CODE_STRING_OUT_OF_BOUNDS = 30
    WASMTIME_TRAP_CODE_LIST_OUT_OF_BOUNDS = 31
    WASMTIME_TRAP_CODE_INVALID_DISCRIMINANT = 32
    WASMTIME_TRAP_CODE_UNALIGNED_POINTER = 33
    WASMTIME_TRAP_CODE_TASK_CANCEL_NOT_CANCELLED = 34
    WASMTIME_TRAP_CODE_TASK_CANCEL_OR_RETURN_TWICE = 35
    WASMTIME_TRAP_CODE_SUBTASK_CANCEL_AFTER_TERMINAL = 36
    WASMTIME_TRAP_CODE_TASK_RETURN_INVALID = 37
    WASMTIME_TRAP_CODE_WAITABLE_SET_DROP_HAS_WAITERS = 38
    WASMTIME_TRAP_CODE_SUBTASK_DROP_NOT_RESOLVED = 39
    WASMTIME_TRAP_CODE_THREAD_NEW_INDIRECT_INVALID_TYPE = 40
    WASMTIME_TRAP_CODE_THREAD_NEW_INDIRECT_UNINITIALIZED = 41
    WASMTIME_TRAP_CODE_BACKPRESSURE_OVERFLOW = 42
    WASMTIME_TRAP_CODE_UNSUPPORTED_CALLBACK_CODE = 43
    WASMTIME_TRAP_CODE_CANNOT_RESUME_THREAD = 44
    WASMTIME_TRAP_CODE_CONCURRENT_FUTURE_STREAM_OP = 45
    WASMTIME_TRAP_CODE_REFERENCE_COUNT_OVERFLOW = 46
    WASMTIME_TRAP_CODE_STREAM_OP_TOO_BIG = 47
    WASMTIME_TRAP_CODE_WAITABLE_SYNC_AND_ASYNC = 48
    WASMTIME_TRAP_CODE_UNCAUGHT_EXCEPTION = 49

_wasmtime_trap_new = dll.wasmtime_trap_new
_wasmtime_trap_new.restype = ctypes.POINTER(wasm_trap_t)
_wasmtime_trap_new.argtypes = [ctypes.POINTER(ctypes.c_char), ctypes.c_size_t]
def wasmtime_trap_new(msg: Any, msg_len: Any) -> ctypes._Pointer:
    return _wasmtime_trap_new(msg, msg_len)  # type: ignore

_wasmtime_trap_new_code = dll.wasmtime_trap_new_code
_wasmtime_trap_new_code.restype = ctypes.POINTER(wasm_trap_t)
_wasmtime_trap_new_code.argtypes = [wasmtime_trap_code_t]
def wasmtime_trap_new_code(code: Any) -> ctypes._Pointer:
    return _wasmtime_trap_new_code(code)  # type: ignore

_wasmtime_trap_code = dll.wasmtime_trap_code
_wasmtime_trap_code.restype = ctypes.c_bool
_wasmtime_trap_code.argtypes = [ctypes.POINTER(wasm_trap_t), ctypes.POINTER(wasmtime_trap_code_t)]
def wasmtime_trap_code(arg0: Any, code: Any) -> bool:
    return _wasmtime_trap_code(arg0, code)  # type: ignore

_wasmtime_frame_func_name = dll.wasmtime_frame_func_name
_wasmtime_frame_func_name.restype = ctypes.POINTER(wasm_name_t)
_wasmtime_frame_func_name.argtypes = [ctypes.POINTER(wasm_frame_t)]
def wasmtime_frame_func_name(arg0: Any) -> ctypes._Pointer:
    return _wasmtime_frame_func_name(arg0)  # type: ignore

_wasmtime_frame_module_name = dll.wasmtime_frame_module_name
_wasmtime_frame_module_name.restype = ctypes.POINTER(wasm_name_t)
_wasmtime_frame_module_name.argtypes = [ctypes.POINTER(wasm_frame_t)]
def wasmtime_frame_module_name(arg0: Any) -> ctypes._Pointer:
    return _wasmtime_frame_module_name(arg0)  # type: ignore

_wasmtime_wat2wasm = dll.wasmtime_wat2wasm
_wasmtime_wat2wasm.restype = ctypes.POINTER(wasmtime_error_t)
_wasmtime_wat2wasm.argtypes = [ctypes.POINTER(ctypes.c_char), ctypes.c_size_t, ctypes.POINTER(wasm_byte_vec_t)]
def wasmtime_wat2wasm(wat: Any, wat_len: Any, ret: Any) -> ctypes._Pointer:
    return _wasmtime_wat2wasm(wat, wat_len, ret)  # type: ignore
